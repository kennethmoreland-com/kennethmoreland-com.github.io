// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramVolumeRenderingIntegrateInputs.cxx,v 1.1 2003-09-02 23:16:20 kmorel Exp $

#include "ocaProgramVolumeRenderingIntegrateInputs.h"

ocaProgramVolumeRenderingIntegrateInputs
    ::ocaProgramVolumeRenderingIntegrateInputs()
{
    this->loadProgram("vri_inputs.cg",
		      "VolumeRenderingIntegrateInputsVert",
		      "VolumeRenderingIntegrateInputsFrag");

    this->OutSelect = cgGetNamedParameter(this->fragProgram, "OutSelect");
    if (this->OutSelect == NULL) {
	ocaRaiseError("Could not get pointer for parameter OutSelect");
    }
}

ocaProgramVolumeRenderingIntegrateInputs
    ::~ocaProgramVolumeRenderingIntegrateInputs()
{
}

void ocaProgramVolumeRenderingIntegrateInputs::setOutSelect(float select)
{
    cgGLSetParameter1f(this->OutSelect, select);
}
