// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramDrawColor.h,v 1.2 2003-06-30 17:56:02 kmorel Exp $

#ifndef _ocaProgramDrawColor_h
#define _ocaProgramDrawColor_h

#include "ocaProgram.h"


// Binding this object binds a fragment program that will pass color values
// to the frame buffer.  Use this to issue drawing OpenGL calls that
// produce colors to get them to the frame buffer.
class OCA_EXPORT ocaProgramDrawColor : public ocaProgram
{
  public:
    ocaProgramMacro(DrawColor);
};

#endif //_ocaProgramDrawColor_h
