// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT.h,v 1.3 2003-06-30 17:56:02 kmorel Exp $

#ifndef _ocaProgramFFT_h
#define _ocaProgramFFT_h

#include "ocaProgram.h"

class ocaLookUpBuffer;
class ocaDrawableBuffer;

class OCA_EXPORT ocaProgramFFT : public ocaProgram
{
  public:
    ocaProgramMacro(FFT);

    void FFT1DS(ocaSmartPointer<ocaLookUpBuffer> samplesReal,
		ocaSmartPointer<ocaLookUpBuffer> samplesImaginary,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesReal,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesImaginary);
    void FFT1DS(ocaSmartPointer<ocaLookUpBuffer> samplesReal,
		ocaSmartPointer<ocaLookUpBuffer> samplesImaginary,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesReal,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesImaginary,
		ocaSmartPointer<ocaDrawableBuffer> temporary1,
		ocaSmartPointer<ocaDrawableBuffer> temporary2);

    void FFT1DT(ocaSmartPointer<ocaLookUpBuffer> samplesReal,
		ocaSmartPointer<ocaLookUpBuffer> samplesImaginary,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesReal,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesImaginary);
    void FFT1DT(ocaSmartPointer<ocaLookUpBuffer> samplesReal,
		ocaSmartPointer<ocaLookUpBuffer> samplesImaginary,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesReal,
		ocaSmartPointer<ocaDrawableBuffer> frequenciesImaginary,
		ocaSmartPointer<ocaDrawableBuffer> temporary1,
		ocaSmartPointer<ocaDrawableBuffer> temporary2);

    void FFT2D(ocaSmartPointer<ocaLookUpBuffer> samplesReal,
	       ocaSmartPointer<ocaLookUpBuffer> samplesImaginary,
	       ocaSmartPointer<ocaDrawableBuffer> frequenciesReal,
	       ocaSmartPointer<ocaDrawableBuffer> frequenciesImaginary);
    void FFT2D(ocaSmartPointer<ocaLookUpBuffer> samplesReal,
	       ocaSmartPointer<ocaLookUpBuffer> samplesImaginary,
	       ocaSmartPointer<ocaDrawableBuffer> frequenciesReal,
	       ocaSmartPointer<ocaDrawableBuffer> frequenciesImaginary,
	       ocaSmartPointer<ocaDrawableBuffer> temporary1,
	       ocaSmartPointer<ocaDrawableBuffer> temporary2);
};

#endif //_ocaProgramFFT_h
