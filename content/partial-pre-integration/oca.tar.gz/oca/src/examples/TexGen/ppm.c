/* -*- c -*- */

#include "ppm.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define DELIM	" \t\n\r"

#define VERIFY_TOKEN()			\
    while (token == NULL) {		\
	do {				\
	    fgets(buffer, 70, fd);	\
	} while (buffer[0] == '#');	\
	token = strtok(buffer, DELIM);	\
    }

#define GET_NEXT_TOKEN()		\
    token = strtok(NULL, DELIM);	\
    VERIFY_TOKEN()

unsigned char *ppm_load(const char *filename, int *widthp, int *heightp)
{
    FILE *fd;
    char buffer[70];
    char *token;
    unsigned char *image;
    int x;

    fd = fopen(filename, "rb");
    if (fd == NULL) {
	fprintf(stderr, "Could not open `%s'\n", filename);
	return NULL;
    }

    fgets(buffer, 70, fd);
    token = strtok(buffer, DELIM);
    if (strcmp(token, "P6") != 0) {
	fprintf(stderr, "Bad magic number: `%s'\n", token);
	return NULL;
    }

    GET_NEXT_TOKEN();
    *widthp = atoi(token);
    GET_NEXT_TOKEN();
    *heightp = atoi(token);
    GET_NEXT_TOKEN();
  /* Ignore maximum color-component value. */

    image = malloc((*widthp)*(*heightp)*3);
    for (x = 0; x < *heightp; x++) {
	fread(image + 3*(*heightp-x-1)*(*widthp), 3, *widthp, fd);
    }

    return image;
}
