// -*- c++ -*- *******************************************************

#include <stdlib.h>
#include <stdio.h>
#include "ppm.h"
#include <GL/glut.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <iostream>

#include <ocaFactory.h>
#include <ocaTimer.h>
#include <ocaError.h>
#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaProgramPassThrough.h>
#include <ocaProgramScale.h>
#include <ocaProgramFFT2c.h>
#include <ocaProgramIFFT2c.h>
#include <ocaProgramFFT2cMult.h>
#include <ocaProgramFFT2cMagnitude.h>


static int width = 512;
static int height = 512;

static int original_window;
static int perturbed_window;

static unsigned char *image = NULL;

static ocaDrawableBuffer::pointer drawable1;
static ocaDrawableBuffer::pointer drawable2;
static ocaDrawableBuffer::pointer drawable3;

#define FLOAT_RAND(min, max)					\
    (((float)rand()/(float)RAND_MAX)*((max)-(min)) + (min))

#define NUM_GAUSSIAN_VALUES	12
static float gaussian_rand()
{
    double value = 0;
    for (int i = 0; i < NUM_GAUSSIAN_VALUES; i++) {
	value = value + FLOAT_RAND(-0.5, 0.5);
    }

    return (float)value;
}

#ifndef M_PI
#define M_PI		3.14159265358979323846
#define M_TWOPI         (M_PI * 2.0)
#endif

static void load_image(const char *filename)
{
    int x, y;

    free(image);

    image = ppm_load(filename, &x, &y);
    if ((image == NULL) || (x != width) || (y != height)) {
	std::cerr << "Bad image load." << std::endl;
	exit(1);
    }
}

static void reshape(int w, int h)
{
  // Set up viewport to draw smaller image correctly.
    glViewport(0, 0, width, height);
}

static void quit()
{
    ocaObject::finalize();
    exit(0);
}

static void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
      case 'q':
      case 'Q':
	  quit();
	  break;
    }
}

#if 0
enum MenuStates {
    MENU_TOGGLE_ROTATE,
    MENU_TOGGLE_SHOW_FREQUENCIES,
    MENU_FILTER_NONE,
    MENU_FILTER_LOWPASS,
    MENU_FILTER_HIGHPASS,
    MENU_FILTER_BANDPASS,
    MENU_FILTER_BANDSTOP,
    MENU_FILTER_LAPLACIAN,
    MENU_NULL
};
static void menu(int value)
{
    switch (value) {
      case MENU_TOGGLE_ROTATE:
	  state.rotate = (state.rotate == ROTATE_OFF) ? ROTATE_ON : ROTATE_OFF;
	  break;
      case MENU_TOGGLE_SHOW_FREQUENCIES:
	  state.showFrequencies =
	      (state.showFrequencies == SHOW_FREQUENCIES_OFF)
	      ? SHOW_FREQUENCIES_ON : SHOW_FREQUENCIES_OFF;
	  break;
      case MENU_FILTER_NONE:
	  state.filter = FILTER_OFF;
	  break;
      case MENU_FILTER_LOWPASS:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = lowpassFrequencyResponse;
	  break;
      case MENU_FILTER_HIGHPASS:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = highpassFrequencyResponse;
	  break;
      case MENU_FILTER_BANDPASS:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = bandpassFrequencyResponse;
	  break;
      case MENU_FILTER_BANDSTOP:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = bandstopFrequencyResponse;
	  break;
      case MENU_FILTER_LAPLACIAN:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = laplacianFrequencyResponse;
	  break;
    }

    resetTimer();
    glutPostRedisplay();
}
#endif

static void draw_original()
{
    glDrawPixels(width, height, GL_RGB, GL_UNSIGNED_BYTE, image);
}

static void draw_perturbed()
{
    ocaDrawableBuffer::pointer result;

    ocaFactory::pointer factory = ocaFactory::getSingleton();

    ocaLookUpBuffer::pointer original = factory->makeLookUpBuffer();
    original->setSize(width, height, 4);
    original->bind();
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_FLOAT_RGBA_NV, width, height, 0,
		 GL_RGB, GL_UNSIGNED_BYTE, image);

#define MAKE_FILTER_FFT_DIRECT	1
    float *filter_data = new float[width*height*3];
#if MAKE_FILTER_FFT_DIRECT
    int i, j, k;
    for (k = 0; k < 3; k++) {
	filter_data[k] = 1;
	filter_data[3*(height/2)*width + k] = 1;
	filter_data[3*(width/2) + k] = 1;
	filter_data[3*((height/2)*width + width/2) + k] = 1;
    }
    for (i = 1; i < height/2; i++) {
	float angle = gaussian_rand()*M_PI;
	for (k = 0; k < 3; k++) {
	    filter_data[3*i*width + k] = cos(angle);
	    filter_data[3*(height-i)*width + k] = sin(angle);
	}
	angle = gaussian_rand()*M_PI;
	for (k = 0; k < 3; k++) {
	    filter_data[3*(i*width + width/2) + k] = cos(angle);
	    filter_data[3*((height-i)*width + width/2) + k] = sin(angle);
	}
    }
    for (i = 0; i < height; i++) {
	for (j = 1; j < width/2; j++) {
	    float angle = gaussian_rand()*M_PI;
	    for (k = 0; k < 3; k++) {
		filter_data[3*(i*width + j) + k] = cos(angle);
		filter_data[3*(i*width + width-j) + k] = sin(angle);
	    }
	}
    }
#else
    for (int i = 0; i < width*height; i++) {
	filter_data[i] = 26214*gaussian_rand();
// 	filter_data[i] = 0;
    }
//     filter_data[0] = 262144 ;
#endif

    ocaLookUpBuffer::pointer filter = factory->makeLookUpBuffer();
    filter->setData(filter_data, width, height, 3);
    delete[] filter_data;

    ocaProgramFFT2c::pointer FFT = ocaProgramFFT2c::getSingleton();

    FFT->execute(original, drawable1, drawable3);
#if !MAKE_FILTER_FFT_DIRECT
    FFT->execute(filter, drawable2, drawable3);
#else
    ocaProgramFFT2cMagnitude::getSingleton()->execute(filter, drawable2);
#endif

    ocaProgramFFT2cMult::getSingleton()
	->execute(drawable1->getSharedLookUpBuffer(),
#if !MAKE_FILTER_FFT_DIRECT
		  drawable2->getSharedLookUpBuffer(),
#else
		  filter,
#endif
		  drawable3);
    drawable1->releaseLookUpBuffer();
    drawable2->releaseLookUpBuffer();

    result = ocaProgramIFFT2c::getSingleton()->execute(drawable3, drawable2);

    float *tmp = new float[width*height*4];
    result->getData(tmp);
    float min, max;
    min = max = tmp[0];
    for (i = 1; i < width*height*4; i++) {
	if (i%4 == 3) continue;
	if (min > tmp[i]) min = tmp[i];
	if (max < tmp[i]) max = tmp[i];
    }
    std::cout << min << " " << max << std::endl;
    delete[] tmp;

    glutSetWindow(perturbed_window);
    ocaProgramPassThrough::getSingleton()
	->execute(result->getSharedLookUpBuffer());
    result->releaseLookUpBuffer();
    

#if 0
    if (   (state.showFrequencies == SHOW_FREQUENCIES_ON)
	|| (state.filter == FILTER_ON) ) {
      // Grab data into oca texture.
	ocaSource->bind();
	glCopyTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
			 0, 0, width, height, 0);

	ocaDrawableBuffer::pointer lastResult = ocaDrawable1;
	ocaDrawableBuffer::pointer scratch = ocaDrawable2;

      // Perform the FFT.
	ocaProgramFFT2c::getSingleton()->execute(ocaSource,
						 lastResult, scratch);

	if (state.filter == FILTER_ON) {
	    ocaProgramFFT2cMult::getSingleton()
		->execute(lastResult->getSharedLookUpBuffer(),
			  state.frequencyResponse,
			  scratch);
	    lastResult->releaseLookUpBuffer();
// 	    scratch->copy(ocaCast<ocaBuffer>(state.frequencyResponse));
	    std::swap(lastResult, scratch);
	  // I shouldn't have to do this.  Is there a bug in the driver?
	    scratch->copy(ocaCast<ocaBuffer>(lastResult));
	    std::swap(lastResult, scratch);
	}

	if (state.showFrequencies == SHOW_FREQUENCIES_ON) {
	  // Show the magnitudes.
	    ocaProgramFFT2cMagnitude::getSingleton()
		->execute(lastResult->getSharedLookUpBuffer(), scratch);
	    lastResult->releaseLookUpBuffer();
	    lastResult = scratch;
	} else {
	  // Perform the IFFT.
	    ocaProgramIFFT2c::getSingleton()->execute(lastResult, scratch,
						      lastResult, scratch);
// 	    lastResult = ocaProgramIFFT2c::getSingleton()->execute(lastResult,
// 								   scratch);
	}

      // Get the final result.
	ocaLookUpBuffer::pointer result = lastResult->getSharedLookUpBuffer();

      // Copy image back into buffer.
	glutSetWindow(glutWindow);
	ocaProgramPassThrough::getSingleton()->execute(result);

      // Release the rendered texture.
	lastResult->releaseLookUpBuffer();
    }

    glutSwapBuffers();

    framecount++;
    timer->stop();
    if (timer->getElapsedTime() > 5.0) {
	glFinish();
	timer->stop();
	printf("Frame time = %f; Pixel time = %g\n",
	       timer->getElapsedTime()/framecount,
	       timer->getElapsedTime()/(framecount*width*height));
	resetTimer();
    }
#endif
}

static void init_glut(int *argcp, char **argv)
{
    glutInit(argcp, argv);
    glutInitWindowSize(width, height);
    glutInitDisplayMode(GLUT_RGBA | GLUT_SINGLE);

    original_window = glutCreateWindow("Original");
    glutReshapeFunc(reshape);
    glutDisplayFunc(draw_original);
    glutKeyboardFunc(keyboard);

    glutInitWindowPosition(width+15, 0);

    perturbed_window = glutCreateWindow("Perturbed");
    glutReshapeFunc(reshape);
    glutDisplayFunc(draw_perturbed);
    glutKeyboardFunc(keyboard);
}
    

static void init_oca()
{
    glutSetWindow(perturbed_window);
    HGLRC glutContext = wglGetCurrentContext();
    HGLRC ocaContext;
    ocaFactory::pointer factory;

    ocaObject::initialize();
    factory = ocaFactory::getSingleton();
    factory->makeCurrent();
    ocaContext = wglGetCurrentContext();
    if (!wglShareLists(ocaContext, glutContext)) {
	ocaRaiseError("Could not share context with glut.");
    }

    drawable1 = factory->makeDrawableBuffer(width, height, 4);
    drawable2 = factory->makeDrawableBuffer(width, height, 4);
    drawable3 = factory->makeDrawableBuffer(width, height, 4);
}

static void init_opengl()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClearColor(0, 0, 0, 0);
}

#if 0
static void init_menu()
{
    glutCreateMenu(menu);

    glutAddMenuEntry("Toggle Rotate",           MENU_TOGGLE_ROTATE);
    glutAddMenuEntry("-----------------------", MENU_NULL);
    glutAddMenuEntry("Toggle Show Frequencies", MENU_TOGGLE_SHOW_FREQUENCIES);
    glutAddMenuEntry("-----------------------", MENU_NULL);
    glutAddMenuEntry("No Filtering",            MENU_FILTER_NONE);
    glutAddMenuEntry("Low Pass Filter",         MENU_FILTER_LOWPASS);
    glutAddMenuEntry("High Pass Filter",        MENU_FILTER_HIGHPASS);
    glutAddMenuEntry("Band Pass Filter",        MENU_FILTER_BANDPASS);
    glutAddMenuEntry("Band Stop Filter",        MENU_FILTER_BANDSTOP);
    glutAddMenuEntry("Laplacian Filter",        MENU_FILTER_LAPLACIAN);

    glutAttachMenu(GLUT_LEFT_BUTTON);
    glutAttachMenu(GLUT_MIDDLE_BUTTON);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}
#endif

int main(int argc, char **argv)
{
    srand((unsigned int)time(NULL));

    try {
	init_glut(&argc, argv);

	glutSetWindow(perturbed_window);
	init_oca();
	init_opengl();
// 	init_menu();
	glutSetWindow(original_window);
	init_opengl();
// 	init_menu();

	load_image("C:/DOCUME~1/kmorel/MYDOCU~1/thesis/oca/src/examples/TexGen/slide.ppm");

	glutMainLoop();
    } catch (ocaError &error) {
	printf("Got oca error: %s\n", error.getMessage());
	return 1;
    }

    return 0;
}
