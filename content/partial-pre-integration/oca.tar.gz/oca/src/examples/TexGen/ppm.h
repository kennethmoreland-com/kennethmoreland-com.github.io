/* -*- c -*- */

#ifndef _ppm_h
#define _ppm_h

#ifdef __cplusplus
extern "C" {
#endif

/* Returned array contains image in RGB format.  Array allocated by malloc
 * and must be freed by calling application. */
unsigned char *ppm_load(const char *filename, int *widthp, int *heightp);

#ifdef __cplusplus
}
#endif

#endif /*_ppm_h*/
