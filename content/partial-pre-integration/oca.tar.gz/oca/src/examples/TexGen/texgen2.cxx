// -*- c++ -*- *******************************************************

#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include <algorithm>

#include <ocaFactory.h>
#include <ocaTimer.h>
#include <ocaError.h>
#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaProgramPassThrough.h>
#include <ocaProgramFFT2c.h>
#include <ocaProgramIFFT2c.h>
#include <ocaProgramFFT2cMult.h>
#include <ocaProgramFFT2cMagnitude.h>

#ifndef M_PI
#define M_PI		3.14159265358979323846
#define M_TWOPI         (M_PI * 2.0)
#endif
#define TWOPISQR	(M_TWOPI*M_TWOPI)

static int width = 512;
static int height = 512;

static ocaDrawableBuffer::pointer ocaDrawable1;
static ocaDrawableBuffer::pointer ocaDrawable2;

enum ShowFrequenciesStates { SHOW_FREQUENCIES_ON, SHOW_FREQUENCIES_OFF };
enum ColorChannelCorrelationStates { COLOR_CHANNELS_CORRELATED,
				     COLOR_CHANNELS_UNCORRELATED };
enum FilterStates { FILTER_OFF, FILTER_ON };
enum FilterType { FILTER_LOWPASS, FILTER_BANDPASS, FILTER_HIGHPASS };
static struct _state {
    ShowFrequenciesStates showFrequencies;
    ColorChannelCorrelationStates colorChannelCorrelation;
    FilterStates filter;
    FilterType type[3];
} state;

static ocaLookUpBuffer::pointer input;
static ocaLookUpBuffer::pointer filter;

const float LOWPASS_CUTOFF_RATIO = 0.025f;
const float HIGHPASS_CUTOFF_RATIO = 0.003125f;
const float BANDPASS_LOW_CUTOFF_RATIO = 0.00625f;
const float BANDPASS_HIGH_CUTOFF_RATIO = 0.125f;
const float BANDPASS_MIDBAND_RATIO
    = (BANDPASS_HIGH_CUTOFF_RATIO+BANDPASS_LOW_CUTOFF_RATIO)/2;
const float BANDPASS_WIDTH_RATIO
    = BANDPASS_HIGH_CUTOFF_RATIO-BANDPASS_LOW_CUTOFF_RATIO;
const float ABSOLUTE_HIGH_CUTOFF_RATIO = 0.25;

#define FLOAT_RAND(min, max)					\
    (((float)rand()/(float)RAND_MAX)*((max)-(min)) + (min))

#define NUM_GAUSSIAN_VALUES	12
static float gaussian_rand()
{
    double value = 0;
    for (int i = 0; i < NUM_GAUSSIAN_VALUES; i++) {
	value = value + FLOAT_RAND(-0.5, 0.5);
    }

    return (float)value;
}

static void replicateRealFrequencies(float *values, int w, int h)
{
    int x, y;
    for (y = 0; y < h/2; y++) {
	for (x = w/2+1; x < w; x++) {
	    values[4*(y*w+x) + 0] = values[4*(y*w+(w-x)) + 0];
	    values[4*(y*w+x) + 1] = values[4*(y*w+(w-x)) + 1];
	    values[4*(y*w+x) + 2] = values[4*(y*w+(w-x)) + 2];
	    values[4*(y*w+x) + 3] = values[4*(y*w+(w-x)) + 3];
	}
    }
    for (y = h/2+1; y < h; y++) {
	for (x = 0; x < w; x++) {
	    values[4*(y*w+x) + 0] = values[4*((h-y)*w+x) + 0];
	    values[4*(y*w+x) + 1] = values[4*((h-y)*w+x) + 1];
	    values[4*(y*w+x) + 2] = values[4*((h-y)*w+x) + 2];
	    values[4*(y*w+x) + 3] = values[4*((h-y)*w+x) + 3];
	}
    }
}

static void build_inputs()
{
    int x, y, k;

  // Make new sizes for filters.
#define MAGSQR(x, y)	((x)*(x) + (y)*(y))
    float *realfreq = new float[4*width*height];
    float *compressedfreq = new float[4*width*height];
    float *f;
    float twoalpha;
    float bias;
    float offset;

  // Make random input.
    bias = 1.0f/(sqrt(width*height));
    offset = bias/2;
    for (k = 0; k < 4; k++) {
	compressedfreq[k] = 0.5;
	compressedfreq[4*(height/2)*width + k] = bias;
	compressedfreq[4*(width/2) + k] = bias;
	compressedfreq[4*((height/2)*width + width/2) + k] = bias;
    }
    for (y = 1; y < height/2; y++) {
	float angle;
	for (k = 0; k < 4; k++) {
	    if (   (state.colorChannelCorrelation==COLOR_CHANNELS_UNCORRELATED)
		|| (k == 0) ) {
		angle = FLOAT_RAND(-1,1)*M_PI;
	    }
	    compressedfreq[4*y*width + k] = bias*cos(angle);
	    compressedfreq[4*(height-y)*width + k] = bias*sin(angle);
	}
	for (k = 0; k < 4; k++) {
	    if (   (state.colorChannelCorrelation==COLOR_CHANNELS_UNCORRELATED)
		|| (k == 0) ) {
		angle = FLOAT_RAND(-1,1)*M_PI;
	    }
	    compressedfreq[4*(y*width + width/2) + k] = bias*cos(angle);
	    compressedfreq[4*((height-y)*width+width/2) + k] = bias*sin(angle);
	}
    }
    for (y = 0; y < height; y++) {
	for (x = 1; x < width/2; x++) {
	    float angle;
	    for (k = 0; k < 4; k++) {
		if (   (   state.colorChannelCorrelation
			== COLOR_CHANNELS_UNCORRELATED)
		    || (k == 0) ) {
		    angle = FLOAT_RAND(-1,1)*M_PI;
		}
		compressedfreq[4*(y*width + x) + k] = bias*cos(angle);
		compressedfreq[4*(y*width + width-x) + k] = bias*sin(angle);
	    }
	}
    }
    input->setData(compressedfreq, width, height, 4);

    int w = width;
    int h = height;

    for (k = 0; k < 3; k++) {
	if (state.type[k] == FILTER_LOWPASS) {
	  // Make lowpass filter.
#if 1
	    twoalpha = LOWPASS_CUTOFF_RATIO*LOWPASS_CUTOFF_RATIO*w*w/0.693147;
	    f = realfreq;
	    for (y = 0; y < h/2+1; y++) {
		for (x = 0; x < w/2+1; x++) {
		    float radiussqr = x*x + y*y;
		    float value = (float)exp(-radiussqr/twoalpha);
		    f[k] = value;
		    f += 4;
		}
		f += 4*(w/2-1);
	    }
#else
	    float cutoff = LOWPASS_CUTOFF_RATIO*LOWPASS_CUTOFF_RATIO*w*w;
	    f = realfreq;
	    for (y = 0; y < h/2+1; y++) {
		for (x = 0; x < w/2+1; x++) {
		    float radiussqr = x*x + y*y;
		    float value;
		    if (radiussqr < cutoff) {
			value = 1;
		    } else {
			value = 0;
		    }
		    f[k] = value;
		    f += 4;
		}
		f += 4*(w/2-1);
	    }
#endif
	}

	if (state.type[k] == FILTER_HIGHPASS) {
	  // Make highpass filter.
#if 0
	    twoalpha = HIGHPASS_CUTOFF_RATIO*HIGHPASS_CUTOFF_RATIO*w*w/0.693147;
	    f = realfreq;
	    for (y = 0; y < h/2+1; y++) {
		for (x = 0; x < w/2+1; x++) {
		    float radiussqr = x*x + y*y;
		    float value = 1 - (float)exp(-radiussqr/twoalpha);
		    f[k] = value;
		    f += 4;
		}
		f += 4*(w/2-1);
	    }
#else
	    float cutoff = HIGHPASS_CUTOFF_RATIO*HIGHPASS_CUTOFF_RATIO*w*w;
	    float highcutoff = ABSOLUTE_HIGH_CUTOFF_RATIO*ABSOLUTE_HIGH_CUTOFF_RATIO*w*w;
	    f = realfreq;
	    for (y = 0; y < h/2+1; y++) {
		for (x = 0; x < w/2+1; x++) {
		    float radiussqr = x*x + y*y;
		    float value;
		    if ((radiussqr > cutoff) && (radiussqr < highcutoff)) {
			value = 1;
		    } else {
			value = 0;
		    }
		    f[k] = value;
		    f += 4;
		}
		f += 4*(w/2-1);
	    }
#endif
	}

	if (state.type[k] == FILTER_BANDPASS) {
	  // Make bandpass filter.
#if 0
	    twoalpha = BANDPASS_WIDTH_RATIO*BANDPASS_WIDTH_RATIO*w*w/(2*0.693147);
	    f = realfreq;
	    for (y = 0; y < h/2+1; y++) {
		for (x = 0; x < w/2+1; x++) {
		    float radiussqr = x*x + y*y - BANDPASS_MIDBAND_RATIO*BANDPASS_MIDBAND_RATIO*w*w;
		    if (radiussqr < 0) radiussqr = -radiussqr;
		    float value;
		    value = (float)exp(-radiussqr/twoalpha);
		    f[k] = value;
		    f += 4;
		}
		f += 4*(w/2-1);
	    }
#else
	    f = realfreq;
	    float lowradsqr = BANDPASS_LOW_CUTOFF_RATIO*BANDPASS_LOW_CUTOFF_RATIO*w*w;
	    float highradsqr =BANDPASS_HIGH_CUTOFF_RATIO*BANDPASS_HIGH_CUTOFF_RATIO*w*w;
	    for (y = 0; y < h/2+1; y++) {
		for (x = 0; x < w/2+1; x++) {
		    float radiussqr = x*x + y*y;
		    if ((radiussqr > lowradsqr) && (radiussqr < highradsqr)) {
			f[k] = 1;
		    } else {
			f[k] = 0;
		    }
		    f += 4;
		}
		f += 4*(w/2-1);
	    }
#endif
	}
    }
    f = realfreq;
    for (y = 0; y < h/2+1; y++) {
	for (x = 0; x < w/2+1; x++) {
	    f[3] = 1;
	    f += 4;
	}
	f += 4*(w/2-1);
    }

    replicateRealFrequencies(realfreq, w, h);
    ocaProgramFFT2c::compress(w, h, 4, compressedfreq, realfreq);
    filter->setData(compressedfreq, w, h, 4);

    delete[] realfreq;
    delete[] compressedfreq;
}

static void reshape(int w, int h)
{
    int logsize;

  // Scale image down to nearest powers of 2.
    for (logsize = 0; w > 1; w >>= 1, logsize++);
    for (; logsize > 0; w <<= 1, logsize--);

    for (logsize = 0; h > 1; h >>= 1, logsize++);
    for (; logsize > 0; h <<= 1, logsize--);

  // Set up viewport to draw smaller image correctly.
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -(float)h/w, (float)h/w, -1.5, 1.5);

  // Make new sizes for oca drawable buffers.
    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawable1 = factory->makeDrawableBuffer(w, h, 4);
    ocaDrawable2 = factory->makeDrawableBuffer(w, h, 4);

    width = w;
    height = h;

    build_inputs();

    printf("New size: %dx%d\n", w, h);
}

static void quit()
{
    ocaObject::finalize();
    exit(0);
}

static void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
      case 'q':
      case 'Q':
	  quit();
	  break;
    }
}

enum MenuStates {
    MENU_SHOW_FREQUENCIES_OFF,
    MENU_SHOW_FREQUENCIES_ON,
    MENU_CORRELATE_COLOR_CHANNELS,
    MENU_UNCORRELATE_COLOR_CHANNELS,
    MENU_FILTER_NONE,
    MENU_FILTER_R_LOWPASS,
    MENU_FILTER_R_HIGHPASS,
    MENU_FILTER_R_BANDPASS,
    MENU_FILTER_G_LOWPASS,
    MENU_FILTER_G_HIGHPASS,
    MENU_FILTER_G_BANDPASS,
    MENU_FILTER_B_LOWPASS,
    MENU_FILTER_B_HIGHPASS,
    MENU_FILTER_B_BANDPASS,
    MENU_NULL
};
static void menu(int value)
{
    switch (value) {
      case MENU_SHOW_FREQUENCIES_OFF:
	  state.showFrequencies = SHOW_FREQUENCIES_OFF;
	  break;
      case MENU_SHOW_FREQUENCIES_ON:
	  state.showFrequencies = SHOW_FREQUENCIES_ON;
	  break;
      case MENU_FILTER_NONE:
	  state.filter = FILTER_OFF;
	  break;
      case MENU_CORRELATE_COLOR_CHANNELS:
	  state.colorChannelCorrelation = COLOR_CHANNELS_CORRELATED;
	  build_inputs();
	  break;
      case MENU_UNCORRELATE_COLOR_CHANNELS:
	  state.colorChannelCorrelation = COLOR_CHANNELS_UNCORRELATED;
	  build_inputs();
	  break;
      case MENU_FILTER_R_LOWPASS:
	  state.filter = FILTER_ON;
	  state.type[0] = FILTER_LOWPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_R_HIGHPASS:
	  state.filter = FILTER_ON;
	  state.type[0] = FILTER_HIGHPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_R_BANDPASS:
	  state.filter = FILTER_ON;
	  state.type[0] = FILTER_BANDPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_G_LOWPASS:
	  state.filter = FILTER_ON;
	  state.type[1] = FILTER_LOWPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_G_HIGHPASS:
	  state.filter = FILTER_ON;
	  state.type[1] = FILTER_HIGHPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_G_BANDPASS:
	  state.filter = FILTER_ON;
	  state.type[1] = FILTER_BANDPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_B_LOWPASS:
	  state.filter = FILTER_ON;
	  state.type[2] = FILTER_LOWPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_B_HIGHPASS:
	  state.filter = FILTER_ON;
	  state.type[2] = FILTER_HIGHPASS;
	  build_inputs();
	  break;
      case MENU_FILTER_B_BANDPASS:
	  state.filter = FILTER_ON;
	  state.type[2] = FILTER_BANDPASS;
	  build_inputs();
	  break;
    }

    glutPostRedisplay();
}

static void init_oca()
{
    int glutwin = glutGetWindow();
    HGLRC glutContext = wglGetCurrentContext();
    HGLRC ocaContext;
    ocaFactory::pointer factory;

    ocaObject::initialize();
    factory = ocaFactory::getSingleton();
    factory->makeCurrent();
    ocaContext = wglGetCurrentContext();
    if (!wglShareLists(ocaContext, glutContext)) {
	ocaRaiseError("Could not share context with glut.");
    }

    filter = factory->makeLookUpBuffer();
    input = factory->makeLookUpBuffer();

    glutSetWindow(glutwin);
}

static void init_opengl()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClearColor(0, 0, 0, 0);
}

static void init_menu()
{
    glutCreateMenu(menu);

    glutAddMenuEntry("Show Frequencies Off",       MENU_SHOW_FREQUENCIES_OFF);
    glutAddMenuEntry("Show Frequencies On",        MENU_SHOW_FREQUENCIES_ON);
    glutAddMenuEntry("--------------------------", MENU_NULL);
    glutAddMenuEntry("Correlate Color Channels",
		     MENU_CORRELATE_COLOR_CHANNELS);
    glutAddMenuEntry("Uncorrelate Color Channels",
		     MENU_UNCORRELATE_COLOR_CHANNELS);
    glutAddMenuEntry("-----------------------",    MENU_NULL);
    glutAddMenuEntry("No Filtering",               MENU_FILTER_NONE);
    glutAddMenuEntry("-----------------------",    MENU_NULL);
    glutAddMenuEntry("Red Low Pass Filter",        MENU_FILTER_R_LOWPASS);
    glutAddMenuEntry("Red High Pass Filter",       MENU_FILTER_R_HIGHPASS);
    glutAddMenuEntry("Red Band Pass Filter",       MENU_FILTER_R_BANDPASS);
    glutAddMenuEntry("-----------------------",    MENU_NULL);
    glutAddMenuEntry("Green Low Pass Filter",      MENU_FILTER_G_LOWPASS);
    glutAddMenuEntry("Green High Pass Filter",     MENU_FILTER_G_HIGHPASS);
    glutAddMenuEntry("Green Band Pass Filter",     MENU_FILTER_G_BANDPASS);
    glutAddMenuEntry("-----------------------",    MENU_NULL);
    glutAddMenuEntry("Blue Low Pass Filter",       MENU_FILTER_B_LOWPASS);
    glutAddMenuEntry("Blue High Pass Filter",      MENU_FILTER_B_HIGHPASS);
    glutAddMenuEntry("Blue Band Pass Filter",      MENU_FILTER_B_BANDPASS);

    glutAttachMenu(GLUT_LEFT_BUTTON);
    glutAttachMenu(GLUT_MIDDLE_BUTTON);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

static void draw()
{
    int glutWindow = glutGetWindow();

    glClear(GL_COLOR_BUFFER_BIT);

    ocaLookUpBuffer::pointer output = input;

    ocaDrawableBuffer::pointer lastResult = ocaDrawable1;
    ocaDrawableBuffer::pointer scratch = ocaDrawable2;

    if (state.filter == FILTER_ON) {
	ocaProgramFFT2cMult::getSingleton()
	    ->execute(input, filter, lastResult);
      // I shouldn't have to do this.  Is there a bug in the driver?
	scratch->copy(ocaCast<ocaBuffer>(lastResult));
	std::swap(lastResult, scratch);
    } else {
	lastResult->copy(ocaCast<ocaBuffer>(input));
    }

    if (state.showFrequencies == SHOW_FREQUENCIES_ON) {
      // Show the magnitudes.
	ocaProgramFFT2cMagnitude::getSingleton()
	    ->execute(lastResult->getSharedLookUpBuffer(), scratch);
	lastResult->releaseLookUpBuffer();
	lastResult = scratch;
    } else {
      // Perform the IFFT.
	ocaProgramIFFT2c::getSingleton()->execute(lastResult, scratch,
						  lastResult, scratch);
    }

    float *data = new float[width*height*4];
    lastResult->getData(data);
    float min, max;
    min = max = data[0];
    for (int i = 1; i < width*height*4; i++) {
	if (min > data[i]) min = data[i];
	if (max < data[i]) max = data[i];
    }
    printf("Min %f, max %f\n", min, max);

  // Get the final result.
    output = lastResult->getSharedLookUpBuffer();

  // Copy image back into buffer.
    glutSetWindow(glutWindow);
    ocaProgramPassThrough::getSingleton()->execute(output);

  // Release the rendered texture.
    lastResult->releaseLookUpBuffer();

    glutSwapBuffers();

    printf("Finished draw.\n");
}

int main(int argc, char **argv)
{
    try {
	glutInit(&argc, argv);
	glutInitWindowSize(width, height);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

	state.showFrequencies = SHOW_FREQUENCIES_OFF;
	state.colorChannelCorrelation = COLOR_CHANNELS_CORRELATED;
	state.filter = FILTER_OFF;
	state.type[0] = FILTER_LOWPASS;
	state.type[1] = FILTER_LOWPASS;
	state.type[2] = FILTER_LOWPASS;

	glutCreateWindow("FFT Demonstration");
	init_oca();
	init_opengl();
	init_menu();

	glutReshapeFunc(reshape);
	glutDisplayFunc(draw);
	glutKeyboardFunc(keyboard);

	glutMainLoop();
    } catch (ocaError &error) {
	printf("Got oca error: %s\n", error.getMessage());
	return 1;
    }

    return 0;
}
