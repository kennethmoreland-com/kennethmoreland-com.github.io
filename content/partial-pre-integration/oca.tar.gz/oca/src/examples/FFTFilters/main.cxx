// -*- c++ -*- *******************************************************

#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include <algorithm>

#include <ocaFactory.h>
#include <ocaTimer.h>
#include <ocaError.h>
#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaProgramPassThrough.h>
#include <ocaProgramFFT2c.h>
#include <ocaProgramIFFT2c.h>
#include <ocaProgramFFT2cMult.h>
#include <ocaProgramFFT2cMagnitude.h>

#ifndef M_PI
#define M_PI		3.14159265358979323846
#define M_TWOPI         (M_PI * 2.0)
#endif
#define TWOPISQR	(M_TWOPI*M_TWOPI)

static int width = 512;
static int height = 512;

static ocaLookUpBuffer::pointer ocaSource;
static ocaDrawableBuffer::pointer ocaDrawable1;
static ocaDrawableBuffer::pointer ocaDrawable2;

static ocaTimer::pointer timer;
static int framecount;

enum RotateStates { ROTATE_OFF, ROTATE_ON };
enum ShowFrequenciesStates { SHOW_FREQUENCIES_ON, SHOW_FREQUENCIES_OFF };
enum FilterStates { FILTER_OFF, FILTER_ON };
static struct _state {
    RotateStates rotate;
    ShowFrequenciesStates showFrequencies;
    FilterStates filter;
    ocaLookUpBuffer::pointer frequencyResponse;
} state;

static ocaLookUpBuffer::pointer lowpassFrequencyResponse;
static ocaLookUpBuffer::pointer highpassFrequencyResponse;
static ocaLookUpBuffer::pointer bandpassFrequencyResponse;
static ocaLookUpBuffer::pointer bandstopFrequencyResponse;
static ocaLookUpBuffer::pointer laplacianFrequencyResponse;
static ocaLookUpBuffer::pointer motionFrequencyResponse;

const float LOWPASS_CUTOFF_RATIO = 0.02f;
const float HIGHPASS_CUTOFF_RATIO = 0.02f;
const float BANDPASS_LOW_CUTOFF_RATIO = 0.05f;
const float BANDPASS_HIGH_CUTOFF_RATIO = 0.25f;
const float BANDPASS_MIDBAND_RATIO
    = (BANDPASS_HIGH_CUTOFF_RATIO+BANDPASS_LOW_CUTOFF_RATIO)/2;
const float BANDPASS_WIDTH_RATIO
    = BANDPASS_HIGH_CUTOFF_RATIO-BANDPASS_LOW_CUTOFF_RATIO;

static void resetTimer()
{
    framecount = 0;
    timer->start();
}

static void replicateRealFrequencies(float *values, int w, int h)
{
    int x, y;
    for (y = 0; y < h/2; y++) {
	for (x = w/2+1; x < w; x++) {
	    values[4*(y*w+x) + 0] = values[4*(y*w+(w-x)) + 0];
	    values[4*(y*w+x) + 1] = values[4*(y*w+(w-x)) + 1];
	    values[4*(y*w+x) + 2] = values[4*(y*w+(w-x)) + 2];
	    values[4*(y*w+x) + 3] = values[4*(y*w+(w-x)) + 3];
	}
    }
    for (y = h/2+1; y < h; y++) {
	for (x = 0; x < w; x++) {
	    values[4*(y*w+x) + 0] = values[4*((h-y)*w+x) + 0];
	    values[4*(y*w+x) + 1] = values[4*((h-y)*w+x) + 1];
	    values[4*(y*w+x) + 2] = values[4*((h-y)*w+x) + 2];
	    values[4*(y*w+x) + 3] = values[4*((h-y)*w+x) + 3];
	}
    }
}

static void reshape(int w, int h)
{
    int x, y;
    int logsize;

  // Scale image down to nearest powers of 2.
    for (logsize = 0; w > 1; w >>= 1, logsize++);
    for (; logsize > 0; w <<= 1, logsize--);

    for (logsize = 0; h > 1; h >>= 1, logsize++);
    for (; logsize > 0; h <<= 1, logsize--);

  // Set up viewport to draw smaller image correctly.
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -(float)h/w, (float)h/w, -1.5, 1.5);

  // Make new sizes for oca drawable buffers.
    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawable1 = factory->makeDrawableBuffer(w, h, 4);
    ocaDrawable2 = factory->makeDrawableBuffer(w, h, 4);
    ocaSource->setSize(w, h, 4);

  // Make new sizes for filters.
#define MAGSQR(x, y)	((x)*(x) + (y)*(y))
    float *realfreq = new float[4*w*h];
    float *compressedfreq = new float[4*w*h];
    float *f;
    float twoalpha;

  // Make lowpass filter.
    twoalpha = LOWPASS_CUTOFF_RATIO*LOWPASS_CUTOFF_RATIO*w*w/0.693147;
    f = realfreq;
    for (y = 0; y < h/2+1; y++) {
	for (x = 0; x < w/2+1; x++) {
	    float radiussqr = x*x + y*y;
	    float value = (float)exp(-radiussqr/twoalpha);
	    f[0] = value;
	    f[1] = value;
	    f[2] = value;
	    f[3] = value;
	    f += 4;
	}
	f += 4*(w/2-1);
    }
    replicateRealFrequencies(realfreq, w, h);
    ocaProgramFFT2c::compress(w, h, 4, compressedfreq, realfreq);
    lowpassFrequencyResponse->setData(compressedfreq, w, h, 4);

  // Make highpass filter.
    twoalpha = HIGHPASS_CUTOFF_RATIO*HIGHPASS_CUTOFF_RATIO*w*w/0.693147;
    f = realfreq;
    for (y = 0; y < h/2+1; y++) {
	for (x = 0; x < w/2+1; x++) {
	    float radiussqr = x*x + y*y;
	    float value = 1 - (float)exp(-radiussqr/twoalpha);
	    f[0] = value;
	    f[1] = value;
	    f[2] = value;
	    f[3] = value;
	    f += 4;
	}
	f += 4*(w/2-1);
    }
    replicateRealFrequencies(realfreq, w, h);
    ocaProgramFFT2c::compress(w, h, 4, compressedfreq, realfreq);
    highpassFrequencyResponse->setData(compressedfreq, w, h, 4);

  // Make bandpass filter.
#if 0
    twoalpha = BANDPASS_WIDTH_RATIO*BANDPASS_WIDTH_RATIO*w*w/(2*0.693147);
    f = realfreq;
    for (y = 0; y < h/2+1; y++) {
	for (x = 0; x < w/2+1; x++) {
	    float radiussqr = x*x + y*y - BANDPASS_MIDBAND_RATIO*BANDPASS_MIDBAND_RATIO*w*w;
	    if (radiussqr < 0) radiussqr = -radiussqr;
	    float value;
	    value = (float)exp(-radiussqr/twoalpha);
		
	    f[0] = value;
	    f[1] = value;
	    f[2] = value;
	    f[3] = value;
	    f += 4;
	}
	f += 4*(w/2-1);
    }
#else
    f = realfreq;
    float lowradsqr = BANDPASS_LOW_CUTOFF_RATIO*BANDPASS_LOW_CUTOFF_RATIO*w*w;
    float highradsqr =BANDPASS_HIGH_CUTOFF_RATIO*BANDPASS_HIGH_CUTOFF_RATIO*w*w;
    for (y = 0; y < h/2+1; y++) {
	for (x = 0; x < w/2+1; x++) {
	    float radiussqr = x*x + y*y;
	    if ((radiussqr > lowradsqr) && (radiussqr < highradsqr)) {
		f[0] = 1;
		f[1] = 1;
		f[2] = 1;
		f[3] = 1;
	    } else {
		f[0] = 0;
		f[1] = 0;
		f[2] = 0;
		f[3] = 0;
	    }
	    f += 4;
	}
	f += 4*(w/2-1);
    }
#endif
    replicateRealFrequencies(realfreq, w, h);
    ocaProgramFFT2c::compress(w, h, 4, compressedfreq, realfreq);
    bandpassFrequencyResponse->setData(compressedfreq, w, h, 4);

  // Make bandstop filter.
    f = realfreq;
    for (x = 0; x < w*h; x++) {
	f[0] = 1 - f[0];
	f[1] = 1 - f[1];
	f[2] = 1 - f[2];
	f[3] = 1 - f[3];
	f += 4;
    }
    ocaProgramFFT2c::compress(w, h, 4, compressedfreq, realfreq);
    bandstopFrequencyResponse->setData(compressedfreq, w, h, 4);

  // Make Laplacian filter.
    f = realfreq;
    for (y = 0; y < h/2+1; y++) {
	for (x = 0; x < w/2+1; x++) {
	    float u = (float)x/w;
	    float v = (float)y/h;
	    f[0] = -TWOPISQR*(u*u + v*v);
	    f[1] = -TWOPISQR*(u*u + v*v);
	    f[2] = -TWOPISQR*(u*u + v*v);
	    f[3] = -TWOPISQR*(u*u + v*v);
	    f += 4;
	}
	f += 4*(w/2-1);
    }
    replicateRealFrequencies(realfreq, w, h);
    ocaProgramFFT2c::compress(w, h, 4, compressedfreq, realfreq);
    laplacianFrequencyResponse->setData(compressedfreq, w, h, 4);

  // Make NPR blur
    f = realfreq;	// Actually, just impulse in spatial domain.
//     float bias = w*h/(60.0f/2);
//     for (x = 0; x < 60; x++) {
// 	f[0] = bias*(60.0f-x)/60.0f;
// 	f[1] = bias*(60.0f-x)/60.0f;
// 	f[2] = bias*(60.0f-x)/60.0f;
// 	f[3] = bias*(60.0f-x)/60.0f;
// 	f += 4;
//     }
//     for ( ; x < w; x++) {
// 	f[0] = 0;
// 	f[1] = 0;
// 	f[2] = 0;
// 	f[3] = 0;
// 	f += 4;
//     }
#define BLUR_LENGTH_INHIBIT	16.0f
    float bias = (float)h*BLUR_LENGTH_INHIBIT/(1 - (float)exp(-BLUR_LENGTH_INHIBIT));
    for (x = 0; x < w; x++) {
	float value = (float)exp(-BLUR_LENGTH_INHIBIT*(float)(w-x)/w)*bias;
	f[0] = value;
	f[1] = value;
	f[2] = value;
	f[3] = value;
	f += 4;
    }
    for (y = 1; y < h; y++) {
	for (x = 0; x < w; x++) {
	    f[0] = 0;
	    f[1] = 0;
	    f[2] = 0;
	    f[3] = 0;
	    f += 4;
	}
    }
    motionFrequencyResponse->setData(realfreq, w, h, 4);
    ocaProgramFFT2c::getSingleton()->execute(motionFrequencyResponse,
					     ocaDrawable1, ocaDrawable2);
    motionFrequencyResponse->copy(ocaCast<ocaBuffer>(ocaDrawable1));

    delete[] realfreq;

    width = w;
    height = h;

    printf("New size: %dx%d\n", w, h);

    resetTimer();
}

static void idle()
{
    if (state.rotate == ROTATE_ON) {
	glutPostRedisplay();
    }
}

static void quit()
{
    ocaObject::finalize();
    exit(0);
}

static void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
      case 'q':
      case 'Q':
	  quit();
	  break;
    }
}

enum MenuStates {
    MENU_TOGGLE_ROTATE,
    MENU_TOGGLE_SHOW_FREQUENCIES,
    MENU_FILTER_NONE,
    MENU_FILTER_LOWPASS,
    MENU_FILTER_HIGHPASS,
    MENU_FILTER_BANDPASS,
    MENU_FILTER_BANDSTOP,
    MENU_FILTER_LAPLACIAN,
    MENU_FILTER_MOTION,
    MENU_NULL
};
static void menu(int value)
{
    switch (value) {
      case MENU_TOGGLE_ROTATE:
	  state.rotate = (state.rotate == ROTATE_OFF) ? ROTATE_ON : ROTATE_OFF;
	  break;
      case MENU_TOGGLE_SHOW_FREQUENCIES:
	  state.showFrequencies =
	      (state.showFrequencies == SHOW_FREQUENCIES_OFF)
	      ? SHOW_FREQUENCIES_ON : SHOW_FREQUENCIES_OFF;
	  break;
      case MENU_FILTER_NONE:
	  state.filter = FILTER_OFF;
	  break;
      case MENU_FILTER_LOWPASS:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = lowpassFrequencyResponse;
	  break;
      case MENU_FILTER_HIGHPASS:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = highpassFrequencyResponse;
	  break;
      case MENU_FILTER_BANDPASS:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = bandpassFrequencyResponse;
	  break;
      case MENU_FILTER_BANDSTOP:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = bandstopFrequencyResponse;
	  break;
      case MENU_FILTER_LAPLACIAN:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = laplacianFrequencyResponse;
	  break;
      case MENU_FILTER_MOTION:
	  state.filter = FILTER_ON;
	  state.frequencyResponse = motionFrequencyResponse;
	  break;
    }

    resetTimer();
    glutPostRedisplay();
}

static float light_ambient[] = { 0.0, 0.0, 1.0, 1.0 };
static float light_diffuse[] = { 1.0, 0.5, 0.0, 1.0 };
static float light_specular[] = {1.0, 1.0, 1.0, 1.0 };
static float light_position[] = { -1.0, 1.0, 1.0, 0.0 };

static float material_ambient[] = { 0.6, 0.6, 0.6, 1.0};
static float material_diffuse[] = { 1.0, 1.0, 1.0, 1.0};
static float material_specular[] = { 1.0, 1.0, 1.0, 1.0};
static float material_shininess[] = { 150.0 };

static void init_oca()
{
    int glutwin = glutGetWindow();
    HGLRC glutContext = wglGetCurrentContext();
    HGLRC ocaContext;
    ocaFactory::pointer factory;

    ocaObject::initialize();
    factory = ocaFactory::getSingleton();
    factory->makeCurrent();
    ocaContext = wglGetCurrentContext();
    if (!wglShareLists(ocaContext, glutContext)) {
	ocaRaiseError("Could not share context with glut.");
    }

    ocaSource = factory->makeLookUpBuffer();

    lowpassFrequencyResponse = factory->makeLookUpBuffer();
    highpassFrequencyResponse = factory->makeLookUpBuffer();
    bandpassFrequencyResponse = factory->makeLookUpBuffer();
    bandstopFrequencyResponse = factory->makeLookUpBuffer();
    laplacianFrequencyResponse = factory->makeLookUpBuffer();
    motionFrequencyResponse = factory->makeLookUpBuffer();

    glutSetWindow(glutwin);

    timer = ocaTimer::New();
}

static void init_opengl()
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, material_ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, material_diffuse);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, material_specular);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, material_shininess);

//     glClearColor(0, 0, 0, 0);
    glClearColor(1, 1, 1, 1);
}

static void init_menu()
{
    glutCreateMenu(menu);

    glutAddMenuEntry("Toggle Rotate",           MENU_TOGGLE_ROTATE);
    glutAddMenuEntry("-----------------------", MENU_NULL);
    glutAddMenuEntry("Toggle Show Frequencies", MENU_TOGGLE_SHOW_FREQUENCIES);
    glutAddMenuEntry("-----------------------", MENU_NULL);
    glutAddMenuEntry("No Filtering",            MENU_FILTER_NONE);
    glutAddMenuEntry("Low Pass Filter",         MENU_FILTER_LOWPASS);
    glutAddMenuEntry("High Pass Filter",        MENU_FILTER_HIGHPASS);
    glutAddMenuEntry("Band Pass Filter",        MENU_FILTER_BANDPASS);
    glutAddMenuEntry("Band Stop Filter",        MENU_FILTER_BANDSTOP);
    glutAddMenuEntry("Laplacian Filter",        MENU_FILTER_LAPLACIAN);
    glutAddMenuEntry("Motion Blur Filter",      MENU_FILTER_MOTION);

    glutAttachMenu(GLUT_LEFT_BUTTON);
    glutAttachMenu(GLUT_MIDDLE_BUTTON);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

static void draw()
{
    int glutWindow = glutGetWindow();

    if (state.rotate == ROTATE_ON) {
	glMatrixMode(GL_MODELVIEW);
	glRotatef(5, 0.3, 1, 0);
    }

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnable(GL_DEPTH_TEST);
    glutSolidTeapot(0.75);
    glDisable(GL_DEPTH_TEST);

    if (   (state.showFrequencies == SHOW_FREQUENCIES_ON)
	|| (state.filter == FILTER_ON) ) {
      // Grab data into oca texture.
	ocaSource->bind();
	glCopyTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGBA,
			 0, 0, width, height, 0);

	ocaDrawableBuffer::pointer lastResult = ocaDrawable1;
	ocaDrawableBuffer::pointer scratch = ocaDrawable2;

      // Perform the FFT.
	ocaProgramFFT2c::getSingleton()->execute(ocaSource,
						 lastResult, scratch);

	if (state.filter == FILTER_ON) {
	    ocaProgramFFT2cMult::getSingleton()
		->execute(lastResult->getSharedLookUpBuffer(),
			  state.frequencyResponse,
			  scratch);
	    lastResult->releaseLookUpBuffer();
// 	    scratch->copy(ocaCast<ocaBuffer>(state.frequencyResponse));
	    std::swap(lastResult, scratch);
	  // I shouldn't have to do this.  Is there a bug in the driver?
	    scratch->copy(ocaCast<ocaBuffer>(lastResult));
	    std::swap(lastResult, scratch);
	}

	if (state.showFrequencies == SHOW_FREQUENCIES_ON) {
	  // Show the magnitudes.
	    ocaProgramFFT2cMagnitude::getSingleton()
		->execute(lastResult->getSharedLookUpBuffer(), scratch);
	    lastResult->releaseLookUpBuffer();
	    lastResult = scratch;
	} else {
	  // Perform the IFFT.
	    ocaProgramIFFT2c::getSingleton()->execute(lastResult, scratch,
						      lastResult, scratch);
// 	    lastResult = ocaProgramIFFT2c::getSingleton()->execute(lastResult,
// 								   scratch);
	}

      // Get the final result.
	ocaLookUpBuffer::pointer result = lastResult->getSharedLookUpBuffer();

      // Copy image back into buffer.
	glutSetWindow(glutWindow);
	ocaProgramPassThrough::getSingleton()->execute(result);

      // Release the rendered texture.
	lastResult->releaseLookUpBuffer();
    }

    glutSwapBuffers();

    framecount++;
    timer->stop();
    if (timer->getElapsedTime() > 5.0) {
	glFinish();
	timer->stop();
	printf("Frame time = %f; Pixel time = %g\n",
	       timer->getElapsedTime()/framecount,
	       timer->getElapsedTime()/(framecount*width*height));
	resetTimer();
    }
}

int main(int argc, char **argv)
{
    try {
	glutInit(&argc, argv);
	glutInitWindowSize(width, height);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

	state.rotate = ROTATE_OFF;
	state.showFrequencies = SHOW_FREQUENCIES_OFF;
	state.filter = FILTER_OFF;

	glutCreateWindow("FFT Demonstration");
	init_oca();
	init_opengl();
	init_menu();

	glutReshapeFunc(reshape);
	glutIdleFunc(idle);
	glutDisplayFunc(draw);
	glutKeyboardFunc(keyboard);

	glutMainLoop();
    } catch (ocaError &error) {
	printf("Got oca error: %s\n", error.getMessage());
	return 1;
    }

    return 0;
}
