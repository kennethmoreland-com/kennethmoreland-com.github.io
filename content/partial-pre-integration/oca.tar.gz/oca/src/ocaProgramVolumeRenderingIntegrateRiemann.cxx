// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramVolumeRenderingIntegrateRiemann.cxx,v 1.2 2003-09-30 19:21:37 kmorel Exp $

#include "ocaProgramVolumeRenderingIntegrateRiemann.h"

#include "ocaCgError.h"

#define DECLARE_RIEMANN_PROGRAM(pieces)					\
static const char *Riemann ## pieces ##Args[] = { "-DPIECES=" #pieces, NULL };\
ocaProgramVolumeRenderingIntegrateRiemann ## pieces			\
    ::ocaProgramVolumeRenderingIntegrateRiemann ## pieces()		\
{									\
    this->loadProgram("vri_riemann.cg",					\
		      "VolumeRenderingIntegrateRiemannVert",		\
		      "VolumeRenderingIntegrateRiemannFrag",		\
		      Riemann ## pieces ## Args);			\
}									\
ocaProgramVolumeRenderingIntegrateRiemann ## pieces			\
    ::~ocaProgramVolumeRenderingIntegrateRiemann ## pieces()		\
{									\
}

#if 0
DECLARE_RIEMANN_PROGRAM(2);
#else
static const char *Riemann2Args[] = { "-DPIECES=2", NULL };
ocaProgramVolumeRenderingIntegrateRiemann2
    ::ocaProgramVolumeRenderingIntegrateRiemann2()
{
    this->fragProfile = CG_PROFILE_FP30;

    this->loadProgram("vri_riemann.cg",
		      "VolumeRenderingIntegrateRiemannVert",
		      "VolumeRenderingIntegrateRiemannFrag",
		      Riemann2Args);

    cgDestroyProgram(this->fragProgram);
    std::string fullFilename = ocaProgram::sourceDirectory + "vri_riemann2.fp";
    try {
	this->fragProgram = cgCreateProgramFromFile(this->programContext,
						    CG_OBJECT,
						    fullFilename.c_str(),
						    this->fragProfile,
						    "VolumeRenderingIntegrateRiemannFrag",
						    NULL);
	cgGLLoadProgram(this->fragProgram);
	this->Incoming = cgGetNamedParameter(this->fragProgram, "Incoming");
    } catch (ocaCgError &cgError) {
	throw ocaCgError(cgError.getError(), this->programContext);
    }
}
ocaProgramVolumeRenderingIntegrateRiemann2
    ::~ocaProgramVolumeRenderingIntegrateRiemann2()
{
}
#endif

DECLARE_RIEMANN_PROGRAM(4);
DECLARE_RIEMANN_PROGRAM(8);
DECLARE_RIEMANN_PROGRAM(16);
DECLARE_RIEMANN_PROGRAM(32);
