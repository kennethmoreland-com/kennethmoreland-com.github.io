// -*- c++ -*-

// This tests both the compressed FFT and IFFT programs.  If the
// CompressedFFT test fails, this one will too.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaError.h>
#include <ocaProgramFFT1c.h>
#include <ocaProgramIFFT1c.h>
#include <ocaProgramFFT2c.h>
#include <ocaProgramIFFT2c.h>
#include <ocaTimer.h>

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>

using std::cout;
using std::endl;

#define MAX_LOG_DIM	8
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

#define ABS(x)	((x) < 0 ? -(x) : (x))
#define EPSILON	0.0001
#define EQUAL(x1,x2)	(   (EPSILON > ABS(x1-x2))		\
			 || (ABS(EPSILON*x1) > ABS(x1-x2)))


static void DoFFT(int lg_sizex, int lg_sizey)
{
    int i;
    int sizex, sizey;

    sizex = sizey = 1;
    for (i = 0; i < lg_sizex; i++) {
	sizex <<= 1;
    }
    for (i = 0; i < lg_sizey; i++) {
	sizey <<= 1;
    }

    cout << "Image size: " << sizex << "x" << sizey << endl;

    float *inbuf = new float[4*sizex*sizey];
    float *outbuf = new float[4*sizex*sizey];
    ocaTimer::pointer timer = ocaTimer::New();

    for (i = 0; i < 4*sizex*sizey; i++) {
	inbuf[i] = (  ((float)rand()/(float)RAND_MAX)
		    * (MAX_VALUE-MIN_VALUE) + MIN_VALUE);
    }

    ocaFactory::pointer factory = ocaFactory::getSingleton();

    timer->start();
    ocaLookUpBuffer::pointer original = factory->makeLookUpBuffer();
    original->setData(inbuf, sizex, sizey, 4);
    timer->stop();
    cout << "Time to load data: " << timer->getElapsedTime() << " sec" << endl;

    ocaDrawableBuffer::pointer result
	= factory->makeDrawableBuffer(sizex, sizey, 4);
    ocaDrawableBuffer::pointer temporary
	= factory->makeDrawableBuffer(sizex, sizey, 4);

    cout << "Performing 1D FFT/IFFT in S." << endl;
  // Compute FFT with Graphics card.
    timer->start();
    ocaProgramFFT1c::getSingleton()->execute(original, result, temporary);
    ocaProgramIFFT1c::getSingleton()->execute(result, temporary,
					      result, temporary);
    glFinish();
    timer->stop();
    cout << "Time for GPU to perform FFT and IFFT: "
	 << timer->getElapsedTime() << " sec" << endl;

    timer->start();
    result->getData(outbuf);
    timer->stop();
    cout << "Time Retrieve FFT: " << timer->getElapsedTime() 
	 << " sec" << endl;

    cout << "Checking data." << endl;
    for (i = 0; i < 4*sizex*sizey; i++) {
	if (!EQUAL(inbuf[i], outbuf[i])) {
	    cout << inbuf[i] << endl;
	    cout << outbuf[i] << endl;
	    ocaRaiseError("FFTs don't agree!");
	}
    }
    cout << "FFT correct." << endl;

    cout << "Performing 2D FFT/IFFT." << endl;
  // Compute FFT with Graphics card.
    timer->start();
    ocaProgramFFT2c::getSingleton()->execute(original, result, temporary);
    ocaProgramIFFT2c::getSingleton()->execute(result, temporary,
					      result, temporary);
    glFinish();
    timer->stop();
    cout << "Time for GPU to perform FFT and IFFT: "
	 << timer->getElapsedTime() << " sec" << endl;

    timer->start();
    result->getData(outbuf);
    timer->stop();
    cout << "Time Retrieve FFT: " << timer->getElapsedTime() 
	 << " sec" << endl;

    cout << "Checking data." << endl;
    for (i = 0; i < 4*sizex*sizey; i++) {
	if (!EQUAL(inbuf[i], outbuf[i])) {
	    cout << inbuf[i] << endl;
	    cout << outbuf[i] << endl;
	    ocaRaiseError("FFTs don't agree!");
	}
    }
    cout << "FFT correct." << endl;

    delete[] inbuf;
    delete[] outbuf;
}


int CompressedIFFT(int, char *[])
{
    srand((unsigned int)time(NULL));

    try {
	DoFFT(1, 1);
	DoFFT(rand()%MAX_LOG_DIM+1, rand()%MAX_LOG_DIM+1);
// 	DoFFT(9, 9);
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();

    return 0;
}
