// -*- c++ -*-
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//

// Tests the data movement to, from, and between lookup buffers and drawable
// buffers.

#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaZeroBuffer.h>
#include <ocaProgramVolumeRenderingIntegrateInputs.h>
#include <ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation.h>
#include <ocaProgramVolumeRenderingIntegrateRiemann.h>
#include <ocaProgramVolumeRenderingIntegrateDirectLinear.h>
#include <ocaProgramVolumeRenderingIntegratePartialPreIntegration.h>
#include <ocaProgramVolumeRenderingIntegrateAverageColorAverageOpacity.h>
#include <ocaProgramVolumeRenderingIntegrateLinearColorAverageOpacity.h>
#include <ocaProgramVolumeRenderingIntegrateLinearColorLinearOpacity.h>
#include <ocaTimer.h>
#include <ocaError.h>

#include <iostream>
#include <fstream>
using std::cout;
using std::cerr;
using std::endl;

#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <float.h>

#define MAX_DIM	1000
#define FRAND()	((float)rand()/(float)RAND_MAX)
#define ABS(x)	((x) < 0 ? -(x) : (x))
//#define EPSILON	0.00001
#define EPSILON		0.01
#define EQUAL(x1,x2)	(   (   (EPSILON >= ABS(x1-x2))			\
			     || (ABS(EPSILON*x1) >= ABS(x1-x2)) )	\
			 && !_isnan(x1) && !_isnan(x2) )

class VriComparator {
  public:
    virtual void Compare(float ColorBack[4], float ColorFront[4], float Length,
			 float ComputedResult[4]) = 0;
    virtual void CompareResult(float ColorBack[4], float ColorFront[4],
			       float Length, float ExpectedResult[4],
			       float ComputedResult[4])
    {
// 	if (!EQUAL(ComputedResult[3], ExpectedResult[3])) {
// 	    char msg[1024];
// 	    sprintf(msg, "Bad comparision for\n"
// 		    "\ttaub = %f, tauf = %f, length = %f\n"
// 		    "Expected %f, got %f", ColorBack[3], ColorFront[3],
// 		    Length, ExpectedResult[3], ComputedResult[3]);
// 	    ocaRaiseError(msg);
// 	}
// 	for (int i = 0; i < 3; i++) {
// 	    if (!EQUAL(ExpectedResult[i], ComputedResult[i])) {
// 		char msg[1024];
// 		sprintf(msg, "Bad comparision for\n"
// 			"cb = %f, cf = %f, taub = %f, tauf = %f, length = %f\n"
// 			"Expected %f, got %f", ColorBack[i], ColorFront[i],
// 			ColorBack[3], ColorFront[3], Length,
// 			ExpectedResult[i], ComputedResult[i]);
// 		ocaRaiseError(msg);
// 	    }
// 	}
	for (int i = 3; i >= 0; i--) {
	    if (!EQUAL(ExpectedResult[i], ComputedResult[i])) {
		char msg[1024];
		sprintf(msg, "Bad comparision for c[%d]\n"
			"cb[%d] = %f, cf[%d] = %f, "
			"cb[3] = %f, cf[3] = %f, length = %f\n"
			"Expected %f, got %f", i, i, ColorBack[i],
			i, ColorFront[i],
			ColorBack[3], ColorFront[3], Length,
			ExpectedResult[i], ComputedResult[i]);
		ocaRaiseError(msg);
	    }
	}
    }
};

class VriNoCheck : public VriComparator {
  public:
    virtual void Compare(float ColorBack[4], float ColorFront[4], float Length,
			 float ComputedResult[4]) { }
};

class VriAverageColorAverageAttenuationComparator : public VriComparator {
  public:
    virtual void Compare(float ColorBack[4], float ColorFront[4], float Length,
			 float ComputedResult[4]) {
	float ExpectedResult[4];

	float alpha = 1 - (float)exp(-Length*(ColorBack[3]+ColorFront[3])/2);
	ExpectedResult[3] = alpha;
	for (int i = 0; i < 3; i++) {
	    ExpectedResult[i] = ((ColorBack[i]+ColorFront[i])/2)*alpha;
	}

	this->CompareResult(ColorBack, ColorFront, Length,
			    ExpectedResult, ComputedResult);
    }
};

class VriAverageColorAverageOpacityComparator : public VriComparator {
  public:
    virtual void Compare(float ColorBack[4], float ColorFront[4], float Length,
			 float ComputedResult[4]) {
	float ExpectedResult[4];

	float alpha = 1 - (float)pow(1-(ColorBack[3]+ColorFront[3])/2, Length);
	ExpectedResult[3] = alpha;
	for (int i = 0; i < 3; i++) {
	    ExpectedResult[i] = ((ColorBack[i]+ColorFront[i])/2)*alpha;
	}

	this->CompareResult(ColorBack, ColorFront, Length,
			    ExpectedResult, ComputedResult);
    }
};

class VriLinearColorAverageOpacityComparator : public VriComparator {
  public:
    virtual void Compare(float ColorBack[4], float ColorFront[4], float Length,
			 float ComputedResult[4]) {
	float ExpectedResult[4];

	float dtau = -Length*(float)log(1-(ColorBack[3]+ColorFront[3])/2);
	float zeta = (float)exp(-dtau);
	float alpha = 1 - zeta;
	float Psi = alpha/dtau;

	for (int i = 0; i < 3; i++) {
	    ExpectedResult[i] = ColorFront[i]*(1-Psi) + ColorBack[i]*(Psi-zeta);
	}
	ExpectedResult[3] = alpha;

	this->CompareResult(ColorBack, ColorFront, Length,
			    ExpectedResult, ComputedResult);
    }
};

class VriLinearColorLinearOpacityComparator : public VriComparator {
  public:
    virtual void Compare(float ColorBack[4], float ColorFront[4], float Length,
			 float ComputedResult[4]) {
	float ExpectedResult[4];

	float zeta = (float)pow(1 - (  0.5*(ColorBack[3]+ColorFront[3])
				     + (0.108165*(ColorBack[3]-ColorFront[3])
					*(ColorBack[3]-ColorFront[3])) ),
				Length);
	float alpha = 1 - zeta;

	float dtau2 = -Length*log(1-(0.27*ColorBack[3] + 0.73*ColorFront[3]));
	float zeta2 = exp(-dtau2);
	float Psi = (1-zeta2)/dtau2;

	for (int i = 0; i < 3; i++) {
	    ExpectedResult[i] = ColorFront[i]*(1-Psi) + ColorBack[i]*(Psi-zeta);
	}
	ExpectedResult[3] = alpha;

	this->CompareResult(ColorBack, ColorFront, Length,
			    ExpectedResult, ComputedResult);
    }
};

class VriRiemannComparator : public VriComparator {
  private:
    VriRiemannComparator();
  protected:
    int pieces;
  public:
    VriRiemannComparator(int p) : pieces(p) {}
    virtual void Compare(float ColorBack[4], float ColorFront[4], float Length,
			 float ComputedResult[4]) {
	float ExpectedResult[4];

	float piece_length = Length/this->pieces;
	for (int i = 0; i < 3; i++) {
	    float incrementColor = (ColorFront[i] - ColorBack[i])/this->pieces;
	    float inputColor = ColorBack[i] + 0.5f*incrementColor;
	    float incrementTau = (ColorFront[3] - ColorBack[3])/this->pieces;
	    float inputTau = ColorBack[3] + 0.5f*incrementTau;

	    ExpectedResult[i] = 0;
	    for (int p = 0; p < this->pieces; p++) {
		float zeta = (float)exp(-piece_length*inputTau);
		float alpha = 1 - zeta;
		ExpectedResult[i] *= zeta;
		ExpectedResult[i] += inputColor*alpha;
		inputColor += incrementColor;
		inputTau += incrementTau;
	    }
	}

      // Just use average tau to compute alpha, since it's a true linear
      // interpolation anyway.
	ExpectedResult[3]
	    = 1 - (float)exp(-Length*(ColorBack[3]+ColorFront[3])/2);
// 	float incrementTau = (ColorFront[3] - ColorBack[3])/this->pieces;
// 	float inputTau = ColorBack[3] + 0.5f*incrementTau;
// 	ExpectedResult[3] = 0;
// 	for (int p = 0; p < this->pieces; p++) {
// 	    float zeta = (float)exp(-piece_length*inputTau);
// 	    float alpha = 1 - zeta;
// 	    ExpectedResult[3] *= zeta;
// 	    ExpectedResult[3] += alpha;
// 	    inputTau += incrementTau;
// 	}

	this->CompareResult(ColorBack, ColorFront, Length,
			    ExpectedResult, ComputedResult);
    }
};

static int width, height;

static GLfloat fullScreenSquare[] = {
    -1.0, -1.0,
    1.0, -1.0,
    1.0, 1.0,
    -1.0, 1.0
};

static bool logfullrange = false;
static bool logsubdivide = false;
static bool logcellboundary = false;

static int time_vri = 1;
#define REPEAT	(time_vri ? 50 : 1)
static double ExerciseVRI(ocaProgramVolumeRenderingIntegrate::pointer vri,
			  GLfloat BackColorInputs[4*4],
			  GLfloat FrontColorInputs[4*4],
			  GLfloat LengthInputs[1*4],
			  ocaLookUpBuffer::pointer background,
			  GLfloat quad[2*4] = fullScreenSquare)
{
    vri->bind();

    cgGLSetParameterPointer(vri->getPosition(), 2, GL_FLOAT,
			    0, quad);
    cgGLEnableClientState(vri->getPosition());
    cgGLSetParameterPointer(vri->getBackColor(), 4, GL_FLOAT,
			    0, BackColorInputs);
    cgGLEnableClientState(vri->getBackColor());
    cgGLSetParameterPointer(vri->getFrontColor(), 4, GL_FLOAT,
			    0, FrontColorInputs);
    cgGLEnableClientState(vri->getFrontColor());
    cgGLSetParameterPointer(vri->getLength(), 1, GL_FLOAT,
			    0, LengthInputs);
    cgGLEnableClientState(vri->getLength());

    cgGLSetTextureParameter(vri->getIncoming(), background->getTextureId());
    cgGLEnableTextureParameter(vri->getIncoming());

    ocaTimer::pointer timer = ocaTimer::New();
    timer->start();
    for (int i = 0; i < REPEAT; i++) {
	glDrawArrays(GL_POLYGON, 0, 4);
    }
    glFinish();
    timer->stop();

    cgGLDisableClientState(vri->getPosition());
    cgGLDisableClientState(vri->getBackColor());
    cgGLDisableClientState(vri->getFrontColor());
    cgGLDisableClientState(vri->getLength());
    cgGLDisableTextureParameter(vri->getIncoming());
    vri->unbind();

    return timer->getElapsedTime()/REPEAT;
}

static void TestVRI(ocaProgramVolumeRenderingIntegrate::pointer vri,
		    VriComparator &comparator)
{
    cout << "Testing " << vri->getClassName() << endl;

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer outbuf = factory->makeDrawableBuffer(width,
								    height, 4);
    outbuf->makeCurrent();

  // Set up inputs.
    int i;
    GLfloat BackColorInputs[4*4];
    for (i = 0; i < 4*4; i++) BackColorInputs[i] = FRAND();
    GLfloat FrontColorInputs[4*4];
    for (i = 0; i < 4*4; i++) FrontColorInputs[i] = FRAND();
    GLfloat LengthInputs[1*4];
    for (i = 0; i < 1*4; i++) LengthInputs[i] = FRAND();

  // Get interpolated inputs.
    float *BackColors = new float[4*width*height];
    float *FrontColors = new float[4*width*height];
    float *Lengths = new float[4*width*height];
    float *Results = new float[4*width*height];

    ocaProgramVolumeRenderingIntegrateInputs::pointer inputs
	= ocaProgramVolumeRenderingIntegrateInputs::getSingleton();
    inputs->setOutSelectToBackColor();
    ExerciseVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(inputs),
		BackColorInputs, FrontColorInputs, LengthInputs,
		ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton()));
    outbuf->getData(BackColors);
    inputs->setOutSelectToFrontColor();
    ExerciseVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(inputs),
		BackColorInputs, FrontColorInputs, LengthInputs,
		ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton()));
    outbuf->getData(FrontColors);
    inputs->setOutSelectToLength();
    ExerciseVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(inputs),
		BackColorInputs, FrontColorInputs, LengthInputs,
		ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton()));
    outbuf->getData(Lengths);

  // Perform the actual test.  Run it twice to get an accurate time.
    double time;
    ExerciseVRI(vri, BackColorInputs, FrontColorInputs, LengthInputs,
		ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton()));
    time = ExerciseVRI(vri, BackColorInputs, FrontColorInputs, LengthInputs,
		ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton()));
    cout << "Calculations performed in " << time << " seconds." << endl;
    cout << "That's " << ((width*height/time)/1000000) << " Mfrag/sec." << endl;

  // Compare fragment program result to expected result.
    cout << "Comparing results..." << std::flush;
    outbuf->getData(Results);
    for (i = 0; i < width*height; i++) {
	comparator.Compare(BackColors + i*4, FrontColors + i*4,
			   Lengths[i*4], Results + i*4);
    }
    cout << "success" << endl;

    delete[] BackColors;
    delete[] FrontColors;
    delete[] Lengths;
    delete[] Results;
}

static void LogVri(ocaProgramVolumeRenderingIntegrate::pointer vri,
		   float BackColors[4*4], float FrontColors[4*4],
		   float Lengths[1*4], const char *filename,
		   int iterations)
{
    cout << endl << "Making log for " << vri->getClassName() << endl;

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer inbuf = factory->makeDrawableBuffer(width,
								    height, 4);
    ocaDrawableBuffer::pointer outbuf = factory->makeDrawableBuffer(width,
								    height, 4);
    ocaLookUpBuffer::pointer background
	= ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton());

    float reall[1*4];
    for (int j = 0; j < 1*4; j++) reall[j] = Lengths[j]/iterations;

    double time = 0.0;
    for (int i = 0; i < iterations; i++) {
	float realbc[4*4], realfc[4*4];
	for (int j = 0; j < 4*4; j++) {
	    float deltacolor = (FrontColors[j] - BackColors[j])/iterations;
	    realbc[j] = BackColors[j] + deltacolor*i;
	    realfc[j] = realbc[j] + deltacolor;
	}

	outbuf->makeCurrent();
	time += ExerciseVRI(vri, realbc, realfc, reall, background);

	inbuf->releaseLookUpBuffer();
	std::swap(inbuf, outbuf);
	background = inbuf->getSharedLookUpBuffer();
    }
    cout << "Calculations performed in " << time << " seconds." << endl;
    cout << "That's " << ((width*height*iterations/time)/1000) << " Mfrag/sec." << endl;

#if 1
    float *values = new float[4*width*height];
    background->getData(values);

    const char *component_names[] = { "r", "g", "b", "a" };
    for (int component = 0; component < 4; component++) {
	char actual_filename[128];
	sprintf(actual_filename, filename, component_names[component]);
	cout << "Writing log " << actual_filename << endl;
	std::ofstream log(actual_filename);
	log.setf(std::ios::fixed);
	log << "{";
	for (int j = 0; j < height; j++) {
	    if (j != 0) log << "," << endl << " ";
	    log << "{";
	    for (int i = 0; i < width; i++) {
		if (i != 0) log << ", ";
		log << values[4*(j*width + i) + component];
	    }
	    log << "}";
	}
	log << "}" << endl;
	log.close();
    }

    delete[] values;
#endif
}

static void LogBoundary(ocaProgramVolumeRenderingIntegrate::pointer vri,
			float BackColor[4], float FrontColor[4],
			float Length, const char *filename)
{
    cout << endl << "Making log for " << vri->getClassName() << endl;

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer middle = factory->makeDrawableBuffer(width,
								    height, 4);
    ocaDrawableBuffer::pointer front = factory->makeDrawableBuffer(width,
								   height, 4);
    ocaLookUpBuffer::pointer back
	= ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton());

    float leftquad[4*2] = {
	-1, 1,
	-1, -1,
	-1 + 2.0f/width, -1,
	-1 + 2.0f/width, 1 };
    float rightquad[4*2] = {
	1 - 2.0f/width, 1,
	1 - 2.0f/width, -1,
	1, -1,
	1, 1 };
    float middlequad[4*2] = {
	-1 + 2.0f/width, 1,
	-1 + 2.0f/width, -1,
	1 - 2.0f/width, -1,
	1 - 2.0f/width, 1 };
    float lengths[4];
    float backcolors[4*4] = {
	BackColor[0], BackColor[1], BackColor[2], BackColor[3],
	BackColor[0], BackColor[1], BackColor[2], BackColor[3],
	BackColor[0], BackColor[1], BackColor[2], BackColor[3],
	BackColor[0], BackColor[1], BackColor[2], BackColor[3] };
    float frontcolors[4*4] = {
	FrontColor[0], FrontColor[1], FrontColor[2], FrontColor[3],
	FrontColor[0], FrontColor[1], FrontColor[2], FrontColor[3],
	FrontColor[0], FrontColor[1], FrontColor[2], FrontColor[3],
	FrontColor[0], FrontColor[1], FrontColor[2], FrontColor[3] };
    float middlecolors[4*4] = {
	FrontColor[0], FrontColor[1], FrontColor[2], FrontColor[3],
	FrontColor[0], FrontColor[1], FrontColor[2], FrontColor[3],
	BackColor[0],  BackColor[1],  BackColor[2],  BackColor[3],
	BackColor[0],  BackColor[1],  BackColor[2],  BackColor[3] };

  // Draw the back cell.
    middle->makeCurrent();

  //Draw unobscured back cell.
    lengths[0] = Length; lengths[1] = Length;
    lengths[2] = Length; lengths[3] = Length; 
    ExerciseVRI(vri, backcolors, frontcolors, lengths, back, leftquad);
  //Draw infinitesimal size where front cell is.
    lengths[0] = 0; lengths[1] = 0;
    lengths[2] = 0; lengths[3] = 0; 
    ExerciseVRI(vri, backcolors, backcolors, lengths, back, rightquad);
  //Draw slopped face of back cell.
    lengths[0] = Length; lengths[1] = Length;
    lengths[2] = 0; lengths[3] = 0; 
    ExerciseVRI(vri, backcolors, middlecolors, lengths, back, middlequad);

  // Draw the front cell.
    front->makeCurrent();
    back = middle->getSharedLookUpBuffer();

  //Draw infinitesimal size where back cell is.
    lengths[0] = 0; lengths[1] = 0;
    lengths[2] = 0; lengths[3] = 0; 
    ExerciseVRI(vri, frontcolors, frontcolors, lengths, back, leftquad);
  //Draw unobscured front cell.
    lengths[0] = Length; lengths[1] = Length;
    lengths[2] = Length; lengths[3] = Length; 
    ExerciseVRI(vri, backcolors, frontcolors, lengths, back, rightquad);
  //Draw slopped face of back cell.
    lengths[0] = 0; lengths[1] = 0;
    lengths[2] = Length; lengths[3] = Length; 
    ExerciseVRI(vri, middlecolors, frontcolors, lengths, back, middlequad);


    float *values = new float[4*width*height];
    front->getData(values);

    cout << "Writing log " << filename << endl;
    std::ofstream log(filename);
    log.setf(std::ios::fixed);
    log.precision(12);
    log << "{";
    for (int i = 0; i < width; i++) {
	if (i != 0) log << ", ";
	log << "{" << values[4*i + 0]
	    << "," << values[4*i + 1]
	    << "," << values[4*i + 2]
	    << "," << values[4*i + 3] << "}";
    }
    log << "}";
    log.close();

    delete[] values;
}

int VolumeRenderingIntegrate(int argc, char *argv[])
{
    if (argc > 1) {
	for (int i = 1; i < argc; i++) {
	    if (strcmp(argv[i], "-logfullrange") == 0) {
		logfullrange = true;
	    } else if (strcmp(argv[i], "-logsubdivide") == 0) {
		logsubdivide = true;
	    } else if (strcmp(argv[i], "-logcellboundary") == 0) {
		logcellboundary = true;
	    } else {
		cerr << "Unknown option: " << argv[i] << endl;
		cerr << "USAGE: " << argv[0]
		     << " [-logfullrange] [-logsubdivide] [-logcellboundary] "
		     << endl;
		exit(1);
	    }
	}
    }

    try {
	if (!logfullrange && !logsubdivide && !logcellboundary) {
	    srand((unsigned int)time(NULL));
	    width = rand()%MAX_DIM + 1;
	    height = rand()%MAX_DIM + 1;

	    cout << "Dimensions: (" << width << " x " << height << ")" << endl;

	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation::getSingleton()),
		    VriAverageColorAverageAttenuationComparator());
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann2::getSingleton()),
		    VriRiemannComparator(2));
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann4::getSingleton()),
		    VriRiemannComparator(4));
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann8::getSingleton()),
		    VriRiemannComparator(8));
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann16::getSingleton()),
		    VriRiemannComparator(16));
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann32::getSingleton()),
		    VriRiemannComparator(32));
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateDirectLinear::getSingleton()),
		    VriNoCheck());
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegratePartialPreIntegration::getSingleton()),
		    VriRiemannComparator(32));
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageOpacity::getSingleton()),
		    VriAverageColorAverageOpacityComparator());
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorAverageOpacity::getSingleton()),
		    VriLinearColorAverageOpacityComparator());
	    TestVRI(ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorLinearOpacity::getSingleton()),
		    VriLinearColorLinearOpacityComparator());
	}

	if (logfullrange) {
	    int i;

	    width = 32;  height = 32;
	    float BackColors[4*4] = {
		1.0, 1.0, 1.0, 1.0,
		0.0, 0.0, 0.0, 1.0,
		0.0, 0.0, 0.0, 0.0,
		1.0, 1.0, 1.0, 0.0
	    };
	    float FrontColors[4*4] = {
		0.0, 0.0, 0.0, 0.0,
		1.0, 1.0, 1.0, 0.0,
		1.0, 1.0, 1.0, 1.0,
		0.0, 0.0, 0.0, 1.0
	    };
	    float Lengths[1*4] = { 0, 0, 0, 0 };

	  // Log the parameters.
	    ocaProgramVolumeRenderingIntegrateInputs::pointer vri_inputs
		= ocaProgramVolumeRenderingIntegrateInputs::getSingleton();
	    vri_inputs->setOutSelectToBackColor();
	    LogVri(ocaCast<ocaProgramVolumeRenderingIntegrate>(vri_inputs),
		   BackColors, FrontColors, Lengths,
		   "fullrange_colors_back_%s.log", 1);
	    vri_inputs->setOutSelectToFrontColor();
	    LogVri(ocaCast<ocaProgramVolumeRenderingIntegrate>(vri_inputs),
		   BackColors, FrontColors, Lengths,
		   "fullrange_colors_front_%s.log", 1);

	  // Log actual values
	    ocaProgramVolumeRenderingIntegrate::pointer vri_average_color_average_attenuation
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann2
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann2::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann4
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann4::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann8
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann8::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann16
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann16::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann32
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann32::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_direct_linear
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateDirectLinear::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_part_preint
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegratePartialPreIntegration::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_average_color_average_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageOpacity::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_linear_color_average_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorAverageOpacity::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_linear_color_linear_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorLinearOpacity::getSingleton());

#define LOG_ALL(length)							\
    for (i = 0; i < 4; i++) Lengths[i] = (float)length;			\
    LogVri(vri_direct_linear, BackColors, FrontColors, Lengths,		\
	   "fullrange_direct_linear_l" #length "_%s.log", 1);		\
    LogVri(vri_part_preint, BackColors, FrontColors, Lengths,		\
	   "fullrange_part_preint_l" #length "_%s.log", 1);		\
    LogVri(vri_average_color_average_attenuation,			\
	   BackColors, FrontColors, Lengths,				\
	   "fullrange_average_color_average_attenuation_l"		\
           #length "_%s.log", 1);					\
    LogVri(vri_average_color_average_opacity,				\
	   BackColors, FrontColors, Lengths,				\
	   "fullrange_average_color_average_opacity_l"			\
           #length "_%s.log", 1);					\
    LogVri(vri_linear_color_average_opacity,				\
	   BackColors, FrontColors, Lengths,				\
	   "fullrange_linear_color_average_opacity_l"			\
           #length "_%s.log", 1);					\
    LogVri(vri_linear_color_linear_opacity,				\
	   BackColors, FrontColors, Lengths,				\
	   "fullrange_linear_color_linear_opacity_l"			\
           #length "_%s.log", 1);					\
    LogVri(vri_riemann2, BackColors, FrontColors, Lengths,		\
	   "fullrange_riemann2_l" #length "_%s.log", 1);		\
//     LogVri(vri_riemann4, BackColors, FrontColors, Lengths,		\
// 	   "fullrange_riemann4_l" #length "_%s.log", 1);		\
//     LogVri(vri_riemann8, BackColors, FrontColors, Lengths,		\
// 	   "fullrange_riemann8_l" #length "_%s.log", 1);		\
//     LogVri(vri_riemann16, BackColors, FrontColors, Lengths,		\
// 	   "fullrange_riemann16_l" #length "_%s.log", 1);		\
//     LogVri(vri_riemann32, BackColors, FrontColors, Lengths,		\
// 	   "fullrange_riemann32_l" #length "_%s.log", 1);		\

	    LOG_ALL(0.001);
	    LOG_ALL(0.1);
	    LOG_ALL(1);
	    LOG_ALL(100);
#undef LOG_ALL
	}

	if (logsubdivide) {
	    time_vri = 0;
	    width = 32;  height = 32;
	    float BackColors[4*4] = {
		1.0, 1.0, 1.0, 1.0,
		0.0, 0.0, 0.0, 1.0,
		0.0, 0.0, 0.0, 0.0,
		1.0, 1.0, 1.0, 0.0
	    };
	    float FrontColors[4*4] = {
		0.0, 0.0, 0.0, 0.0,
		1.0, 1.0, 1.0, 0.0,
		1.0, 1.0, 1.0, 1.0,
		0.0, 0.0, 0.0, 1.0
	    };
	    float Lengths[1*4] = { 1, 1, 1, 1 };

	  // Log the parameters.
	    ocaProgramVolumeRenderingIntegrateInputs::pointer vri_inputs
		= ocaProgramVolumeRenderingIntegrateInputs::getSingleton();
	    vri_inputs->setOutSelectToBackColor();
	    LogVri(ocaCast<ocaProgramVolumeRenderingIntegrate>(vri_inputs),
		   BackColors, FrontColors, Lengths,
		   "subdivide_colors_back_%s.log", 1);
	    vri_inputs->setOutSelectToFrontColor();
	    LogVri(ocaCast<ocaProgramVolumeRenderingIntegrate>(vri_inputs),
		   BackColors, FrontColors, Lengths,
		   "subdivide_colors_front_%s.log", 1);

	  // Log actual values
	    ocaProgramVolumeRenderingIntegrate::pointer vri_average_color_average_attenuation
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann2
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann2::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_direct_linear
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateDirectLinear::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_part_preint
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegratePartialPreIntegration::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_average_color_average_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageOpacity::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_linear_color_average_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorAverageOpacity::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_linear_color_linear_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorLinearOpacity::getSingleton());

#define LOG_ALL(subdivisions)						\
     LogVri(vri_average_color_average_attenuation, 			\
            BackColors, FrontColors, Lengths, 				\
	    "subdivide_average_color_average_attenuation_"		\
            #subdivisions "_%s.log", subdivisions);			\
     LogVri(vri_riemann2, BackColors, FrontColors, Lengths, 		\
	    "subdivide_riemann2_" #subdivisions "_%s.log",		\
	    subdivisions);						\
     LogVri(vri_direct_linear, BackColors, FrontColors, Lengths,	\
	    "subdivide_direct_linear_" #subdivisions "_%s.log",		\
	    subdivisions); 						\
     LogVri(vri_part_preint, BackColors, FrontColors, Lengths,		\
	    "subdivide_part_preint_" #subdivisions "_%s.log",		\
	    subdivisions);						\
     LogVri(vri_average_color_average_opacity,	 			\
            BackColors, FrontColors, Lengths, 				\
	    "subdivide_average_color_average_opacity_"			\
            #subdivisions "_%s.log", subdivisions);			\
     LogVri(vri_linear_color_average_opacity,	 			\
            BackColors, FrontColors, Lengths, 				\
	    "subdivide_linear_color_average_opacity_"			\
            #subdivisions "_%s.log", subdivisions);			\
     LogVri(vri_linear_color_linear_opacity,	 			\
            BackColors, FrontColors, Lengths, 				\
	    "subdivide_linear_color_linear_opacity_"			\
            #subdivisions "_%s.log", subdivisions);

	    LOG_ALL(1);
	    LOG_ALL(10);
	    LOG_ALL(100);
	    LOG_ALL(1000);
#undef LOG_ALL
	}

	if (logcellboundary) {
	    width = 1026;
	    height = 1;

#define ATTENUATION	1.386294f
#define OPACITY		0.75f
	    float BackColor[4] = {1.0, 0.0, 1.0, OPACITY};
	    float FrontColor[4] = {1.0, 1.0, 0.0, OPACITY};
	  // Log the parameters.
	    ocaProgramVolumeRenderingIntegrateInputs::pointer vri_inputs
		= ocaProgramVolumeRenderingIntegrateInputs::getSingleton();
	    vri_inputs->setOutSelectToBackColor();
	    LogBoundary(ocaCast<ocaProgramVolumeRenderingIntegrate>(vri_inputs),
			BackColor, FrontColor, 1,
			"cellboundary_colors.log");
	    vri_inputs->setOutSelectToLength();
	    LogBoundary(ocaCast<ocaProgramVolumeRenderingIntegrate>(vri_inputs),
			BackColor, FrontColor, 1,
			"cellboundary_lengths.log");

	  // Log actual values
	    ocaProgramVolumeRenderingIntegrate::pointer vri_average_color_average_attenuation
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann2
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann2::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann4
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann4::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann8
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann8::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann16
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann16::getSingleton());
// 	    ocaProgramVolumeRenderingIntegrate::pointer vri_riemann32
// 		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateRiemann32::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_direct_linear
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateDirectLinear::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_part_preint
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegratePartialPreIntegration::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_average_color_average_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateAverageColorAverageOpacity::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_linear_color_average_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorAverageOpacity::getSingleton());
	    ocaProgramVolumeRenderingIntegrate::pointer vri_linear_color_linear_opacity
		= ocaCast<ocaProgramVolumeRenderingIntegrate>(ocaProgramVolumeRenderingIntegrateLinearColorLinearOpacity::getSingleton());

#define LOG_METHOD(length, method, opacity)				  \
    BackColor[3] = opacity;						  \
    FrontColor[3] = 0;							  \
    LogBoundary(vri_##method, BackColor, FrontColor, (float)length,	  \
		"cellboundary_" #method "_backopaque_l" #length ".log");  \
    BackColor[3] = 0;							  \
    FrontColor[3] = opacity;						  \
    LogBoundary(vri_##method, BackColor, FrontColor, (float)length,	  \
		"cellboundary_" #method "_frontopaque_l" #length ".log"); \
    BackColor[3] = opacity;						  \
    FrontColor[3] = opacity;						  \
    LogBoundary(vri_##method, BackColor, FrontColor, (float)length,	  \
		"cellboundary_" #method "_allopaque_l" #length ".log");
#define LOG_ALL(length)							\
    LOG_METHOD(length, direct_linear, ATTENUATION);			\
    LOG_METHOD(length, part_preint, ATTENUATION);			\
    LOG_METHOD(length, average_color_average_attenuation, ATTENUATION);	\
    LOG_METHOD(length, average_color_average_opacity, OPACITY);		\
    LOG_METHOD(length, linear_color_average_opacity, OPACITY);		\
    LOG_METHOD(length, linear_color_linear_opacity, OPACITY);		\
    LOG_METHOD(length, riemann2, ATTENUATION);				\
//     LOG_METHOD(length, riemann4, ATTENUATION);			\
//     LOG_METHOD(length, riemann8, ATTENUATION);			\
//     LOG_METHOD(length, riemann16, ATTENUATION);			\
//     LOG_METHOD(length, riemann32, ATTENUATION);			\

	    LOG_ALL(0.001);
	    LOG_ALL(0.1);
	    LOG_ALL(1);
	    LOG_ALL(100);
#undef LOG_ALL
#undef LOG_METHOD
	}
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();
    return 0;
}
