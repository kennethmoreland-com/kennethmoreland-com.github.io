// -*- c++ -*-

// Tests the data movement to, from, and between lookup buffers and drawable
// buffers.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaError.h>

#include <iostream>
using std::cout;
using std::endl;

#include <stdlib.h>
#include <time.h>

#define MAX_DIM	1280
#define MAX_VECTOR 4
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

static int width, height, components;

static void TestCopy(ocaBuffer::pointer srcBuffer,
		     ocaBuffer::pointer destBuffer)
{
    cout << "Copying from " << srcBuffer->getClassName()
	 << " to " << destBuffer->getClassName() << endl;

    float *inbuf = new float[width*height*components];
    float *outbuf = new float[width*height*components];
    int i;

    for (i = 0; i < width*height*components; i++) {
	inbuf[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    }

    srcBuffer->setData(inbuf, width, height, components);
    destBuffer->copy(srcBuffer);
    destBuffer->getData(outbuf);

    for (i = 0; i < width*height*components; i++) {
	if (outbuf[i] != inbuf[i]) {
	    cout << inbuf[i] << endl;
	    cout << outbuf[i] << endl;
	    ocaRaiseError("Data not consistent at index " + oca_itos(i));
	}
    }
    cout << "Comparison correct." << endl;

    delete[] inbuf;
    delete[] outbuf;
}

int DataCopy(int, char *[])
{
    srand((unsigned int)time(NULL));
    width = rand()%MAX_DIM + 1;
    height = rand()%MAX_DIM + 1;
    do {
	components = rand()%MAX_VECTOR + 1;
    } while (components == 2);

    cout << "Dimensions: (" << width << ", " << height << ", "
	 << components << ")" << endl;

    try {
	ocaFactory::pointer factory = ocaFactory::getSingleton();

	TestCopy(ocaCast<ocaBuffer>(factory->makeLookUpBuffer()),
		 ocaCast<ocaBuffer>(factory->makeLookUpBuffer()));
	TestCopy(ocaCast<ocaBuffer>(factory->makeLookUpBuffer()),
		 ocaCast<ocaBuffer>(factory->makeDrawableBuffer(width, height,
								components)));
	TestCopy(ocaCast<ocaBuffer>(factory->makeDrawableBuffer(width, height,
								components)),
		 ocaCast<ocaBuffer>(factory->makeLookUpBuffer()));
	TestCopy(ocaCast<ocaBuffer>(factory->makeDrawableBuffer(width, height,
								components)),
		 ocaCast<ocaBuffer>(factory->makeDrawableBuffer(width, height,
								components)));
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();
    return 0;
}
