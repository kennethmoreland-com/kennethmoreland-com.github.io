// -*- c++ -*-

// Tests this simple matrix multiply program.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaError.h>
#include <ocaProgramFastMatrixMultiply.h>
#include <ocaTimer.h>

#include <iostream>
#include <stdlib.h>
#include <time.h>

using std::cout;
using std::endl;

#define MAX_DIM	200
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

#define ABS(x)	((x) < 0 ? -(x) : (x))
#define EPSILON	0.0001
#define EQUAL(x1,x2)	(   (EPSILON > ABS(x1-x2))		\
			 || (ABS(EPSILON*x1) > ABS(x1-x2)))

static void DoMatrixMult(int rows, int cols, int intermediate)
{
    cout << "Matrix A: " << rows << "x" << intermediate << endl;
    cout << "Matrix B: " << intermediate << "x" << cols << endl;
    cout << "Matrix C: " << rows << "x" << cols << endl;

    int i;
    float *bufA = new float[rows*intermediate];
    float *bufB = new float[intermediate*cols];
    float *bufC = new float[rows*cols];
    float *bufC2 = new float[rows*cols];
    ocaTimer::pointer timer = ocaTimer::New();

    for (i = 0; i < rows*intermediate; i++) {
	bufA[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    }
    for (i = 0; i < cols*intermediate; i++) {
	bufB[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    }

    ocaFactory::pointer factory = ocaFactory::getSingleton();

    timer->start();
    ocaLookUpBuffer::pointer A = factory->makeLookUpBuffer();
    ocaLookUpBuffer::pointer B = factory->makeLookUpBuffer();
    A->setData(bufA, intermediate/4, rows, 4);
    B->setData(bufB, cols/4, intermediate, 4);

    ocaDrawableBuffer::pointer C = factory->makeDrawableBuffer(cols/4, rows, 4);

    ocaProgramFastMatrixMultiply::getSingleton()->execute(A, B, C);

    C->getData(bufC);
    timer->stop();

    cout << "Time to multiply: " << timer->getElapsedTime() << " sec" << endl;

#if 0
#define MSIZE 4
    int r1,c1;
	    for (r1 = 0; r1 < MSIZE; r1++) {
		printf("|");
		for (c1 = 0; c1 < MSIZE; c1++) {
		    printf("%4.0f", bufA[r1*MSIZE + c1]);
		}
		printf("|   |");
		for (c1 = 0; c1 < MSIZE; c1++) {
		    printf("%4.0f", bufB[r1*MSIZE + c1]);
		}
		printf("|\n");
	    }
	    printf("\n");
	    for (r1 = 0; r1 < MSIZE; r1++) {
		printf("|");
		for (c1 = 0; c1 < MSIZE; c1++) {
		    printf("%4.0f", bufC[r1*MSIZE + c1]);
		}
		printf("|\n");
	    }
#endif

    int r, c;
    timer->start();
    for (r = 0; r < rows; r++) {
	for (c = 0; c < cols; c++) {
	    float v = 0.0;
	    for (int k = 0; k < intermediate; k++) {
		v += bufA[r*intermediate + k]
		    *bufB[k*cols + c];
	    }
	    bufC2[r*cols + c] = v;
	}
    }
    timer->stop();
    cout << "Time to multiply in software: " << timer->getElapsedTime() 
	 << " sec" << endl;

    cout << "Checking data." << endl;
    for (r = 0; r < rows; r++) {
	for (c = 0; c < cols; c++) {
	    if (!EQUAL(bufC[r*cols + c], bufC2[r*cols + c])) {
		ocaRaiseError("Matrices don't agree!");
	    }
	}
    }
    cout << "Multiplication correct." << endl;

    delete[] bufA;
    delete[] bufB;
    delete[] bufC;
    delete[] bufC2;
}


int FastMatrixMultiply(int, char *[])
{
    int rows, cols, intermediate;

    srand((unsigned int)time(NULL));
    rows = (rand()%(MAX_DIM/4) + 1)*4;
    cols = (rand()%(MAX_DIM/4) + 1)*4;
    intermediate = (rand()%(MAX_DIM/4) + 1)*4;

    try {
	DoMatrixMult(rows, cols, intermediate);
	DoMatrixMult(rows, cols, 4);
// 	DoMatrixMult(1024, 1024, 1024);
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();

    return 0;
}
