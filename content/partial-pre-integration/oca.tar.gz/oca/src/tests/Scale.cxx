// -*- c++ -*-

// Tests the data movement to, from, and between lookup buffers and drawable
// buffers.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaProgramScale.h>
#include <ocaError.h>

#include <iostream>
using std::cout;
using std::endl;

#include <stdlib.h>
#include <time.h>

#define MAX_DIM	1000
#define MAX_VECTOR 4
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

#define ABS(x)	((x) < 0 ? -(x) : (x))
#define EPSILON	0.0001
#define EQUAL(x1,x2)	(   (EPSILON > ABS(x1-x2))		\
			 || (ABS(EPSILON*x1) > ABS(x1-x2)))

static int width, height, components;
static float scale;

static void TestCopy(ocaBuffer::pointer srcBuffer,
		     ocaBuffer::pointer destBuffer)
{
    cout << "Copying from " << srcBuffer->getClassName()
	 << " to " << destBuffer->getClassName() << endl;

}

int Scale(int, char *[])
{
    srand((unsigned int)time(NULL));
    width = rand()%MAX_DIM + 1;
    height = rand()%MAX_DIM + 1;
    scale = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    do {
	components = rand()%MAX_VECTOR + 1;
    } while (components == 2);

    cout << "Dimensions: (" << width << ", " << height << ", "
	 << components << ")" << endl;

    try {
	ocaFactory::pointer factory = ocaFactory::getSingleton();

	ocaLookUpBuffer::pointer source = factory->makeLookUpBuffer();
	ocaDrawableBuffer::pointer dest
	    = factory->makeDrawableBuffer(width, height, components);

	float *inbuf = new float[width*height*components];
	float *outbuf = new float[width*height*components];
	int i;

	for (i = 0; i < width*height*components; i++) {
	    inbuf[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
	}

	source->setData(inbuf, width, height, components);
	ocaProgramScale::getSingleton()->execute(source, scale, dest);
	dest->getData(outbuf);

	for (i = 0; i < width*height*components; i++) {
	    if (!EQUAL(outbuf[i], scale*inbuf[i])) {
		cout << scale*inbuf[i] << endl;
		cout << outbuf[i] << endl;
		ocaRaiseError("Data not consistent at index " + oca_itos(i));
	    }
	}
	cout << "Comparison correct." << endl;

	delete[] inbuf;
	delete[] outbuf;
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();
    return 0;
}
