// -*- c++ -*-

// Tests this simple matrix multiply program for complex numbers.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaError.h>
#include <ocaProgramComplexMatrixMultiply.h>

#include <iostream>
#include <stdlib.h>
#include <time.h>

using std::cout;
using std::endl;

#define MAX_DIM	100
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

#define ABS(x)	((x) < 0 ? -(x) : (x))
#define EPSILON	0.005
#define EQUAL(x1,x2)	(   (EPSILON > ABS(x1-x2))		\
			 || (ABS(EPSILON*x1) > ABS(x1-x2)))

#define RI(r, c, numcols) (4*((r)*(numcols) + (c)) + 0)
#define II(r, c, numcols) (4*((r)*(numcols) + (c)) + 1)
static void DoMatrixMult(int rows, int cols, int intermediate)
{
    cout << "Matrix A: " << rows << "x" << intermediate << endl;
    cout << "Matrix B: " << intermediate << "x" << cols << endl;
    cout << "Matrix C: " << rows << "x" << cols << endl;

    int i;
    float *bufA = new float[rows*intermediate*4];
    float *bufB = new float[intermediate*cols*4];
    float *bufC = new float[rows*cols*4];

    for (i = 0; i < rows*intermediate*4; i++) {
	bufA[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    }
    for (i = 0; i < cols*intermediate*4; i++) {
	bufB[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    }

    ocaFactory::pointer factory = ocaFactory::getSingleton();

    ocaLookUpBuffer::pointer A = factory->makeLookUpBuffer();
    ocaLookUpBuffer::pointer B = factory->makeLookUpBuffer();
    A->setData(bufA, intermediate, rows, 4);
    B->setData(bufB, cols, intermediate, 4);

    ocaDrawableBuffer::pointer C = factory->makeDrawableBuffer(cols, rows, 4);

    ocaProgramComplexMatrixMultiply::getSingleton()->execute(A, B, C);

    C->getData(bufC);

    cout << "Checking data." << endl;
    for (int r = 0; r < rows; r++) {
	for (int c = 0; c < cols; c++) {
	    float vr = 0;
	    float vi = 0;
	    for (int k = 0; k < intermediate; k++) {
		vr += (  (bufA[RI(r,k,intermediate)]*bufB[RI(k,c,cols)])
		       - (bufA[II(r,k,intermediate)]*bufB[II(k,c,cols)]) );
		vi += (  (bufA[RI(r,k,intermediate)]*bufB[II(k,c,cols)])
		       + (bufA[II(r,k,intermediate)]*bufB[RI(k,c,cols)]) );
	    }
	    if (!EQUAL(vr,bufC[RI(r,c,cols)]) || !EQUAL(vi,bufC[II(r,c,cols)]))
	    {
		cout << vr << " + i" << vi << endl;
		cout << bufC[RI(r,c,cols)] << " + i"
		     << bufC[II(r,c,cols)] << endl;
		ocaRaiseError("Matrices don't agree!");
	    }
	}
    }
    cout << "Multiplication correct." << endl;

    delete[] bufA;
    delete[] bufB;
    delete[] bufC;
}


int ComplexMatrixMultiply(int, char *[])
{
    int rows, cols, intermediate;

    srand((unsigned int)time(NULL));
    rows = rand()%MAX_DIM + 1;
    cols = rand()%MAX_DIM + 1;
    intermediate = rand()%MAX_DIM + 1;

    try {
	DoMatrixMult(rows, cols, intermediate);
	DoMatrixMult(rows, cols, 1);
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();

    return 0;
}
