// -*- c++ -*-

#include <ocaObject.h>
#include <ocaError.h>

#include <iostream>
using std::cout;
using std::endl;

static void InitializeTests(int *argcp, char **argvp[])
{
    try {
	ocaObject::initialize();
    } catch (ocaError &error) {
	cout << "Could not initialize oca libs:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	exit(1);
    }
}
