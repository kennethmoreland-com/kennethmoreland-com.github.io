// -*- c++ -*-

// Tests the FFT in compressed format.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaError.h>
#include <ocaProgramFFT2c.h>
#include <ocaProgramFFT2cMult.h>
#include <ocaTimer.h>

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>

using std::cout;
using std::endl;

ocaTimer::pointer timer;

#define MAX_LOG_DIM	8
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

#define ABS(x)	((x) < 0 ? -(x) : (x))
#define EPSILON	0.0001
#define EQUAL(x1,x2)	(   (EPSILON > ABS(x1-x2))		\
			 || (ABS(EPSILON*x1) > ABS(x1-x2)))

/*
 * This method is Copyright (c) Paul Bourke 1993.
 * The original code can be retrieved from
 *	http://astronomy.swin.edu.au/~pbourke/analysis/dft/
 * This computes an in-place complex-to-complex FFT 
 * real and imag are the real and imaginary arrays of 2^m points.
 * dir =  1 gives forward transform
 * dir = -1 gives reverse transform 
*/
static short FFT(short int dir,long m,float *real,float *imag)
{
   long n,i,i1,j,k,i2,l,l1,l2;
   float c1,c2,treal,timag,t1,t2,u1,u2,z;

   /* Calculate the number of points */
   n = 1;
   for (i=0;i<m;i++) 
      n *= 2;

   /* Do the bit reversal */
   i2 = n >> 1;
   j = 0;
   for (i=0;i<n-1;i++) {
      if (i < j) {
         treal = real[i];
         timag = imag[i];
         real[i] = real[j];
         imag[i] = imag[j];
         real[j] = treal;
         imag[j] = timag;
      }
      k = i2;
      while (k <= j) {
         j -= k;
         k >>= 1;
      }
      j += k;
   }

   /* Compute the FFT */
   c1 = -1.0; 
   c2 = 0.0;
   l2 = 1;
   for (l=0;l<m;l++) {
      l1 = l2;
      l2 <<= 1;
      u1 = 1.0; 
      u2 = 0.0;
      for (j=0;j<l1;j++) {
         for (i=j;i<n;i+=l2) {
            i1 = i + l1;
            t1 = u1 * real[i1] - u2 * imag[i1];
            t2 = u1 * imag[i1] + u2 * real[i1];
            real[i1] = real[i] - t1; 
            imag[i1] = imag[i] - t2;
            real[i] += t1;
            imag[i] += t2;
         }
         z =  u1 * c1 - u2 * c2;
         u2 = u1 * c2 + u2 * c1;
         u1 = z;
      }
      c2 = (float)sqrt((1.0 - c1) / 2.0);
      if (dir == 1) 
         c2 = -c2;
      c1 = (float)sqrt((1.0 + c1) / 2.0);
   }

   /* Scaling for forward transform */
   if (dir == 1) {
      for (i=0;i<n;i++) {
         real[i] /= n;
         imag[i] /= n;
      }
   }
   
   return 1;
}


static void DoFFT(int lg_sizex, int lg_sizey)
{
    int i, k;
    int sizex, sizey;

    sizex = sizey = 1;
    for (i = 0; i < lg_sizex; i++) {
	sizex <<= 1;
    }
    for (i = 0; i < lg_sizey; i++) {
	sizey <<= 1;
    }

    cout << "Image size: " << sizex << "x" << sizey << endl;

    float *inbuf_original1 = new float[4*sizex*sizey];
    float *inbuf_original2 = new float[4*sizex*sizey];
    float *inbuf_real1[4];
    float *inbuf_imag1[4];
    float *inbuf_real2[4];
    float *inbuf_imag2[4];
    for (i = 0; i < 4; i++) {
	inbuf_real1[i] = new float[sizex*sizey];
	inbuf_imag1[i] = new float[sizex*sizey];
	inbuf_real2[i] = new float[sizex*sizey];
	inbuf_imag2[i] = new float[sizex*sizey];
    }
    float *outbuf_compressed = new float[4*sizex*sizey];
    float *outbuf_real = new float[4*sizex*sizey];
    float *outbuf_imag = new float[4*sizex*sizey];

    for (i = 0; i < 4*sizex*sizey; i++) {
	inbuf_original1[i] = (  ((float)rand()/(float)RAND_MAX)
			      * (MAX_VALUE-MIN_VALUE) + MIN_VALUE);
	inbuf_original2[i] = (  ((float)rand()/(float)RAND_MAX)
			      * (MAX_VALUE-MIN_VALUE) + MIN_VALUE);
    }
    for (i = 0; i < sizex*sizey; i++) {
	inbuf_real1[0][i] = inbuf_original1[4*i + 0];
	inbuf_real1[1][i] = inbuf_original1[4*i + 1];
	inbuf_real1[2][i] = inbuf_original1[4*i + 2];
	inbuf_real1[3][i] = inbuf_original1[4*i + 3];
	inbuf_imag1[0][i] = 0;
	inbuf_imag1[1][i] = 0;
	inbuf_imag1[2][i] = 0;
	inbuf_imag1[3][i] = 0;
	inbuf_real2[0][i] = inbuf_original2[4*i + 0];
	inbuf_real2[1][i] = inbuf_original2[4*i + 1];
	inbuf_real2[2][i] = inbuf_original2[4*i + 2];
	inbuf_real2[3][i] = inbuf_original2[4*i + 3];
	inbuf_imag2[0][i] = 0;
	inbuf_imag2[1][i] = 0;
	inbuf_imag2[2][i] = 0;
	inbuf_imag2[3][i] = 0;
    }

    ocaFactory::pointer factory = ocaFactory::getSingleton();

    ocaLookUpBuffer::pointer original1 = factory->makeLookUpBuffer();
    original1->setData(inbuf_original1, sizex, sizey, 4);
    ocaLookUpBuffer::pointer original2 = factory->makeLookUpBuffer();
    original2->setData(inbuf_original2, sizex, sizey, 4);

    ocaDrawableBuffer::pointer frequencies1
	= factory->makeDrawableBuffer(sizex, sizey, 4);
    ocaDrawableBuffer::pointer frequencies2
	= factory->makeDrawableBuffer(sizex, sizey, 4);
    ocaDrawableBuffer::pointer frequencies_final
	= factory->makeDrawableBuffer(sizex, sizey, 4);

    cout << "Computing FFTs in software." << endl;
  // Compute FFT (in place) with traditional function.
    float *tmp_real = new float[sizey];
    float *tmp_imag = new float[sizey];

    for (i = 0; i < sizey; i++) {
	FFT(1, lg_sizex, inbuf_real1[0] + i*sizex, inbuf_imag1[0] + i*sizex);
	FFT(1, lg_sizex, inbuf_real1[1] + i*sizex, inbuf_imag1[1] + i*sizex);
	FFT(1, lg_sizex, inbuf_real1[2] + i*sizex, inbuf_imag1[2] + i*sizex);
	FFT(1, lg_sizex, inbuf_real1[3] + i*sizex, inbuf_imag1[3] + i*sizex);
    }
    for (k = 0; k < 4; k++) {
	for (i = 0; i < sizex; i++) {
	    int j;
	    for (j = 0; j < sizey; j++) {
		tmp_real[j] = inbuf_real1[k][j*sizex + i];
		tmp_imag[j] = inbuf_imag1[k][j*sizex + i];
	    }
	    FFT(1, lg_sizey, tmp_real, tmp_imag);
	    for (j = 0; j < sizey; j++) {
		inbuf_real1[k][j*sizex + i] = tmp_real[j];
		inbuf_imag1[k][j*sizex + i] = tmp_imag[j];
	    }
	}
    }

    timer->start();
    for (i = 0; i < sizey; i++) {
	FFT(1, lg_sizex, inbuf_real2[0] + i*sizex, inbuf_imag2[0] + i*sizex);
	FFT(1, lg_sizex, inbuf_real2[1] + i*sizex, inbuf_imag2[1] + i*sizex);
	FFT(1, lg_sizex, inbuf_real2[2] + i*sizex, inbuf_imag2[2] + i*sizex);
	FFT(1, lg_sizex, inbuf_real2[3] + i*sizex, inbuf_imag2[3] + i*sizex);
    }
    for (k = 0; k < 4; k++) {
	for (i = 0; i < sizex; i++) {
	    int j;
	    for (j = 0; j < sizey; j++) {
		tmp_real[j] = inbuf_real2[k][j*sizex + i];
		tmp_imag[j] = inbuf_imag2[k][j*sizex + i];
	    }
	    FFT(1, lg_sizey, tmp_real, tmp_imag);
	    for (j = 0; j < sizey; j++) {
		inbuf_real2[k][j*sizex + i] = tmp_real[j];
		inbuf_imag2[k][j*sizex + i] = tmp_imag[j];
	    }
	}
    }
    timer->stop();
    cout << "Time to do one 2D FFT in software: " << timer->getElapsedTime() << endl;

    delete[] tmp_real;
    delete[] tmp_imag;

    cout << "Multiplying frequencies in software." << endl;
  // Now multiply the two and store the result in inbuf_real/imag1.
    timer->start();
    for (i = 0; i < sizex; i++) {
	for (int j = 0; j < sizey; j++) {
	    for (k = 0; k < 4; k++) {
		int index = j*sizex + i;
		float realval = (  inbuf_real1[k][index]*inbuf_real2[k][index]
				 - inbuf_imag1[k][index]*inbuf_imag2[k][index]);
		float imagval = (  inbuf_real1[k][index]*inbuf_imag2[k][index]
				 + inbuf_imag1[k][index]*inbuf_real2[k][index]);
		inbuf_real1[k][index] = realval;
		inbuf_imag1[k][index] = imagval;
	    }
	}
    }
    timer->stop();
    cout << "Time to multiply frequencies in software: "
	 << timer->getElapsedTime() << endl;

    cout << "Performing 2D FFTs." << endl;
    timer->start();
    ocaProgramFFT2c::pointer FFT2c = ocaProgramFFT2c::getSingleton();
    FFT2c->execute(original1, frequencies1, frequencies_final);
    FFT2c->execute(original2, frequencies2, frequencies_final);
    cout << "Doing multiplication." << endl;
    ocaProgramFFT2cMult::getSingleton()
	->execute(frequencies1->getSharedLookUpBuffer(),
		  frequencies2->getSharedLookUpBuffer(),
		  frequencies_final);
    glFinish();
    timer->stop();
    cout << "Time to do FFT and multiplication in GPU: "
	 << timer->getElapsedTime() << endl;
    frequencies_final->getData(outbuf_compressed);

    cout << "Uncompressing" << endl;
    ocaProgramFFT2c::uncompress(sizex, sizey, 4, 
				(const float *)outbuf_compressed,
				outbuf_real, outbuf_imag);

    cout << "Checking data." << endl;
    for (k = 0; k < 4; k++) {
	for (i = 0; i < sizex*sizey; i++) {
	    if (   !EQUAL(inbuf_real1[k][i]/(sizex*sizey),
			  outbuf_real[4*i+k]/(sizex*sizey))
		|| !EQUAL(inbuf_imag1[k][i]/(sizex*sizey),
			  outbuf_imag[4*i+k]/(sizex*sizey)) )
	    {
		cout << inbuf_real1[k][i] << " + "
		     << inbuf_imag1[k][i] << "i" << endl;
		cout << outbuf_real[4*i+k] << " + "
		     << outbuf_imag[4*i+k] << "i" << endl;
		ocaRaiseError("FFTs don't agree!");
	    }
	}
    }
    cout << "FFT multiplication correct." << endl;

    delete[] inbuf_real1[0];
    delete[] inbuf_real1[1];
    delete[] inbuf_real1[2];
    delete[] inbuf_real1[3];
    delete[] inbuf_imag1[0];
    delete[] inbuf_imag1[1];
    delete[] inbuf_imag1[2];
    delete[] inbuf_imag1[3];
    delete[] inbuf_real2[0];
    delete[] inbuf_real2[1];
    delete[] inbuf_real2[2];
    delete[] inbuf_real2[3];
    delete[] inbuf_imag2[0];
    delete[] inbuf_imag2[1];
    delete[] inbuf_imag2[2];
    delete[] inbuf_imag2[3];
    delete[] outbuf_compressed;
    delete[] outbuf_real;
    delete[] outbuf_imag;
}


int FFTMultiply(int, char *[])
{
    srand((unsigned int)time(NULL));

    try {
	timer = ocaTimer::New();

	DoFFT(1, 1);
	DoFFT(rand()%MAX_LOG_DIM+1, rand()%MAX_LOG_DIM+1);
// // 	DoFFT(5, 5);
// 	DoFFT(10, 10);
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();

    return 0;
}
