// -*- c++ -*-

// Tests this simple matrix multiply program.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaError.h>
#include <ocaProgramFFT.h>
#include <ocaZeroBuffer.h>

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>

using std::cout;
using std::endl;

#define MAX_LOG_DIM	8
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

#define ABS(x)	((x) < 0 ? -(x) : (x))
#define EPSILON	0.001
#define EQUAL(x1,x2)	(   (EPSILON > ABS(x1-x2))		\
			 || (ABS(EPSILON*x1) > ABS(x1-x2)))

/*
 * This method is Copyright (c) Paul Bourke 1993.
 * The original code can be retrieved from
 *	http://astronomy.swin.edu.au/~pbourke/analysis/dft/
 * This computes an in-place complex-to-complex FFT 
 * real and imag are the real and imaginary arrays of 2^m points.
 * dir =  1 gives forward transform
 * dir = -1 gives reverse transform 
*/
static short FFT(short int dir,long m,float *real,float *imag)
{
   long n,i,i1,j,k,i2,l,l1,l2;
   float c1,c2,treal,timag,t1,t2,u1,u2,z;

   /* Calculate the number of points */
   n = 1;
   for (i=0;i<m;i++) 
      n *= 2;

   /* Do the bit reversal */
   i2 = n >> 1;
   j = 0;
   for (i=0;i<n-1;i++) {
      if (i < j) {
         treal = real[i];
         timag = imag[i];
         real[i] = real[j];
         imag[i] = imag[j];
         real[j] = treal;
         imag[j] = timag;
      }
      k = i2;
      while (k <= j) {
         j -= k;
         k >>= 1;
      }
      j += k;
   }

   /* Compute the FFT */
   c1 = -1.0; 
   c2 = 0.0;
   l2 = 1;
   for (l=0;l<m;l++) {
      l1 = l2;
      l2 <<= 1;
      u1 = 1.0; 
      u2 = 0.0;
      for (j=0;j<l1;j++) {
         for (i=j;i<n;i+=l2) {
            i1 = i + l1;
            t1 = u1 * real[i1] - u2 * imag[i1];
            t2 = u1 * imag[i1] + u2 * real[i1];
            real[i1] = real[i] - t1; 
            imag[i1] = imag[i] - t2;
            real[i] += t1;
            imag[i] += t2;
         }
         z =  u1 * c1 - u2 * c2;
         u2 = u1 * c2 + u2 * c1;
         u1 = z;
      }
      c2 = (float)sqrt((1.0 - c1) / 2.0);
      if (dir == 1) 
         c2 = -c2;
      c1 = (float)sqrt((1.0 + c1) / 2.0);
   }

   /* Scaling for forward transform */
   /* KDM: Bourke's definition of the DFT has the forward scaled whereas
    * I've been using a definition with the reversed scaled.  I changed
    * this to agree with my code. */
   if (dir == -1) {
      for (i=0;i<n;i++) {
         real[i] /= n;
         imag[i] /= n;
      }
   }
   
   return 1;
}


static void DoFFT(int lg_sizex, int lg_sizey)
{
    int i;
    int sizex, sizey;

    sizex = sizey = 1;
    for (i = 0; i < lg_sizex; i++) {
	sizex <<= 1;
    }
    for (i = 0; i < lg_sizey; i++) {
	sizey <<= 1;
    }

    cout << "Image size: " << sizex << "x" << sizey << endl;

    float *inbuf_real = new float[sizex*sizey];
    float *inbuf_imag = new float[sizex*sizey];
    float *outbuf_real = new float[sizex*sizey];
    float *outbuf_imag = new float[sizex*sizey];

    for (i = 0; i < sizex*sizey; i++) {
	inbuf_real[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
	inbuf_imag[i] = 0;
    }

    ocaFactory::pointer factory = ocaFactory::getSingleton();

    ocaLookUpBuffer::pointer original = factory->makeLookUpBuffer();
    original->setData(inbuf_real, sizex, sizey, 1);

    ocaDrawableBuffer::pointer FFT1D_real
	= factory->makeDrawableBuffer(sizex, sizey, 1);
    ocaDrawableBuffer::pointer FFT1D_imag
	= factory->makeDrawableBuffer(sizex, sizey, 1);

    ocaProgramFFT::pointer FFT_program = ocaProgramFFT::getSingleton();

    cout << "Performing 1D FFT in S." << endl;
  // Compute FFT with Graphics card.
    FFT_program->FFT1DS(original, 
			ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton()),
			FFT1D_real, FFT1D_imag);
    FFT1D_real->getData(outbuf_real);
    FFT1D_imag->getData(outbuf_imag);

  // Compute FFT (in place) with traditional function.
    for (i = 0; i < sizey; i++) {
	FFT(1, lg_sizex, inbuf_real + i*sizex, inbuf_imag + i*sizex);
    }

    cout << "Checking data." << endl;
    for (i = 0; i < sizex*sizey; i++) {
	if (   !EQUAL(inbuf_real[i], outbuf_real[i])
	    || !EQUAL(inbuf_imag[i], outbuf_imag[i]) ) {
	    cout << inbuf_real[i] << " + " << inbuf_imag[i] << "i" << endl;
	    cout << outbuf_real[i] << " + " << outbuf_imag[i] << "i" << endl;
	    ocaRaiseError("FFTs don't agree!");
	}
    }
    cout << "FFT correct." << endl;

    ocaDrawableBuffer::pointer FFT2D_real
	= factory->makeDrawableBuffer(sizex, sizey, 1);
    ocaDrawableBuffer::pointer FFT2D_imag
	= factory->makeDrawableBuffer(sizex, sizey, 1);

    cout << "Performing 1D FFT in T." << endl;
  // Compute FFT with Graphics card.
    FFT_program->FFT1DT(FFT1D_real->getSharedLookUpBuffer(),
			FFT1D_imag->getSharedLookUpBuffer(),
			FFT2D_real, FFT2D_imag);
    FFT2D_real->getData(outbuf_real);
    FFT2D_imag->getData(outbuf_imag);

  // Compute FFT (in place) with traditional function.
    float *tmp_real = new float[sizey];
    float *tmp_imag = new float[sizey];
    for (i = 0; i < sizex; i++) {
	int j;
	for (j = 0; j < sizey; j++) {
	    tmp_real[j] = inbuf_real[j*sizex + i];
	    tmp_imag[j] = inbuf_imag[j*sizex + i];
	}
	FFT(1, lg_sizey, tmp_real, tmp_imag);
	for (j = 0; j < sizey; j++) {
	    inbuf_real[j*sizex + i] = tmp_real[j];
	    inbuf_imag[j*sizex + i] = tmp_imag[j];
	}
    }
    delete[] tmp_real;
    delete[] tmp_imag;

    cout << "Checking data." << endl;
    for (i = 0; i < sizex*sizey; i++) {
	if (   !EQUAL(inbuf_real[i], outbuf_real[i])
	    || !EQUAL(inbuf_imag[i], outbuf_imag[i]) ) {
	    cout << inbuf_real[i] << " + " << inbuf_imag[i] << "i" << endl;
	    cout << outbuf_real[i] << " + " << outbuf_imag[i] << "i" << endl;
	    ocaRaiseError("FFTs don't agree!");
	}
    }
    cout << "FFT correct." << endl;

    cout << "Performing 2D FFT." << endl;
    FFT_program->FFT2D(original, 
		       ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton()),
		       FFT2D_real, FFT2D_imag);
    FFT2D_real->getData(outbuf_real);
    FFT2D_imag->getData(outbuf_imag);

    cout << "Checking data." << endl;
    for (i = 0; i < sizex*sizey; i++) {
	if (   !EQUAL(inbuf_real[i], outbuf_real[i])
	    || !EQUAL(inbuf_imag[i], outbuf_imag[i]) ) {
	    cout << inbuf_real[i] << " + " << inbuf_imag[i] << "i" << endl;
	    cout << outbuf_real[i] << " + " << outbuf_imag[i] << "i" << endl;
	    ocaRaiseError("FFTs don't agree!");
	}
    }
    cout << "FFT correct." << endl;

    delete[] inbuf_real;
    delete[] inbuf_imag;
    delete[] outbuf_real;
    delete[] outbuf_imag;
}


int SimpleFFT(int, char *[])
{
    srand((unsigned int)time(NULL));

    try {
	DoFFT(rand()%MAX_LOG_DIM, rand()%MAX_LOG_DIM);
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();

    return 0;
}
