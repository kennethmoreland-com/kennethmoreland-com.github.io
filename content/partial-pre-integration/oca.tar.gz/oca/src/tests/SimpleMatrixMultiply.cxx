// -*- c++ -*-

// Tests this simple matrix multiply program.

#include <ocaLookUpBuffer.h>
#include <ocaDrawableBuffer.h>
#include <ocaFactory.h>
#include <ocaError.h>
#include <ocaProgramMatrixMultiply.h>

#include <iostream>
#include <stdlib.h>
#include <time.h>

using std::cout;
using std::endl;

#define MAX_DIM	100
#define MIN_VALUE -2.0f
#define MAX_VALUE 5.0f

#define ABS(x)	((x) < 0 ? -(x) : (x))
#define EPSILON	0.0001
#define EQUAL(x1,x2)	(   (EPSILON > ABS(x1-x2))		\
			 || (ABS(EPSILON*x1) > ABS(x1-x2)))

static void DoMatrixMult(int rows, int cols, int intermediate)
{
    cout << "Matrix A: " << rows << "x" << intermediate << endl;
    cout << "Matrix B: " << intermediate << "x" << cols << endl;
    cout << "Matrix C: " << rows << "x" << cols << endl;

    int i;
    float *bufA = new float[rows*intermediate];
    float *bufB = new float[intermediate*cols];
    float *bufC = new float[rows*cols];

    for (i = 0; i < rows*intermediate; i++) {
	bufA[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    }
    for (i = 0; i < cols*intermediate; i++) {
	bufB[i] = ((float)rand()/(float)RAND_MAX)*(MAX_VALUE-MIN_VALUE) + MIN_VALUE;
    }

    ocaFactory::pointer factory = ocaFactory::getSingleton();

    ocaLookUpBuffer::pointer A = factory->makeLookUpBuffer();
    ocaLookUpBuffer::pointer B = factory->makeLookUpBuffer();
    A->setData(bufA, intermediate, rows, 1);
    B->setData(bufB, cols, intermediate, 1);

    ocaDrawableBuffer::pointer C = factory->makeDrawableBuffer(cols, rows, 1);

    ocaProgramMatrixMultiply::getSingleton()->execute(A, B, C);

    C->getData(bufC);

    cout << "Checking data." << endl;
    for (int r = 0; r < rows; r++) {
	for (int c = 0; c < cols; c++) {
	    float v = 0;
	    for (int k = 0; k < intermediate; k++) {
		v += bufA[r*intermediate + k]
		    *bufB[k*cols + c];
	    }
	    if (!EQUAL(v,bufC[r*cols + c])) {
		cout << v << endl;
		cout << bufC[r*cols + c] << endl;
		ocaRaiseError("Matrices don't agree!");
	    }
	}
    }
    cout << "Multiplication correct." << endl;

    delete[] bufA;
    delete[] bufB;
    delete[] bufC;
}


int SimpleMatrixMultiply(int, char *[])
{
    int rows, cols, intermediate;

    srand((unsigned int)time(NULL));
    rows = rand()%MAX_DIM + 1;
    cols = rand()%MAX_DIM + 1;
    intermediate = rand()%MAX_DIM + 1;

    try {
	DoMatrixMult(rows, cols, intermediate);
	DoMatrixMult(rows, cols, 1);
    } catch (ocaError &error) {
	cout << "Got an error:" << endl
	     << error.getMessage() << endl;
	ocaObject::finalize();
	return 1;
    }
    ocaObject::finalize();

    return 0;
}
