// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaDrawableBuffer.cxx,v 1.16 2003-06-30 17:56:01 kmorel Exp $

#include "ocaDrawableBuffer.h"
#include "ocaLookUpBuffer.h"

#include "ocaError.h"
#include "ocaOpenGLExtensions.h"
#include "ocaProgramPassThrough.h"
#include "ocaFactory.h"

#ifdef WIN32
#define USE_RENDER_TEXTURE	1
#else
#define USE_RENDER_TEXTURE	0
#include <X11/Xmu/StdCmap.h>
#include <X11/Xatom.h>
#endif

static inline GLenum getFormat(int vecsize)
{
    switch (vecsize) {
      case 1: return GL_RED;
      case 2: ocaRaiseError("2 vectors not supported yet.");
      case 3: return GL_RGB;
      case 4: return GL_RGBA;
    }
    ocaRaiseError("Bad vector size: " + oca_itos(vecsize));
}
static inline GLenum getInternalFormat(int vecsize)
{
    switch (vecsize) {
      case 1: return GL_FLOAT_R_NV;
      case 2: return GL_FLOAT_RG_NV;
      case 3: return GL_FLOAT_RGB_NV;
      case 4: return GL_FLOAT_RGBA_NV;
    }
    ocaRaiseError("Bad vector size: " + oca_itos(vecsize));
}

ocaDrawableBuffer::ocaDrawableBuffer()
{
    this->size[0] = 0;  this->size[1] = 0;
    this->vectorSize = 0;
    this->lubBound = false;
}

ocaDrawableBuffer::~ocaDrawableBuffer()
{
    if (this->valid) {
	this->releaseLookUpBuffer();
#if WIN32
	ocagl.ReleasePbufferDCARB(this->hPbuffer, this->hDC);
	wglDeleteContext(this->hRC);
	ocagl.DestroyPbufferARB(this->hPbuffer);
#else
	glXDestroyGLXPixmap(this->DisplayId, this->DrawableId);
	XFreePixmap(this->DisplayId, this->pixmapId);
#endif
    }

    if (!this->sharedLookUp.isNull()) {
	this->sharedLookUp->invalidateDrawable();
    }
}


const int *ocaDrawableBuffer::getSize() const
{
    return this->size;
}

int ocaDrawableBuffer::getVectorSize() const
{
    return this->vectorSize;
}

void ocaDrawableBuffer::getData(float *buffer) const
{
    ocaOpenGLContext::ScopedContext saveContext;
    this->makeCurrent();
    glReadPixels(0, 0, this->size[0], this->size[1],
		 getFormat(this->vectorSize), GL_FLOAT, buffer);
}

void ocaDrawableBuffer::setData(float *buffer)
{
    ocaLookUpBuffer::pointer tmpbuffer
	= ocaFactory::getSingleton()->makeLookUpBuffer();
    tmpbuffer->setData(buffer, this->size[0], this->size[1], this->vectorSize);
    this->copy(ocaCast<ocaBuffer>(tmpbuffer));
}

void ocaDrawableBuffer::copy(const ocaBuffer::pointer &src)
{
    if (this->lubBound) {
	ocaRaiseError("Cannot set drawable buffer's data while texture bound.");
    }

    const ocaLookUpBuffer::pointer lubsrc = ocaCast<ocaLookUpBuffer>(src);
    if (!lubsrc.isNull()) {
	ocaProgramPassThrough::pointer passthrough
	    = ocaProgramPassThrough::getSingleton();
	passthrough->execute(lubsrc, this);
	return;
    }

    const ocaDrawableBuffer::pointer drawsrc = ocaCast<ocaDrawableBuffer>(src);
    if (!drawsrc.isNull()) {
	bool bound = drawsrc->isBoundToLookUp();
	ocaLookUpBuffer::pointer sharedlubsrc
	    = drawsrc->getSharedLookUpBuffer();
	this->copy(ocaCast<ocaBuffer>(sharedlubsrc));
	if (!bound) {
	    drawsrc->releaseLookUpBuffer();
	}
	return;
    }

    const ocaOpenGLContext::pointer openglsrc = ocaCast<ocaOpenGLContext>(src);
    if (!openglsrc.isNull()) {
	ocaLookUpBuffer::pointer lubsrc
	    = ocaFactory::getSingleton()->makeLookUpBuffer();
	lubsrc->copy(src);
	this->copy(ocaCast<ocaBuffer>(lubsrc));
    }

    this->super::copy(src);
}

bool ocaDrawableBuffer::isValid() const
{
    if (this->lubBound) return false;
    return this->ocaOpenGLContext::isValid();
}

bool ocaDrawableBuffer::isBoundToLookUp() const
{
    return this->lubBound;
}

void ocaDrawableBuffer::clear()
{
    ocaOpenGLContext::ScopedContext;
    this->makeCurrent();
    ocaDrawableBuffer::clearCurrent();
}

void ocaDrawableBuffer::clearCurrent()
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);
}

ocaLookUpBuffer::pointer ocaDrawableBuffer::getSharedLookUpBuffer()
{
  // Create look up buffer if necessary
    if (this->sharedLookUp.isNull()) {
	this->sharedLookUp = new ocaDrawableBuffer::SharedLookUp(this);
    }

  // Make image equal to buffer image.
//     ocaOpenGLContext::ScopedContext saveContext;
//     ocaFactory::pointer factory = ocaFactory::getSingleton();
//     factory->makeCurrent();
//     ocaLookUpBuffer::ScopedBinding saveBinding(factory);
    ocaLookUpBuffer::ScopedBinding saveBinding(ocaOpenGLContext::getCurrent());
    this->sharedLookUp->bind();
    this->bindToLookUpBuffer();

  // Return look up buffer.
    return ocaCast<ocaLookUpBuffer>(this->sharedLookUp);
}

void ocaDrawableBuffer::releaseLookUpBuffer()
{
    if (!this->lubBound) return;
#if USE_RENDER_TEXTURE
    BOOL noerr;
    noerr = ocagl.ReleaseTexImageARB(this->hPbuffer, WGL_FRONT_LEFT_ARB);
    if (!noerr) {
	ocaRaiseError("Could not release drawable from lookup buffer: "
		      + oca_itos(GetLastError() & 0x0000FFFF));
    }
#endif
    this->lubBound = false;
}

void ocaDrawableBuffer::bindToLookUpBuffer()
{
#if USE_RENDER_TEXTURE
    BOOL noerr;
    noerr = ocagl.BindTexImageARB(this->hPbuffer, WGL_FRONT_LEFT_ARB);
    if (!noerr) {
	ocaRaiseError("Could not bind drawable to lookup buffer: "
		      + oca_itos(GetLastError() & 0x0000FFFF));
    }
#else
    printf("Warning: copying texture instead of using render texture\n");
    ocaLookUpBuffer::getCurrent()->copy(this);
#endif

    this->lubBound = true;
}

#ifdef WIN32
ocaDrawableBuffer::pointer ocaDrawableBuffer::create(int width, int height,
						     int vectorSize,
						     HWND hWnd, HDC parentHDC,
						     HGLRC parentHRC)
{
    ocaDrawableBuffer::pointer newdb(new ocaDrawableBuffer);

    static GLint attribIList[] = {
	WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB,
	WGL_FLOAT_COMPONENTS_NV, GL_TRUE,
	WGL_DRAW_TO_PBUFFER_ARB, GL_TRUE,
	WGL_BIND_TO_TEXTURE_RECTANGLE_FLOAT_RGBA_NV, GL_TRUE,
	WGL_COLOR_BITS_ARB, 96,
	WGL_ACCELERATION_ARB, WGL_FULL_ACCELERATION_ARB,
	WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
	WGL_DOUBLE_BUFFER_ARB, GL_FALSE,
	0
    };
    int pixelFormatId;
    UINT numPixelFormats;

    newdb->hWnd = hWnd;
    int success = ocagl.ChoosePixelFormatARB(parentHDC, attribIList, NULL, 1,
					     &pixelFormatId, &numPixelFormats);
    if (!success || (numPixelFormats < 1)) {
	ocaRaiseError("Could not get pixel format for pbuffer: "
		      + oca_itos(GetLastError() & 0x0000FFFF));
    }

    static int pBufferAttrib[] = {
	WGL_TEXTURE_FORMAT_ARB, WGL_TEXTURE_FLOAT_RGBA_NV,
	WGL_TEXTURE_TARGET_ARB, WGL_TEXTURE_RECTANGLE_NV,
	WGL_MIPMAP_TEXTURE_ARB, 0,
	0
    };
    newdb->hPbuffer = ocagl.CreatePbufferARB(parentHDC, pixelFormatId,
					     width, height, pBufferAttrib);
    if (newdb->hPbuffer == NULL) {
	ocaRaiseError("Could not create pbuffer: "
		      + oca_itos(GetLastError() & 0x0000FFFF));
    }
    newdb->hDC = ocagl.GetPbufferDCARB(newdb->hPbuffer);

    SetPixelFormat(newdb->hDC, pixelFormatId, NULL);

    newdb->hRC = wglCreateContext(newdb->hDC);

    wglShareLists(parentHRC, newdb->hRC);

    newdb->size[0] = width;  newdb->size[1] = height;
    newdb->vectorSize = vectorSize;
    newdb->lubBound = false;
    newdb->valid = true;

    return newdb;
}

#else // Must be UNIX

ocaDrawableBuffer::pointer ocaDrawableBuffer::create(int width, int height,
						     int vectorsize,
						     Display *displayId,
						     GLXContext parentContext)
{
    ocaDrawableBuffer::pointer newdb(new ocaDrawableBuffer);

    static int attrib_list[] = {
	GLX_RENDER_TYPE_SGIX, GLX_RGBA_BIT_SGIX,
	GLX_DRAWABLE_TYPE_SGIX, GLX_PIXMAP_BIT_SGIX,
	None
    };
    int num_attribs;

    newdb->DisplayId = displayId;
    GLXFBConfigSGIX *FBconfig
	= ocagl.ChooseFBConfigSGIX(displayId, DefaultScreen(displayId),
				   attrib_list, &num_attribs);
    if (FBconfig == NULL) {
	ocaRaiseError("Could not get proper X configuration.");
    }

    newdb->ContextId = ocagl.CreateContextWithConfigSGIX(displayId,
							 FBconfig[0],
							 GLX_RGBA_TYPE_SGIX,
							 NULL /*SHARING!*/,
							 GL_TRUE);

    newdb->pixmapId = XCreatePixmap(displayId,
				    RootWindow(displayId,
					       DefaultScreen(displayId)),
				    width, height, 24 /*Query from FBconfig?*/);

    newdb->DrawableId = ocagl.CreateGLXPixmapWithConfigSGIX(displayId,
							    FBconfig[0],
							    newdb->pixmapId);

    XFree(FBconfig);

#if 0
    XVisualInfo *visualInfo = glXChooseVisual(displayId,
					      DefaultScreen(displayId),
					      attribIList);
    if (visualInfo == NULL) {
	ocaRaiseError("Could not get proper X visual");
    }

    int found_shared_colormap = 0;
    Colormap colormap;
    status = XmuLookupStandardColormap(displayId, visualInfo->screen,
				       visualInfo->visualid, visualInfo->depth,
				       XA_RGB_DEFAULT_MAP, 0, 1);
    if (status == 1) {
	XStandardColormap *standardCmaps;
	int numCmaps;
	status = XGetRGBColormaps(displayId, RootWindow(displayId,
							visualInfo->screen),
				  &standardCmaps, &numCmaps,
				  XA_RGB_DEFAULT_MAP);
	if (status == 1) {
	    for (int i = 0; i < numCmaps; i++) {
		if (standardCmaps[i].visualid == visualInfo->visualid) {
		    colormap = standardCmaps[i].colormap;
		    found_shared_colormap = 1;
		    break;
		}
	    }
	    XFree(standardCmaps);
	}
    }
    if (!found_shared_colormap) {
      /* Create unshared colormap. */
	colormap = XCreateColormap(displayId, RootWindow(displayId,
							 visualInfo->screen),
				   visualInfo->visual, AllocNone);
    }

    newdb->ContextId = glXCreateContext(displayId, visualInfo, parentContext,
					GL_TRUE);
    if (newdb->ContextId == NULL) {
	ocaRaiseError("Could not create rendering context.");
    }

    newdb->pixmapId = XCreatePixmap(displayId, RootWindow(displayId,
							  visualInfo->screen),
				    width, height, visualInfo->depth);

    newdb->DrawableId =  glXCreateGLXPixmap(displayId, visualInfo,
					    newdb->pixmapId);
#endif

    newdb->size[0] = width;  newdb->size[1] = height;
    newdb->vectorSize = vectorsize;
    newdb->lubBound = false;
    newdb->valid = true;

    return newdb;
}

#endif

ocaDrawableBuffer::SharedLookUp::SharedLookUp(ocaDrawableBuffer *source)
    : ocaLookUpBuffer(ocaFactory::getSingleton())
{
    this->drawable = source;
    source->ocaBuffer::getSize(this->size);
    this->vectorSize = source->getVectorSize();
}

void ocaDrawableBuffer::SharedLookUp::invalidateDrawable()
{
    this->drawable = NULL;
}
