// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// Computes the volume rendering equation by computing the horrendous
// solution for linear interpolates.
//
// $Id: ocaProgramVolumeRenderingIntegrateDirectLinear.h,v 1.2 2003-09-25 22:29:33 kmorel Exp $

#ifndef _ocaProgramVolumeRenderingIntegrateDirectLinear_h
#define _ocaProgramVolumeRenderingIntegrateDirectLinear_h

#include "ocaProgramVolumeRenderingIntegrate.h"

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateDirectLinear
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateDirectLinear);
};

#endif //_ocaProgramVolumeRenderingIntegrateDirectLinear_h
