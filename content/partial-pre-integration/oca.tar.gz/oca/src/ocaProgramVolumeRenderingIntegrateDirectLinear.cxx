// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramVolumeRenderingIntegrateDirectLinear.cxx,v 1.1 2003-09-16 23:00:36 kmorel Exp $

#include "ocaProgramVolumeRenderingIntegrateDirectLinear.h"

ocaProgramVolumeRenderingIntegrateDirectLinear
    ::ocaProgramVolumeRenderingIntegrateDirectLinear()
{
    this->loadProgram("vri_direct_linear.cg",
		      "VolumeRenderingIntegrateDirectLinearVert",
		      "VolumeRenderingIntegrateDirectLinearFrag");
}

ocaProgramVolumeRenderingIntegrateDirectLinear
    ::~ocaProgramVolumeRenderingIntegrateDirectLinear()
{
}
