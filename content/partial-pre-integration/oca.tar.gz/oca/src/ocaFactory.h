// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaFactory.h,v 1.7 2003-06-30 17:56:01 kmorel Exp $

#ifndef _ocaFactory_h
#define _ocaFactory_h

#include "ocaOpenGLContext.h"

class ocaDrawableBuffer;
class ocaLookUpBuffer;

class OCA_EXPORT ocaFactory : public ocaOpenGLContext
{
  public:
    ocaSingletonMacro(ocaFactory, ocaOpenGLContext);

    ocaSmartPointer<ocaDrawableBuffer> makeDrawableBuffer(int width, int height,
							  int vectorSize);
    ocaSmartPointer<ocaLookUpBuffer> makeLookUpBuffer();

    const int *getSize() const;
    int getVectorSize() const;
    void getData(float *buffer) const;
    void setData(float *buffer);

    ~ocaFactory();

  protected:
    ocaFactory();
#ifdef WIN32
    HINSTANCE hInstance;
#else
    Pixmap PixmapId;
#endif
};

#endif _ocaFactory_h
