// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// "Solves" the volume rendering equation by averaging the color and
// attenuation and then performing the homogeneous solution.
//
// $Id: ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation.h,v 1.1 2004-04-08 15:56:29 kmorel Exp $

#ifndef _ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation_h
#define _ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation_h

#include "ocaProgramVolumeRenderingIntegrate.h"

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateAverageColorAverageAttenuation);
};

#endif //_ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation_h
