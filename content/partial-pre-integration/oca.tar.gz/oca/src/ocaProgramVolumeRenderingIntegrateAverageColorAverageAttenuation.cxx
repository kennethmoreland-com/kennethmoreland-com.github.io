// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation.cxx,v 1.1 2004-04-08 15:56:29 kmorel Exp $

#include "ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation.h"

ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation
    ::ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation()
{
    this->loadProgram("vri_average_color_average_attenuation.cg",
		      "mainvert", "mainfrag");
}

ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation
    ::~ocaProgramVolumeRenderingIntegrateAverageColorAverageAttenuation()
{
}
