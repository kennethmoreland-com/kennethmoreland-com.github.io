// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramVolumeRenderingIntegratePartialPreIntegration.cxx,v 1.2 2003-09-28 23:41:26 kmorel Exp $

#include "ocaProgramVolumeRenderingIntegratePartialPreIntegration.h"

#include "PsiGammaTable.h"
#include "ocaFactory.h"
#include "ocaLookUpBuffer.h"
#include "ocaCgError.h"

#define STRINGIFY(x)	#x
#define STRINGIFY2(x)	STRINGIFY(x)

static const char *compilerArgs[] = {
    "-DPSI_TABLE_RESOLUTION=float2(" STRINGIFY2(PSI_GAMMA_TABLE_BACK_RES) "," STRINGIFY2(PSI_GAMMA_TABLE_FRONT_RES) ")",
    NULL
};

ocaProgramVolumeRenderingIntegratePartialPreIntegration
    ::ocaProgramVolumeRenderingIntegratePartialPreIntegration()
{
    this->fragProfile = CG_PROFILE_FP30;

    this->loadProgram("vri_part_preint.cg",
		      "VolumeRenderingIntegratePartialPreIntegrationVert",
		      "VolumeRenderingIntegratePartialPreIntegrationFrag",
		      compilerArgs);

    cgDestroyProgram(this->fragProgram);
    std::string fullFilename = ocaProgram::sourceDirectory + "vri_part_preint.fp";
    try {
	this->fragProgram = cgCreateProgramFromFile(this->programContext,
						    CG_OBJECT,
						    fullFilename.c_str(),
						    this->fragProfile,
						    "VolumeRenderingIntegratePartialPreIntegrationFrag",
						    NULL);
	cgGLLoadProgram(this->fragProgram);
	this->Incoming = cgGetNamedParameter(this->fragProgram, "Incoming");
    } catch (ocaCgError &cgError) {
	throw ocaCgError(cgError.getError(), this->programContext);
    }

    this->PsiGammaTable = cgGetNamedParameter(this->fragProgram,
					      "PsiGammaTable");
    if (this->PsiGammaTable == NULL) {
	ocaRaiseError("Could not get pointer for parameter PsiGammaTable");
    }

    this->PsiGammaTableLookup =
	ocaFactory::getSingleton()->makeLookUpBuffer();
    this->PsiGammaTableLookup->setData((float *)psi_gamma_table,
				       PSI_GAMMA_TABLE_BACK_RES,
				       PSI_GAMMA_TABLE_FRONT_RES, 1);
}

ocaProgramVolumeRenderingIntegratePartialPreIntegration
    ::~ocaProgramVolumeRenderingIntegratePartialPreIntegration()
{
}

void ocaProgramVolumeRenderingIntegratePartialPreIntegration::bind()
{
    this->super::bind();
    cgGLSetTextureParameter(this->PsiGammaTable,
			    this->PsiGammaTableLookup->getTextureId());
    cgGLEnableTextureParameter(this->PsiGammaTable);
}

void ocaProgramVolumeRenderingIntegratePartialPreIntegration::unbind()
{
    cgGLDisableTextureParameter(this->PsiGammaTable);
    this->super::unbind();
}
