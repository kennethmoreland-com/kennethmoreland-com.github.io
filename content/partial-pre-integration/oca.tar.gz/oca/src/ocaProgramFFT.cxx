// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT.cxx,v 1.7 2003-06-30 17:56:02 kmorel Exp $

#include "ocaProgramFFT.h"

#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"
#include "ocaZeroBuffer.h"
#include "ocaFactory.h"

#define GET_PROGRAM_PARAMETER(paramname, parameter)			\
    parameter = cgGetNamedParameter(this->fragProgram, paramname);	\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }

const static char *RealCompilerArgs[] = { "-DCALCULATE_REAL", NULL, NULL };
const static char *ImagCompilerArgs[] = { "-DCALCULATE_IMAGINARY", NULL, NULL };

const static GLfloat fullScreenSquare[] = {
    -1.0, -1.0,
    1.0, -1.0,
    1.0, 1.0,
    -1.0, 1.0
};

// Prototypes for individual functions that must be used in conjunction
// for performing any FFT.
static inline void executeFFT(ocaLookUpBuffer::pointer inputReal,
			      ocaLookUpBuffer::pointer inputImaginary,
			      int partitionSize, int fft_dir,
			      ocaProgram::pointer self,
			      CGprogram fragProgram,
			      CGparameter arraySize,
			      CGparameter N,
			      CGparameter numPartitions,
			      CGparameter Xr,
			      CGparameter Xi)
{
    int as = inputReal->getSize()[fft_dir];

    self->bind();
    cgGLSetParameter1f(arraySize, (float)as);
    cgGLSetParameter1f(N, (float)partitionSize);
    cgGLSetParameter1f(numPartitions, (float)(as/partitionSize));
    cgGLSetTextureParameter(Xr, inputReal->getTextureId());
    cgGLEnableTextureParameter(Xr);
    cgGLSetTextureParameter(Xi, inputImaginary->getTextureId());
    cgGLEnableTextureParameter(Xi);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2, GL_FLOAT, 0, fullScreenSquare);
    glDrawArrays(GL_QUADS, 0, 4);
    glDisableClientState(GL_VERTEX_ARRAY);
    cgGLDisableTextureParameter(Xr);
    cgGLDisableTextureParameter(Xi);
    self->unbind();
}

class ocaProgramFFT1DSReal : public ocaProgram
{
  public:
    ocaProgramMacro(FFT1DSReal);
    void execute(ocaLookUpBuffer::pointer inputReal,
		 ocaLookUpBuffer::pointer inputImaginary,
		 int N);
  protected:
    CGparameter arraySize;
    CGparameter N;
    CGparameter numPartitions;
    CGparameter Xr, Xi;
};
ocaProgramFFT1DSReal::ocaProgramFFT1DSReal()
{
    RealCompilerArgs[1] = "-DIN_S_DIM";
    this->loadProgram("fft.cg", NULL, "FFTFrag", RealCompilerArgs);
    GET_PROGRAM_PARAMETER("ArraySize", this->arraySize);
    GET_PROGRAM_PARAMETER("N", this->N);
    GET_PROGRAM_PARAMETER("NumPartitions", this->numPartitions);
    GET_PROGRAM_PARAMETER("Xr", this->Xr);
    GET_PROGRAM_PARAMETER("Xi", this->Xi);
}
ocaProgramFFT1DSReal::~ocaProgramFFT1DSReal()
{
}
void ocaProgramFFT1DSReal::execute(ocaLookUpBuffer::pointer inputReal,
				   ocaLookUpBuffer::pointer inputImaginary,
				   int partitionSize)
{
    executeFFT(inputReal, inputImaginary, partitionSize, 0,
	       this, this->fragProgram,
	       this->arraySize, this->N, this->numPartitions,
	       this->Xr, this->Xi);
}

class ocaProgramFFT1DSImag : public ocaProgram
{
  public:
    ocaProgramMacro(FFT1DSImag);
    void execute(ocaLookUpBuffer::pointer inputReal,
		 ocaLookUpBuffer::pointer inputImaginary,
		 int N);
  protected:
    CGparameter arraySize;
    CGparameter N;
    CGparameter numPartitions;
    CGparameter Xr, Xi;
};
ocaProgramFFT1DSImag::ocaProgramFFT1DSImag()
{
    ImagCompilerArgs[1] = "-DIN_S_DIM";
    this->loadProgram("fft.cg", NULL, "FFTFrag", ImagCompilerArgs);
    GET_PROGRAM_PARAMETER("ArraySize", this->arraySize);
    GET_PROGRAM_PARAMETER("N", this->N);
    GET_PROGRAM_PARAMETER("NumPartitions", this->numPartitions);
    GET_PROGRAM_PARAMETER("Xr", this->Xr);
    GET_PROGRAM_PARAMETER("Xi", this->Xi);
}
ocaProgramFFT1DSImag::~ocaProgramFFT1DSImag()
{
}
void ocaProgramFFT1DSImag::execute(ocaLookUpBuffer::pointer inputReal,
				   ocaLookUpBuffer::pointer inputImaginary,
				   int partitionSize)
{
    executeFFT(inputReal, inputImaginary, partitionSize, 0,
	       this, this->fragProgram,
	       this->arraySize, this->N, this->numPartitions,
	       this->Xr, this->Xi);
}

class ocaProgramFFT1DTReal : public ocaProgram
{
  public:
    ocaProgramMacro(FFT1DTReal);
    void execute(ocaLookUpBuffer::pointer inputReal,
		 ocaLookUpBuffer::pointer inputImaginary,
		 int N);
  protected:
    CGparameter arraySize;
    CGparameter N;
    CGparameter numPartitions;
    CGparameter Xr, Xi;
};
ocaProgramFFT1DTReal::ocaProgramFFT1DTReal()
{
    RealCompilerArgs[1] = "-DIN_T_DIM";
    this->loadProgram("fft.cg", NULL, "FFTFrag", RealCompilerArgs);
    GET_PROGRAM_PARAMETER("ArraySize", this->arraySize);
    GET_PROGRAM_PARAMETER("N", this->N);
    GET_PROGRAM_PARAMETER("NumPartitions", this->numPartitions);
    GET_PROGRAM_PARAMETER("Xr", this->Xr);
    GET_PROGRAM_PARAMETER("Xi", this->Xi);
}
ocaProgramFFT1DTReal::~ocaProgramFFT1DTReal()
{
}
void ocaProgramFFT1DTReal::execute(ocaLookUpBuffer::pointer inputReal,
				   ocaLookUpBuffer::pointer inputImaginary,
				   int partitionSize)
{
    executeFFT(inputReal, inputImaginary, partitionSize, 1,
	       this, this->fragProgram,
	       this->arraySize, this->N, this->numPartitions,
	       this->Xr, this->Xi);
}

class ocaProgramFFT1DTImag : public ocaProgram
{
  public:
    ocaProgramMacro(FFT1DTImag);
    void execute(ocaLookUpBuffer::pointer inputReal,
		 ocaLookUpBuffer::pointer inputImaginary,
		 int N);
  protected:
    CGparameter arraySize;
    CGparameter N;
    CGparameter numPartitions;
    CGparameter Xr, Xi;
};
ocaProgramFFT1DTImag::ocaProgramFFT1DTImag()
{
    ImagCompilerArgs[1] = "-DIN_T_DIM";
    this->loadProgram("fft.cg", NULL, "FFTFrag", ImagCompilerArgs);
    GET_PROGRAM_PARAMETER("ArraySize", this->arraySize);
    GET_PROGRAM_PARAMETER("N", this->N);
    GET_PROGRAM_PARAMETER("NumPartitions", this->numPartitions);
    GET_PROGRAM_PARAMETER("Xr", this->Xr);
    GET_PROGRAM_PARAMETER("Xi", this->Xi);
}
ocaProgramFFT1DTImag::~ocaProgramFFT1DTImag()
{
}
void ocaProgramFFT1DTImag::execute(ocaLookUpBuffer::pointer inputReal,
				   ocaLookUpBuffer::pointer inputImaginary,
				   int partitionSize)
{
    executeFFT(inputReal, inputImaginary, partitionSize, 1,
	       this, this->fragProgram,
	       this->arraySize, this->N, this->numPartitions,
	       this->Xr, this->Xi);
}

/* I THOUGHT I NEEDED THIS, BUT I DON'T. *********************************/
#if 0
class ocaProgramFFTSwapBits : public ocaProgram
{
  public:
    ocaProgramMacro(FFTSwapBits);
    void execute(ocaLookUpBuffer::pointer input,
		 int LogArraySize);
  protected:
    CGparameter logArraySize;
    CGparameter inData;
};
ocaProgramFFTSwapBits::pointer ocaProgramFFTSwapBits::singleton;
ocaProgramFFTSwapBits::ocaProgramFFTSwapBits()
{
    this->loadProgram("indexbitreverse.cg", NULL, "IndexBitReverseFrag");
    GET_PROGRAM_PARAMETER("LogArraySize", this->logArraySize);
    GET_PROGRAM_PARAMETER("inData", this->inData);
}
ocaProgramFFTSwapBits::~ocaProgramFFTSwapBits()
{
    cgFreeBindIter(this->logArraySize);
    cgFreeBindIter(this->inData);
}
void ocaProgramFFTSwapBits::execute(ocaLookUpBuffer::pointer input,
				    int LogArraySize)
{
    cgError err;

    this->bind();
    err = cgGLBindUniform4f(this->fragProgram, this->logArraySize,
			    LogArraySize, 0, 0, 0);
    if (err) ocaRaiseError("Could not bind program parameter LogArraySize");
    err = cgGLActiveTexture(this->inData);
    if (err) ocaRaiseError("Could not activate input");
    input->bind();

    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2, GL_FLOAT, 0, fullScreenSquare);
    glDrawArrays(GL_QUADS, 0, 4);
    glDisableClientState(GL_VERTEX_ARRAY);
}
#endif //Swap bits not needed.


ocaProgramFFT::ocaProgramFFT() {}
ocaProgramFFT::~ocaProgramFFT() {}

template<class FFTreal, class FFTimag>
static void DoFFT(FFTreal realprog, FFTimag imagprog,
		  ocaLookUpBuffer::pointer samplesReal,
		  ocaLookUpBuffer::pointer samplesImaginary,
		  ocaDrawableBuffer::pointer targetReal,
		  ocaDrawableBuffer::pointer targetImag,
		  ocaDrawableBuffer::pointer feedbackReal,
		  ocaDrawableBuffer::pointer feedbackImag,
		  int size)
{
    bool first = true;
    for (int partitionSize = 2; partitionSize <= size; partitionSize *= 2)
    {
      // Set up lookup buffers.
	ocaLookUpBuffer::pointer realLookUp;
	ocaLookUpBuffer::pointer imagLookUp;
	if (first) {
	    realLookUp = samplesReal;
	    imagLookUp = samplesImaginary;
	    first = false;
	} else {
	    realLookUp = feedbackReal->getSharedLookUpBuffer();
	    imagLookUp = feedbackImag->getSharedLookUpBuffer();
	}

      // Run vertex program for both real and imaginary result.
	targetReal->makeCurrent();
	realprog->execute(realLookUp, imagLookUp, partitionSize);

	targetImag->makeCurrent();
	imagprog->execute(realLookUp, imagLookUp, partitionSize);

      // Unbind shared lookup buffers.
	feedbackReal->releaseLookUpBuffer();
	feedbackImag->releaseLookUpBuffer();

      // Switch drawable buffers.
	ocaDrawableBuffer::pointer swap;
	swap = targetReal;
	targetReal = feedbackReal;
	feedbackReal = swap;
	swap = targetImag;
	targetImag = feedbackImag;
	feedbackImag = swap;
    }
}


void ocaProgramFFT::FFT1DS(ocaLookUpBuffer::pointer samplesReal,
			   ocaLookUpBuffer::pointer samplesImaginary,
			   ocaDrawableBuffer::pointer frequenciesReal,
			   ocaDrawableBuffer::pointer frequenciesImaginary)
{
    const int *size = frequenciesReal->getSize();
    int vectorSize = frequenciesReal->getVectorSize();

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer temporary1
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);
    ocaDrawableBuffer::pointer temporary2
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);

    this->FFT1DS(samplesReal, samplesImaginary,
		 frequenciesReal, frequenciesImaginary, temporary1, temporary2);
}

void ocaProgramFFT::FFT1DS(ocaLookUpBuffer::pointer samplesReal,
			   ocaLookUpBuffer::pointer samplesImaginary,
			   ocaDrawableBuffer::pointer frequenciesReal,
			   ocaDrawableBuffer::pointer frequenciesImaginary,
			   ocaDrawableBuffer::pointer temporary1,
			   ocaDrawableBuffer::pointer temporary2)
{
    int size = samplesReal->getSize()[0];
    int logsize = 0;
    int i = size;
    while (1) {
	if (i < 2) break;
	if ((i%2) == 1) ocaRaiseError("FFT input must be a power of 2");
	i >>= 1;
	logsize++;
    }

  // Special case: size is 1, output is just the same as the input.
    if (size == 1) {
	frequenciesReal->copy(ocaCast<ocaBuffer>(samplesReal));
	frequenciesImaginary->copy(ocaCast<ocaBuffer>(samplesImaginary));
	return;
    }

    ocaDrawableBuffer::pointer feedbackReal, feedbackImag;
    ocaDrawableBuffer::pointer targetReal, targetImag;

    if ((logsize%2) == 0) {
	targetReal = temporary1;
	targetImag = temporary2;
	feedbackReal = frequenciesReal;
	feedbackImag = frequenciesImaginary;
    } else {
	feedbackReal = temporary1;
	feedbackImag = temporary2;
	targetReal = frequenciesReal;
	targetImag = frequenciesImaginary;
    }

    DoFFT(ocaProgramFFT1DSReal::getSingleton(),
	  ocaProgramFFT1DSImag::getSingleton(),
	  samplesReal, samplesImaginary,
	  targetReal, targetImag, feedbackReal, feedbackImag, size);
}

void ocaProgramFFT::FFT1DT(ocaLookUpBuffer::pointer samplesReal,
			   ocaLookUpBuffer::pointer samplesImaginary,
			   ocaDrawableBuffer::pointer frequenciesReal,
			   ocaDrawableBuffer::pointer frequenciesImaginary)
{
    const int *size = frequenciesReal->getSize();
    int vectorSize = frequenciesReal->getVectorSize();

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer temporary1
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);
    ocaDrawableBuffer::pointer temporary2
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);

    this->FFT1DT(samplesReal, samplesImaginary,
		 frequenciesReal, frequenciesImaginary, temporary1, temporary2);
}

void ocaProgramFFT::FFT1DT(ocaLookUpBuffer::pointer samplesReal,
			   ocaLookUpBuffer::pointer samplesImaginary,
			   ocaDrawableBuffer::pointer frequenciesReal,
			   ocaDrawableBuffer::pointer frequenciesImaginary,
			   ocaDrawableBuffer::pointer temporary1,
			   ocaDrawableBuffer::pointer temporary2)
{
    int size = samplesReal->getSize()[1];
    int logsize = 0;
    int i = size;
    while (1) {
	if (i < 2) break;
	if ((i%2) == 1) ocaRaiseError("FFT input must be a power of 2");
	i >>= 1;
	logsize++;
    }

  // Special case: size is 1, output is just the same as the input.
    if (size == 1) {
	frequenciesReal->copy(ocaCast<ocaBuffer>(samplesReal));
	frequenciesImaginary->copy(ocaCast<ocaBuffer>(samplesImaginary));
	return;
    }

    ocaDrawableBuffer::pointer feedbackReal, feedbackImag;
    ocaDrawableBuffer::pointer targetReal, targetImag;

    if ((logsize%2) == 0) {
	targetReal = temporary1;
	targetImag = temporary2;
	feedbackReal = frequenciesReal;
	feedbackImag = frequenciesImaginary;
    } else {
	feedbackReal = temporary1;
	feedbackImag = temporary2;
	targetReal = frequenciesReal;
	targetImag = frequenciesImaginary;
    }

    DoFFT(ocaProgramFFT1DTReal::getSingleton(),
	  ocaProgramFFT1DTImag::getSingleton(),
	  samplesReal, samplesImaginary,
	  targetReal, targetImag, feedbackReal, feedbackImag, size);
}

void ocaProgramFFT::FFT2D(ocaLookUpBuffer::pointer samplesReal,
			  ocaLookUpBuffer::pointer samplesImaginary,
			  ocaDrawableBuffer::pointer frequenciesReal,
			  ocaDrawableBuffer::pointer frequenciesImaginary)
{
    const int *size = frequenciesReal->getSize();
    int vectorSize = frequenciesReal->getVectorSize();

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer temporary1
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);
    ocaDrawableBuffer::pointer temporary2
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);

    this->FFT2D(samplesReal, samplesImaginary,
		frequenciesReal, frequenciesImaginary, temporary1, temporary2);
}


void ocaProgramFFT::FFT2D(ocaLookUpBuffer::pointer samplesReal,
			  ocaLookUpBuffer::pointer samplesImaginary,
			  ocaDrawableBuffer::pointer frequenciesReal,
			  ocaDrawableBuffer::pointer frequenciesImaginary,
			  ocaDrawableBuffer::pointer temporary1,
			  ocaDrawableBuffer::pointer temporary2)
{
    const int *size = samplesReal->getSize();
    int logsize_x = 0;
    int i = size[0];
    while (1) {
	if (i < 2) break;
	if ((i%2) == 1) ocaRaiseError("FFT input must be a power of 2");
	i >>= 1;
	logsize_x++;
    }
    int logsize_y = 0;
    i = size[1];
    while (1) {
	if (i < 2) break;
	if ((i%2) == 1) ocaRaiseError("FFT input must be a power of 2");
	i >>= 1;
	logsize_y++;
    }

  // Special case: size is 1x1, output is just the same as the input.
    if ((size[0] == 1) && (size[1] == 1)) {
	frequenciesReal->copy(ocaCast<ocaBuffer>(samplesReal));
	frequenciesImaginary->copy(ocaCast<ocaBuffer>(samplesImaginary));
	return;
    }

    ocaDrawableBuffer::pointer feedbackReal, feedbackImag;
    ocaDrawableBuffer::pointer targetReal, targetImag;

    if (((logsize_x+logsize_y)%2) == 0) {
	targetReal = temporary1;
	targetImag = temporary2;
	feedbackReal = frequenciesReal;
	feedbackImag = frequenciesImaginary;
    } else {
	feedbackReal = temporary1;
	feedbackImag = temporary2;
	targetReal = frequenciesReal;
	targetImag = frequenciesImaginary;
    }

  // Do "Horizontal" FFT.
    DoFFT(ocaProgramFFT1DSReal::getSingleton(),
	  ocaProgramFFT1DSImag::getSingleton(),
	  samplesReal, samplesImaginary,
	  targetReal, targetImag, feedbackReal, feedbackImag, size[0]);

  // Make target and feedback meaningful again.
    if ((logsize_x%2) == 1) {
	ocaDrawableBuffer::pointer swap;
	swap = targetReal;
	targetReal = feedbackReal;
	feedbackReal = swap;
	swap = targetImag;
	targetImag = feedbackImag;
	feedbackImag = swap;
    }

  // Get appropriate data buffer.
    if (logsize_x > 0) {
	samplesReal = feedbackReal->getSharedLookUpBuffer();
	samplesImaginary = feedbackImag->getSharedLookUpBuffer();
    }

  // Do "Vertical" FFT.
    DoFFT(ocaProgramFFT1DTReal::getSingleton(),
	  ocaProgramFFT1DTImag::getSingleton(),
	  samplesReal, samplesImaginary,
	  targetReal, targetImag, feedbackReal, feedbackImag, size[1]);
}
