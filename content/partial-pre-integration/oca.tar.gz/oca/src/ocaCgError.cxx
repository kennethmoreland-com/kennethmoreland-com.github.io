// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaCgError.cxx,v 1.3 2003-06-30 17:56:01 kmorel Exp $

#include "ocaCgError.h"

using std::string;

ocaCgError::ocaCgError()
{
    this->cgErrorCode = CG_NO_ERROR;
}

ocaCgError::ocaCgError(CGerror code)
{
    this->cgErrorCode = code;
    this->message = cgGetErrorString(this->cgErrorCode);
}

ocaCgError::ocaCgError(CGerror code, CGcontext context)
{
    this->cgErrorCode = code;
    this->message = cgGetErrorString(this->cgErrorCode);
    if ((this->cgErrorCode == CG_COMPILER_ERROR) && context) {
	this->message.append("\n");
	this->message.append(cgGetLastListing(context));
    }
}

