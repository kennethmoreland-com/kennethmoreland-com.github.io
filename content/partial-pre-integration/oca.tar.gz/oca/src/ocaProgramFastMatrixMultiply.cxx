// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFastMatrixMultiply.cxx,v 1.5 2003-06-30 17:56:02 kmorel Exp $

#include "ocaProgramFastMatrixMultiply.h"

#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"
#include "ocaZeroBuffer.h"
#include "ocaFactory.h"

#include <iostream>

#define GET_PROGRAM_PARAMETER(program, paramname, parameter)		\
    parameter = cgGetNamedParameter(program, paramname);		\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }

ocaProgramFastMatrixMultiply::ocaProgramFastMatrixMultiply()
{
    this->loadProgram("fastmatrixmultiply.cg",
		      "FastMatrixMultiplyVert", "FastMatrixMultiplyFrag");

    GET_PROGRAM_PARAMETER(this->vertProgram, "input.position", this->position);
    GET_PROGRAM_PARAMETER(this->fragProgram, "A", this->matrixA);
    GET_PROGRAM_PARAMETER(this->fragProgram, "B", this->matrixB);
    GET_PROGRAM_PARAMETER(this->fragProgram, "ACCUM", this->matrixACCUM);
    GET_PROGRAM_PARAMETER(this->fragProgram, "k", this->iteration);
}

ocaProgramFastMatrixMultiply::~ocaProgramFastMatrixMultiply()
{
}

void ocaProgramFastMatrixMultiply::execute(ocaLookUpBuffer::pointer matrixA,
					   ocaLookUpBuffer::pointer matrixB,
					 ocaDrawableBuffer::pointer destination)
{
    ocaDrawableBuffer::pointer temporary(NULL);
    if (matrixA->getSize()[0] > 1) {
	const int *size = destination->getSize();
	int vs = destination->getVectorSize();
	temporary
	    = ocaFactory::getSingleton()->makeDrawableBuffer(size[0], size[1],
							     vs);
    }
    this->execute(matrixA, matrixB, destination, temporary);
}

static GLfloat fullScreenSquare[] = {
    -1.0, -1.0,
    1.0, -1.0,
    1.0, 1.0,
    -1.0, 1.0
};

void ocaProgramFastMatrixMultiply::execute(ocaLookUpBuffer::pointer matrixA,
					   ocaLookUpBuffer::pointer matrixB,
					 ocaDrawableBuffer::pointer destination,
					   ocaDrawableBuffer::pointer temporary)
{
    if (!temporary.isNull()) {
	const int *size1, *size2;
	size1 = destination->getSize();
	size2 = temporary->getSize();

	if ((size1[0] != size2[0]) || (size1[1] != size2[1])) {
	    ocaRaiseError("Temporary drawable buffer does not have same "
			  "dimensions as destination.");
	}
    }

  // Make sure everything can or does hold 4-tuples.
    if (   (matrixA->getVectorSize() != 4)
	|| (matrixB->getVectorSize() != 4)
	|| (destination->getVectorSize() != 4)
	|| (!temporary.isNull() && (temporary->getVectorSize() != 4)) )
    {
	ocaRaiseError("Inputs and outputs to FastMatrixMultiply must contain "
		      "4-vectors.");
    }

  // Get matrix dimensions and make sure they are consistent.
    int rows, cols;
    int num_iterations;
    int size[2];
    destination->ocaBuffer::getSize(cols, rows);
    cols *= 4;
    if ((rows%4) != 0) {
	ocaRaiseError("Matrix dimensions must be divisible by 4.");
    }

    matrixA->ocaBuffer::getSize(num_iterations, size[0]);
    if (size[0] != rows) {
	ocaRaiseError("Matrix A does not agree with output dimensions.");
    }

    matrixB->ocaBuffer::getSize(size[0], size[1]);
    if (size[0]*4 != cols) {
	ocaRaiseError("Matrix B does not agree with output dimensions.");
    }
    if (size[1] != num_iterations*4) {
	ocaRaiseError("Matrix A and matrix b do not have agreeable dimensions");
    }

  // Establish input textures in both drawables.
    destination->makeCurrent();
    this->bind();
    cgGLSetTextureParameter(this->matrixA, matrixA->getTextureId());
    cgGLEnableTextureParameter(this->matrixA);
    cgGLSetTextureParameter(this->matrixB, matrixB->getTextureId());
    cgGLEnableTextureParameter(this->matrixB);
    cgGLSetParameterPointer(this->position, 2, GL_FLOAT, 0, fullScreenSquare);
    cgGLEnableClientState(this->position);


    if (!temporary.isNull()) {
	temporary->makeCurrent();
	this->bind();
	cgGLSetTextureParameter(this->matrixA, matrixA->getTextureId());
	cgGLEnableTextureParameter(this->matrixA);
	cgGLSetTextureParameter(this->matrixB, matrixB->getTextureId());
	cgGLEnableTextureParameter(this->matrixB);
	cgGLSetParameterPointer(this->position, 2, GL_FLOAT, 0,
				fullScreenSquare);
	cgGLEnableClientState(this->position);

    }

  // Set up output matrices so that the final output is contained in
  // destination.
    ocaDrawableBuffer::pointer feedback;
    ocaDrawableBuffer::pointer target;
    if (num_iterations%2 == 1) {
	target = destination;
	feedback = temporary;
    } else {
	target = temporary;
	feedback = destination;
    }

    for (int k = 0; k < num_iterations; k++) {
	ocaLookUpBuffer::pointer feedbackLub;
	if (k == 0) {
	    feedbackLub 
		= ocaCast<ocaLookUpBuffer>(ocaZeroBuffer::getSingleton());
	} else {
	    feedbackLub = feedback->getSharedLookUpBuffer();
	}
	target->makeCurrent();
	this->bind();

	cgGLSetTextureParameter(this->matrixACCUM, feedbackLub->getTextureId());
	cgGLEnableTextureParameter(this->matrixACCUM);

	cgGLSetParameter1f(this->iteration, (float)k);

      // Run vertex program.
	glDrawArrays(GL_QUADS, 0, 4);

	cgGLDisableTextureParameter(this->matrixACCUM);

      // Swap drawables
	if (k != 0) {
	    feedback->releaseLookUpBuffer();
	}
	ocaDrawableBuffer::pointer tmp = feedback;
	feedback = target;
	target = tmp;
    }

    if (!temporary.isNull()) {
	temporary->makeCurrent();
	cgGLDisableTextureParameter(this->matrixA);
	cgGLDisableTextureParameter(this->matrixB);
	cgGLDisableClientState(this->position);
	this->unbind();
    }

    destination->makeCurrent();
    cgGLDisableTextureParameter(this->matrixA);
    cgGLDisableTextureParameter(this->matrixB);
    cgGLDisableClientState(this->position);
    this->unbind();
}
