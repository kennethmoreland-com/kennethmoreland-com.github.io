// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// "Solves" the volume rendering equation by averaging the color and
// attenuation and then performing the homogeneous solution.
//
// $Id: ocaProgramVolumeRenderingIntegrateInputs.h,v 1.2 2003-09-04 19:40:34 kmorel Exp $

#ifndef _ocaProgramVolumeRenderingIntegrateInputs_h
#define _ocaProgramVolumeRenderingIntegrateInputs_h

#include "ocaProgramVolumeRenderingIntegrate.h"

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateInputs
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateInputs);

    virtual void setOutSelect(float select);
    inline void setOutSelectToBackColor() { this->setOutSelect(0); }
    inline void setOutSelectToFrontColor() { this->setOutSelect(1); }
    inline void setOutSelectToLength() { this->setOutSelect(2); }

  protected:
    CGparameter OutSelect;
};

#endif //_ocaProgramVolumeRenderingIntegrateInputs_h
