// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramVolumeRenderingIntegrate.cxx,v 1.2 2003-09-04 19:40:34 kmorel Exp $

#include "ocaProgramVolumeRenderingIntegrate.h"

#define GET_PROGRAM_PARAMETER(program, paramname, parameter)		\
    parameter = cgGetNamedParameter(program, paramname);		\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }
#define GET_VERT_PROGRAM_PARAMETER(parameter)				\
    GET_PROGRAM_PARAMETER(this->vertProgram, "input." #parameter,	\
			  this->parameter);
#define GET_FRAG_PROGRAM_PARAMETER(parameter)				\
    GET_PROGRAM_PARAMETER(this->fragProgram, #parameter, this->parameter)

void ocaProgramVolumeRenderingIntegrate::loadProgram(const char *filename,
						     const char *vertProgEntry,
						     const char *fragProgEntry,
						     const char **compilerArgs)
{
    this->super::loadProgram(filename, vertProgEntry, fragProgEntry,
			     compilerArgs);
    GET_VERT_PROGRAM_PARAMETER(Position);
    GET_VERT_PROGRAM_PARAMETER(BackColor);
    GET_VERT_PROGRAM_PARAMETER(FrontColor);
    GET_VERT_PROGRAM_PARAMETER(Length);
    GET_FRAG_PROGRAM_PARAMETER(Incoming);
}
