// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaError.h,v 1.4 2003-06-30 17:56:01 kmorel Exp $

// Exception class to be thrown on error.

#ifndef _ocaError_h
#define _ocaError_h

#include "ocaConfig.h"

#include <stdlib.h>
#include <stdio.h>
#include <string>

class OCA_EXPORT ocaError
{
  public:
    inline const char *getMessage() const { return message.c_str(); }

    ocaError();
    ocaError(const char *msg);
    ocaError(std::string msg);
    virtual ~ocaError();

  protected:
    std::string message;
};

std::string OCA_EXPORT oca_itos(int num);
std::string OCA_EXPORT oca_ftos(float num);

#define ocaRaiseError(msg) {						    \
    ocaError _err(__FILE__ ":" + oca_itos(__LINE__) + ": " + std::string(msg));\
  /*printf("%s\n", _err.getMessage());*/				    \
    throw _err;								    \
}

#endif //_ocaError_h
