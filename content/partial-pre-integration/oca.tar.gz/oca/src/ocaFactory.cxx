// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaFactory.cxx,v 1.8 2003-06-30 17:56:01 kmorel Exp $

#include "ocaFactory.h"

#include "ocaError.h"
#include "ocaDrawableBuffer.h"
#include "ocaLookUpBuffer.h"

#ifdef WIN32
static const char WindowClassName[] = "oca";
#else
#include <X11/Xmu/StdCmap.h>
#include <X11/Xatom.h>
#endif

#ifdef WIN32
ocaFactory::ocaFactory()
{
    this->hInstance = GetModuleHandle(NULL);

    WNDCLASS wc;
    wc.style		= CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc	= DefWindowProc;	// We won't handle events.
    wc.cbClsExtra	= 0;
    wc.cbWndExtra	= 0;
    wc.hInstance	= this->hInstance;
    wc.hIcon		= NULL;
    wc.hCursor		= NULL;
    wc.hbrBackground	= NULL;
    wc.lpszMenuName	= NULL;
    wc.lpszClassName	= WindowClassName;

    RegisterClass(&wc);

    this->hWnd = CreateWindow(WindowClassName,
			      "",
			      WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
			      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0,
			      NULL,     // no parent window
			      NULL,     // Use the window class menu.
			      this->hInstance,// This instance owns this window
			      NULL      // We don't use any extra data
			      );
    if (!this->hWnd) {
	ocaRaiseError("Could not create base window.");
    }

    this->hDC = GetDC(this->hWnd);

    PIXELFORMATDESCRIPTOR pfd;
    memset(&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW;
    pfd.iPixelType = PFD_TYPE_RGBA;

  // We perfer to use the wglChoosePixelFormatARB extension, but we can't
  // use this extension until we have an OpenGL context to initialize the
  // extension.  To avoid this chicken-and-egg problem, we create this one
  // window with traditional methods.
    int pixelFormatId = ChoosePixelFormat(this->hDC, &pfd);
    SetPixelFormat(this->hDC, pixelFormatId, &pfd);

    this->hRC = wglCreateContext(this->hDC);

    this->valid = true;
}

ocaFactory::~ocaFactory()
{
    if (this->valid) {
	ReleaseDC(this->hWnd, this->hDC);
	wglDeleteContext(this->hRC);

	DestroyWindow(this->hWnd);
	UnregisterClass(WindowClassName, this->hInstance);

	this->valid = false;
    }
}
#else // Using UNIX
ocaFactory::ocaFactory()
{
    static int attribIList[] = {
	GLX_USE_GL, GL_TRUE,
	GLX_RGBA, GL_TRUE,
	None
    };
    Status status;

    this->DisplayId = XOpenDisplay(getenv("DISPLAY"));
    if (this->DisplayId == NULL) {
	ocaRaiseError("Could not open display "
		      + std::string(getenv("DISPLAY")));
    }
    if (!glXQueryExtension(this->DisplayId, NULL, NULL)) {
	ocaRaiseError("X server does not support OpenGL.");
    }

  // Like in the MS Windows case, we would like to use extensions
  // (GLX_SGIX_fbconfig and GLX_SGIX_pbuffer) to create pbuffers, but
  // don't want to use the extensions until we have successfully queried
  // them.  So the factory will just use an ordinary window.
    XVisualInfo *visualInfo = glXChooseVisual(this->DisplayId,
					      DefaultScreen(this->DisplayId),
					      attribIList);
    if (visualInfo == NULL) {
	ocaRaiseError("Could not get proper X visual");
    }

    int found_shared_colormap = 0;
    Colormap colormap;
    status = XmuLookupStandardColormap(this->DisplayId, visualInfo->screen,
				       visualInfo->visualid, visualInfo->depth,
				       XA_RGB_DEFAULT_MAP, 0, 1);
    if (status == 1) {
	XStandardColormap *standardCmaps;
	int numCmaps;
	status = XGetRGBColormaps(this->DisplayId,
				  RootWindow(this->DisplayId,
					     visualInfo->screen),
				  &standardCmaps, &numCmaps,
				  XA_RGB_DEFAULT_MAP);
	if (status == 1) {
	    for (int i = 0; i < numCmaps; i++) {
		if (standardCmaps[i].visualid == visualInfo->visualid) {
		    colormap = standardCmaps[i].colormap;
		    found_shared_colormap = 1;
		    break;
		}
	    }
	    XFree(standardCmaps);
	}
    }
    if (!found_shared_colormap) {
      /* Create unshared colormap. */
	colormap = XCreateColormap(this->DisplayId,
				   RootWindow(this->DisplayId,
					      visualInfo->screen),
				   visualInfo->visual, AllocNone);
    }

    this->ContextId = glXCreateContext(this->DisplayId, visualInfo,
				       NULL, GL_TRUE);
    if (this->ContextId == NULL) {
	ocaRaiseError("Could not create rendering context.");
    }

    XSetWindowAttributes swa;
    swa.colormap = colormap;
    swa.border_pixel = 0;
    this->DrawableId = XCreateWindow(this->DisplayId,
				     RootWindow(this->DisplayId,
						visualInfo->screen),
				     0, 0, 1, 1, 0, visualInfo->depth,
				     InputOutput, visualInfo->visual,
				     CWBorderPixel | CWColormap, &swa);

    this->valid = true;
}

ocaFactory::~ocaFactory()
{
    if (this->valid) {
	XDestroyWindow(this->DisplayId, this->DrawableId);
    }
}
#endif

ocaDrawableBuffer::pointer ocaFactory::makeDrawableBuffer(int width, int height,
							  int vectorSize)
{
#if WIN32
    return ocaDrawableBuffer::create(width, height, vectorSize,
				     this->hWnd, this->hDC,
				     this->hRC);
#else
    return ocaDrawableBuffer::create(width, height, vectorSize,
				     this->DisplayId, this->ContextId);
#endif
}

ocaLookUpBuffer::pointer ocaFactory::makeLookUpBuffer()
{
    return ocaLookUpBuffer::create(this);
}

const int *ocaFactory::getSize() const
{
    static int size[] = {0, 0};
    return size;
}

int ocaFactory::getVectorSize() const
{
    return 0;
}

void ocaFactory::getData(float *buffer) const
{
    ocaRaiseError("No real data assoicated with factory context.");
}

void ocaFactory::setData(float *buffer)
{
    ocaRaiseError("No real data assoicated with factory context.");
}
