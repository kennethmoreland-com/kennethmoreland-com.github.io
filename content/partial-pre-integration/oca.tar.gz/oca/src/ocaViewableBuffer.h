// -*- c++ -*- *******************************************************

// I started this class, and then decided it would be easier to just
// use glut, so I put it back down.

#ifndef _ocaViewableBuffer_h
#define _ocaViewableBuffer_h

#include "ocaDrawableBuffer.h"

class OCA_EXPORT ocaViewableBuffer : public ocaOpenGLContext
{
  public:
    ocaTypeMacro(ocaViewableBuffer, ocaOpenGLContext);

    virtual const int *getSize() const;
    virtual int getVectorSize() const;
    virtual void getData(float *buffer) const;
    virtual void setData(float *buffer);

    virtual void copy(const ocaBuffer::pointer &src);

  // Clears this buffer.
    virtual void clear();
    virtual void clear(float r, float g, float b, float a);

  // Swaps the front and back buffers.  Contents become unavailable.
    virtual void swapBuffers();

    static ocaViewableBuffer::pointer
	create(int width, int height, int vectorSize,
	       HWND hWnd, HDC parentHDC, HGLRC parentHRC);

  protected:
    ocaViewableBuffer();
    virtual ~ocaViewableBuffer();

    int size[2];
    int vectorSize;
};

#endif //_ocaViewableBuffer_h
