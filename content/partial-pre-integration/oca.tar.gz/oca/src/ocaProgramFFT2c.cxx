// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT2c.cxx,v 1.8 2003-06-30 17:56:02 kmorel Exp $

#include "ocaProgramFFT2c.h"

#include "ocaProgramFFT1c.h"
#include "ocaProgramScale.h"
#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"
#include "ocaFactory.h"

#define GET_VERT_PROGRAM_PARAMETER(paramname, parameter)		\
    parameter = cgGetNamedParameter(this->vertProgram, paramname);	\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }

#define GET_FRAG_PROGRAM_PARAMETER(paramname, parameter)		\
    parameter = cgGetNamedParameter(this->fragProgram, paramname);	\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }

//-----------------------------------------------------------------------------
// Runs the FFT on the lines of real values produced by the 1D FFT.
class ocaProgramFFT1cVerticalReal : public ocaProgramFFT1cHelpers
{
  public:
    ocaProgramMacro(FFT1cVerticalReal);
  protected:
    const static char *compilerArgs[];
};
const char *ocaProgramFFT1cVerticalReal::compilerArgs[] = {
    "-DFFT_DIM=y", "-DCALCULATE_REAL", NULL
};
ocaProgramFFT1cVerticalReal::ocaProgramFFT1cVerticalReal() {
    this->load_program(compilerArgs);
}
ocaProgramFFT1cVerticalReal::~ocaProgramFFT1cVerticalReal() {}


class ocaProgramFFT1cVerticalImag : public ocaProgramFFT1cHelpers
{
  public:
    ocaProgramMacro(FFT1cVerticalImag);
  protected:
    const static char *compilerArgs[];
};
const char *ocaProgramFFT1cVerticalImag::compilerArgs[] = {
    "-DFFT_DIM=y", "-DCALCULATE_IMAGINARY", NULL
};
ocaProgramFFT1cVerticalImag::ocaProgramFFT1cVerticalImag() {
    this->load_program(compilerArgs);
}
ocaProgramFFT1cVerticalImag::~ocaProgramFFT1cVerticalImag() {}


//-----------------------------------------------------------------------------
// Complex FFT programs.

class ocaProgramFFT2cHelpers : public ocaProgram
{
  public:
    void execute(ocaLookUpBuffer::pointer source,
		 int partitionSize, int numPartitions,
		 float *realIndexes, float *imagIndexes,
		 bool forward);
  protected:
    ocaProgramFFT2cHelpers() {}
    void load_program(const char **compilerArgs);
    CGparameter realIndex;
    CGparameter imagIndex;
    CGparameter ArraySizeVert;
    CGparameter ArraySizeFrag;
    CGparameter PartitionSize;
    CGparameter NumPartitions;
    CGparameter Direction;
    CGparameter A;
};

void ocaProgramFFT2cHelpers::load_program(const char **compilerArgs)
{
    this->loadProgram("fft2c.cg", "FFT2cVert", "FFT2cFrag", compilerArgs);
    GET_VERT_PROGRAM_PARAMETER("input.realIndex", this->realIndex);
    GET_VERT_PROGRAM_PARAMETER("input.imagIndex", this->imagIndex);
    GET_VERT_PROGRAM_PARAMETER("ArraySize", this->ArraySizeVert);
    GET_FRAG_PROGRAM_PARAMETER("ArraySize", this->ArraySizeFrag);
    GET_FRAG_PROGRAM_PARAMETER("PartitionSize", this->PartitionSize);
    GET_FRAG_PROGRAM_PARAMETER("NumPartitions", this->NumPartitions);
    GET_FRAG_PROGRAM_PARAMETER("Direction", this->Direction);
    GET_FRAG_PROGRAM_PARAMETER("A", this->A);
}

void ocaProgramFFT2cHelpers::execute(ocaLookUpBuffer::pointer source,
				     int partitionSize, int numPartitions,
				     float *realIndexes, float *imagIndexes,
				     bool forward)
{
    const int *arraySize = source->getSize();

    this->bind();
    cgGLSetParameter2f(this->ArraySizeVert, (float)arraySize[0], 
		       (float)arraySize[1]);
    cgGLSetParameter2f(this->ArraySizeFrag, (float)arraySize[0], 
		       (float)arraySize[1]);
    cgGLSetParameter2f(this->PartitionSize, (float)partitionSize,
		       (float)(partitionSize/2));
    cgGLSetParameter2f(this->NumPartitions, (float)numPartitions,
		       (float)(numPartitions*2));
    cgGLSetParameter1f(this->Direction, forward ? 1.0f : -1.0f);
    cgGLSetTextureParameter(this->A, source->getTextureId());
    cgGLEnableTextureParameter(this->A);

    cgGLEnableClientState(this->realIndex);
    cgGLEnableClientState(this->imagIndex);

    cgGLSetParameterPointer(this->realIndex, 2, GL_FLOAT, 0, realIndexes);
    cgGLSetParameterPointer(this->imagIndex, 2, GL_FLOAT, 0, imagIndexes);

    glDrawArrays(GL_QUADS, 0, 4);

    cgGLDisableClientState(this->realIndex);
    cgGLDisableClientState(this->imagIndex);
    cgGLDisableTextureParameter(this->A);

    this->unbind();
}

// Real lines program ********************************************
const static char *realLinesCompilerArgs[] = { "-DCALCULATE_REAL", NULL };

class ocaProgramFFT2cRealLines : public ocaProgramFFT2cHelpers
{
  public:
    ocaProgramMacro(FFT2cRealLines);
};
ocaProgramFFT2cRealLines::ocaProgramFFT2cRealLines()
{
    this->load_program(realLinesCompilerArgs);
}
ocaProgramFFT2cRealLines::~ocaProgramFFT2cRealLines()
{
}


// Imaginary lines program ********************************************
const static char *imaginaryLinesCompilerArgs[]
    = { "-DCALCULATE_IMAGINARY", NULL };

class ocaProgramFFT2cImaginaryLines : public ocaProgramFFT2cHelpers
{
  public:
    ocaProgramMacro(FFT2cImaginaryLines);
};
ocaProgramFFT2cImaginaryLines::ocaProgramFFT2cImaginaryLines()
{
    this->load_program(imaginaryLinesCompilerArgs);
}
ocaProgramFFT2cImaginaryLines::~ocaProgramFFT2cImaginaryLines()
{
}


//-----------------------------------------------------------------------------
// Object that does the basic 2D FFT algorithm.
// There is no tangling/untangling done, and the "first" FFT computation
// is assumed to be done (or the IFFT will be done).
void ocaProgramFFT2cCore::execute(ocaLookUpBuffer::pointer source,
				  ocaDrawableBuffer::pointer &target,
				  ocaDrawableBuffer::pointer &feedback,
				  bool forward)
{
    const int *arraySize = source->getSize();
    int size = arraySize[1];

  // Indices for columns starting with real numbers.
    static float realIndex1[2*4];
    static float imagIndex1[2*4];

    realIndex1[0] = 0;			realIndex1[1] = 0;
    realIndex1[2] = 0;			realIndex1[3] = (float)arraySize[1];
    realIndex1[4] = 1;			realIndex1[5] = (float)arraySize[1];
    realIndex1[6] = 1;			realIndex1[7] = 0;

    imagIndex1[0] = arraySize[0]/2.f;	imagIndex1[1] = 0;
    imagIndex1[2] = arraySize[0]/2.f;	imagIndex1[3] = (float)arraySize[1];
    imagIndex1[4] = arraySize[0]/2.f+1;	imagIndex1[5] = (float)arraySize[1];
    imagIndex1[6] = arraySize[0]/2.f+1;	imagIndex1[7] = 0;

  // Indices for columns starting with parts of complex numbers.
    static float realIndex2[2*4];
    static float imagIndex2[2*4];

    realIndex2[0] = 1;			realIndex2[1] = 0;
    realIndex2[2] = 1;			realIndex2[3] = (float)arraySize[1];
    realIndex2[4] = arraySize[0]/2.f;	realIndex2[5] = (float)arraySize[1];
    realIndex2[6] = arraySize[0]/2.f;	realIndex2[7] = 0;

    imagIndex2[0] = (float)arraySize[0];imagIndex2[1] = 0;
    imagIndex2[2] = (float)arraySize[0];imagIndex2[3] = (float)arraySize[1];
    imagIndex2[4] = arraySize[0]/2.f+1;	imagIndex2[5] = (float)arraySize[1];
    imagIndex2[6] = arraySize[0]/2.f+1;	imagIndex2[7] = 0;

    ocaProgramFFT1cVerticalReal::pointer compressLinesReal
	= ocaProgramFFT1cVerticalReal::getSingleton();
    ocaProgramFFT1cVerticalImag::pointer compressLinesImag
	= ocaProgramFFT1cVerticalImag::getSingleton();
    ocaProgramFFT2cRealLines::pointer realLinesProgram
	= ocaProgramFFT2cRealLines::getSingleton();
    ocaProgramFFT2cImaginaryLines::pointer imaginaryLinesProgram
	= ocaProgramFFT2cImaginaryLines::getSingleton();

    bool first = true;
    for (int partitionSize = 2; partitionSize <= size; partitionSize *= 2)
    {
	int numPartitions = size/partitionSize;

      // Set up lookup buffer.
	ocaLookUpBuffer::pointer lookUp;
	if (first) {
	    lookUp = source;
	    first = false;
	} else {
	    lookUp = feedback->getSharedLookUpBuffer();
	}

	target->makeCurrent();

      // ******** Do lines of real values that need to be compressed.
	compressLinesReal->execute(lookUp, partitionSize, numPartitions,
				   realIndex1, imagIndex1, forward);
	compressLinesImag->execute(lookUp, partitionSize, numPartitions,
				   realIndex1, imagIndex1, forward);

      // ******** Do lines of complex values that are already compressed.
	realLinesProgram->execute(lookUp, partitionSize, numPartitions,
				  realIndex2, imagIndex2, forward);
	imaginaryLinesProgram->execute(lookUp, partitionSize, numPartitions,
				       realIndex2, imagIndex2, forward);

      // Unbind shared lookup buffer.
	feedback->releaseLookUpBuffer();

      // Switch drawable buffers.
	ocaDrawableBuffer::pointer swap;
	swap = target;
	target = feedback;
	feedback = swap;
    }
}

ocaProgramFFT2cCore::ocaProgramFFT2cCore() {}
ocaProgramFFT2cCore::~ocaProgramFFT2cCore() {}


// Visible program object code ********************************************

ocaProgramFFT2c::ocaProgramFFT2c() {
}
ocaProgramFFT2c::~ocaProgramFFT2c() {
}

void ocaProgramFFT2c::execute(ocaLookUpBuffer::pointer samples,
			      ocaDrawableBuffer::pointer frequencies)
{
    const int *size = frequencies->getSize();
    int vectorSize = frequencies->getVectorSize();

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer temporary
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);

    this->execute(samples, frequencies, temporary);
}

void ocaProgramFFT2c::execute(ocaLookUpBuffer::pointer samples,
			      ocaDrawableBuffer::pointer frequencies,
			      ocaDrawableBuffer::pointer temporary)
{
    const int *arraySize = samples->getSize();

    if ((arraySize[0] < 2) || (arraySize[1] < 2)) {
	ocaRaiseError("2D FFT must be of image size 2x2 or greater.");
    }

    int size = arraySize[1];
    int numArrays = arraySize[0];
    int logsize = 0;
    int i = size;
    while (1) {
	if (i < 2) break;
	if ((i%2) == 1) ocaRaiseError("FFT input must be a power of 2");
	i >>= 1;
	logsize++;
    }

    ocaDrawableBuffer::pointer feedback;
    ocaDrawableBuffer::pointer target;

    if ((logsize%2) == 0) {
	feedback = temporary;
	target = frequencies;
    } else {
	target = temporary;
	feedback = frequencies;
    }

  // Do first FFT.
    ocaProgramFFT1c::getSingleton()->execute(samples, feedback, target);

  // Do core part of second FFT.
    ocaProgramFFT2cCore::getSingleton()
	->execute(feedback->getSharedLookUpBuffer(), target, feedback, true);

  // Do final copying and untangling.
    ocaLookUpBuffer::pointer lookup = feedback->getSharedLookUpBuffer();

    target->makeCurrent();

    ocaProgramFFT1cUntangleRealF::pointer untangleRealF
	= ocaProgramFFT1cUntangleRealF::getSingleton();
    ocaProgramFFT1cUntangleRealG::pointer untangleRealG
	= ocaProgramFFT1cUntangleRealG::getSingleton();
    ocaProgramFFT1cUntangleImagF::pointer untangleImagF
	= ocaProgramFFT1cUntangleImagF::getSingleton();
    ocaProgramFFT1cUntangleImagG::pointer untangleImagG
	= ocaProgramFFT1cUntangleImagG::getSingleton();

    float realFRegion[] = {
	0,			1,
	0,			(float)arraySize[1]/2,
	1,			(float)arraySize[1]/2,
	1,			1
    };
    float imagFRegion[] = {
	0,			(float)arraySize[1],
	0,			(float)arraySize[1]/2+1,
	1,			(float)arraySize[1]/2+1,
	1,			(float)arraySize[1]
    };
    float realGRegion[] = {
	(float)arraySize[0]/2,	1,
	(float)arraySize[0]/2,	(float)arraySize[1]/2,
	(float)arraySize[0]/2+1,(float)arraySize[1]/2,
	(float)arraySize[0]/2+1,1
    };
    float imagGRegion[] = {
	(float)arraySize[0]/2,	(float)arraySize[1],
	(float)arraySize[0]/2,	(float)arraySize[1]/2+1,
	(float)arraySize[0]/2+1,(float)arraySize[1]/2+1,
	(float)arraySize[0]/2+1,(float)arraySize[1]
    };

    float scale = 1.0f/arraySize[1];

    ocaProgramScale::getSingleton()->execute(lookup, scale, target);

    untangleRealF->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);
    untangleRealG->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);
    untangleImagF->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);
    untangleImagG->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);

    feedback->releaseLookUpBuffer();
}

void ocaProgramFFT2c::uncompress(int sizex, int sizey, int vectorsize,
				 const float *freqcompress,
				 float *freqreal, float *freqimag)
{
#define FREQCOMPRESS(x, y, j)	freqcompress[vectorsize*((y)*sizex + (x)) + (j)]
    int x, y, j;

    if (freqreal) {
	float *dest = freqreal;
	for (y = 0; y < sizey; y++) {
	    for (x = 0; x < sizex; x++) {
		for (j = 0; j < vectorsize; j++) {
		    if ((x == 0) || (x == sizex/2)) {
			if (y <= sizey/2) {
			    dest[j] = FREQCOMPRESS(x, y, j);
			} else {
			    dest[j] = FREQCOMPRESS(x, sizey-y, j);
			}
		    } else if (x > sizex/2) {
			dest[j] = FREQCOMPRESS(sizex-x, y, j);
		    } else if ((y == 0) || (y == sizey/2)) {
			dest[j] = FREQCOMPRESS(x, y, j);
		    } else {
			dest[j] = FREQCOMPRESS(x, sizey-y, j);
		    }
		}
		dest += vectorsize;
	    }
	}
    }

    if (freqimag) {
	float *dest = freqimag;
	for (y = 0; y < sizey; y++) {
	    for (x = 0; x < sizex; x++) {
		for (j = 0; j < vectorsize; j++) {
		    if ((x == 0) || (x == sizex/2)) {
			if ((y == 0) || (y == sizey/2)) {
			    dest[j] = 0;
			} else if (y < sizey/2) {
			    dest[j] = -FREQCOMPRESS(x, sizey-y, j);
			} else {
			    dest[j] = FREQCOMPRESS(x, y, j);
			}
		    } else if (x > sizex/2) {
			dest[j] = FREQCOMPRESS(x, y, j);
		    } else if ((y == 0) || (y == sizey/2)) {
			dest[j] = -FREQCOMPRESS(sizex-x, y, j);
		    } else {
			dest[j] = -FREQCOMPRESS(sizex-x, sizey-y, j);
		    }
		}
		dest += vectorsize;
	    }
	}
    }
#undef FREQCOMPRESS
}

void ocaProgramFFT2c::compress(int sizex, int sizey, int vectorsize,
			       float *freqcompress,
			       const float *freqreal, const float *freqimag)
{
#define FREQREAL(x, y, j)	freqreal[vectorsize*((y)*sizex + (x)) + j]
#define FREQIMAG(x, y, j)	freqimag[vectorsize*((y)*sizex + (x)) + j]
    int x, y, j;
    float *dest = freqcompress;

    for (y = 0; y < sizey; y++) {
	for (x = 0; x < sizex; x++) {
	    for (j = 0; j < vectorsize; j++) {
		if ((x == 0) || (x == sizex/2)) {
		    if (y <= sizey/2) {
			dest[j] = FREQREAL(x, y, j);
		    } else if (freqimag) {
			dest[j] = FREQIMAG(x, y, j);
		    } else {
			dest[j] = 0;
		    }
		} else if (x < sizex/2) {
		    if ((y == 0) || (y == sizey/2)) {
			dest[j] = FREQREAL(x, y, j);
		    } else {
			dest[j] = FREQREAL(x, sizey-y, j);
		    }
		} else if (freqimag) {
		    dest[j] = FREQIMAG(x, y, j);
		} else {
		    dest[j] = 0;
		}
	    }
	    dest += 4;
	}
    }
}
