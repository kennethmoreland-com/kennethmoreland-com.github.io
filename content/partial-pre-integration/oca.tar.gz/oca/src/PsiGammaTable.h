/* -*- c -*- */

#ifdef __cplusplus
extern "C" {
#endif

#define PSI_GAMMA_TABLE_BACK_RES	1024
#define PSI_GAMMA_TABLE_FRONT_RES	1024

#define PSI_GAMMA_LOOKUP(gammaback, gammafront) \
    PsiGammaTable[(int)((gammafront)*PSI_GAMMA_TABLE_FRONT_RES+0.5f)][(int)((gammaback)*PSI_GAMMA_TABLE_BACK_RES+0.5f)]

#define PSI_LOOKUP(tauDback, tauDfront) \
    PSI_GAMMA_LOOKUP((tauDback)/((tauDback)+1), (tauDfront)/((tauDfront)+1))

extern float psi_gamma_table[PSI_GAMMA_TABLE_FRONT_RES][PSI_GAMMA_TABLE_BACK_RES];

#ifdef __cplusplus
}
#endif
