// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgram.cxx,v 1.12 2003-09-02 23:16:20 kmorel Exp $

#include "ocaProgram.h"

#include "ocaOpenGLExtensions.h"
#include "ocaCgError.h"

#ifdef WIN32
#include <io.h>
#define access _access
#define F_OK	00
#else
#include <unistd.h>
#endif

using std::string;

string ocaProgram::sourceDirectory;

ocaProgram::ocaProgram()
{
    this->valid = false;

    this->vertProfile = cgGLGetLatestProfile(CG_GL_VERTEX);
    this->fragProfile = cgGLGetLatestProfile(CG_GL_FRAGMENT);
}

ocaProgram::~ocaProgram()
{
    if (this->valid) {
	if (this->vertProgram != NULL) {
	    cgDestroyProgram(this->vertProgram);
	}
	if (this->fragProgram != NULL) {
	    cgDestroyProgram(this->fragProgram);
	}
	cgDestroyContext(this->programContext);
    }
}

const static char *vertcompilerargs[] = {
    "-DVERTPROG"
};
const static char *fragcompilerargs[] = {
    "-DFRAGPROG"
};
const static int ncompilerargs = 1;

const static char *nullargs[] = { NULL };

void ocaProgram::loadProgram(const char *filename,
			     const char *vertProgEntry,
			     const char *fragProgEntry,
			     const char **compilerArgs)
{
    if (compilerArgs == NULL) {
	compilerArgs = nullargs;
    }

  // Some day this should be sophisticated enough to search from the
  // executable location rather than the current directory.
    string fullFilename = ocaProgram::sourceDirectory + filename;

    int i;

    try {
	this->programContext = cgCreateContext();

	int nuserargs = 0;
	while (compilerArgs[nuserargs] != NULL) nuserargs++;

	const char **totalargs = new const char*[nuserargs+ncompilerargs+1];
	for (i = 0; i < nuserargs; i++) {
	    totalargs[i] = compilerArgs[i];
	}
	totalargs[nuserargs+ncompilerargs] = NULL;

	if (vertProgEntry != NULL) {
	    for (i = 0; i < ncompilerargs; i++) {
		totalargs[i+nuserargs] = vertcompilerargs[i];
	    }
	    this->vertProgram = cgCreateProgramFromFile(this->programContext,
							CG_SOURCE,
							fullFilename.c_str(),
							this->vertProfile,
							vertProgEntry,
							totalargs);
	    cgGLLoadProgram(this->vertProgram);
	} else {
	    this->vertProgram = NULL;
	}

	if (fragProgEntry != NULL) {
	    for (i = 0; i < ncompilerargs; i++) {
		totalargs[i+nuserargs] = fragcompilerargs[i];
	    }
	    this->fragProgram = cgCreateProgramFromFile(this->programContext,
							CG_SOURCE,
							fullFilename.c_str(),
							this->fragProfile,
							fragProgEntry,
							totalargs);
	    cgGLLoadProgram(this->fragProgram);
	} else {
	    this->fragProgram = NULL;
	}

	this->valid = true;
    } catch (ocaCgError &cgError) {
	throw ocaCgError(cgError.getError(), this->programContext);
    }
}

void ocaProgram::bind()
{
    if (!this->valid) {
	ocaRaiseError("Tried to bind invalid program.");
    }
    if (this->vertProgram != NULL) {
	cgGLEnableProfile(this->vertProfile);
	cgGLBindProgram(this->vertProgram);
    }
    if (this->fragProgram != NULL) {
	cgGLEnableProfile(this->fragProfile);
	cgGLBindProgram(this->fragProgram);
    }
}

void ocaProgram::unbind()
{
    if (!this->valid) {
	return;
    }
    if (this->vertProgram != NULL) {
	cgGLDisableProfile(this->vertProfile);
    }
    if (this->fragProgram != NULL) {
	cgGLDisableProfile(this->fragProfile);
    }
}

void ocaProgram::findSourceDirectory()
{
    if (access(OCA_BUILD_CG_DIR, F_OK) == 0) {
	ocaProgram::sourceDirectory = OCA_BUILD_CG_DIR;
	ocaProgram::sourceDirectory.append("/");
	return;
    }

    ocaRaiseError("Could not find source directory for Cg files.");
}
