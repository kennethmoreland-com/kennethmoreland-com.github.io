// -*- c++ -*- *******************************************************

#include "ocaViewableBuffer.h"
#include "ocaLookUpBuffer.h"

#include "ocaError.h"
#include "ocaOpenGLExtensions.h"
#include "ocaFactory.h"

static inline GLenum getFormat(int vecsize)
{
    switch (vecsize) {
      case 1: return GL_RED;
      case 2: ocaRaiseError("2 vectors not supported yet.");
      case 3: return GL_RGB;
      case 4: return GL_RGBA;
    }
    ocaRaiseError("Bad vector size: " + oca_itos(vecsize));
}

ocaViewableBuffer::ocaViewableBuffer() {}

ocaViewableBuffer::~ocaViewableBuffer()
{
}

const int *ocaViewableBuffer::getSize() const
{
    return this->size;
}

int ocaViewableBuffer::getVectorSize() const
{
    return this->vectorSize;
}

void ocaViewableBuffer::getData(float *buffer) const
{
    ocaOpenGLContext::ScopedContext saveContext;
    this->makeCurrent();
    glReadPixels(0, 0, this->size[0], this->size[1],
		 getFormat(this->vectorSize), GL_FLOAT, buffer);
}

// This would be faster if it was more direct.
void ocaViewableBuffer::setData(float *buffer)
{
    ocaLookUpBuffer::pointer tmpbuffer
	= ocaFactory::getSingleton()->makeLookUpBuffer();
    tmpbuffer->setData(buffer, this->size[0], this->size[1], this->vectorSize);
    this->copy(tmpbuffer);
}

void ocaViewableBuffer::copy(const ocaBuffer::pointer &src)
{
    const int *srcsize = src->getSize();
    if (   (srcsize[0] != this->size[0]) || (srcsize[1] != this->size[1])
	|| (src->getVectorSize() != this->vectorSize) ) {
	ocaRaiseError("Source and destination buffers are not compatable for copy");
    }

    const ocaLookUpBuffer::pointer lubsrc(src);
    if (!lubsrc.isNull()) {
	ocaOpenGLContext::ScopedContext saveContext;
	this->makeCurrent();

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	lubsrc->bind();
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glEnable(GL_TEXTURE_RECTANGLE_NV);

	glBegin(GL_QUADS);
	  glTexCoord2f(0.0, 0.0);
	  glVertex2f(-1.0, -1.0);
	  glTexCoord2f((float)this->size[0], 0.0);
	  glVertex2f(1.0, -1.0);
	  glTexCoord2f((float)this->size[0], (float)this->size[1]);
	  glVertex2f(1.0, 1.0);
	  glTexCoord2f(0.0, (float)this->size[1]);
	  glVertex2f(-1.0, 1.0);
	glEnd();

	glDisable(GL_TEXTURE_RECTANGLE_NV);

	return;
    }

    const ocaDrawableBuffer::pointer drawsrc(src);
    if (!drawsrc.isNull()) {
	bool bound = drawsrc->isBoundToLookUp();
	ocaLookUpBuffer::pointer sharedlubsrc
	    = drawsrc->getSharedLookUpBuffer();
	this->copy(sharedlubsrc);
	if (!bound) {
	    drawsrc->releaseLookUpBuffer();
	}
	return;
    }

    const ocaOpenGLContext::pointer openglsrc(src);
    if (!openglsrc.isNull()) {
	ocaLookUpBuffer::pointer lubsrc
	    = ocaFactory::getSingleton()->makeLookUpBuffer();
	lubsrc->copy(src);
	this->copy(lubsrc);
    }

    this->super::copy(src);
}

void ocaViewableBuffer::clear()
{
    this->clear(0.0, 0.0, 0.0, 0.0);
}

void ocaViewableBuffer::clear(float r, float g, float b, float a)
{
    ocaOpenGLContext::ScopedContext saveContext;
    this->makeCurrent();
    glClearColor(r, g, b, a);
    glClear(GL_COLOR_BUFFER_BIT);
}

void ocaViewableBuffer::swapBuffers()
{
    SwapBuffers(this->hDC);
}

ocaViewableBuffer::pointer ocaViewableBuffer::create(int width, int height,
						     int vectorSize,
						     HWND hWnd, HDC parentHDC,
						     HGLRC parentHRC)
{
    ocaViewableBuffer::pointer newvb(new ocaViewableBuffer);

}

