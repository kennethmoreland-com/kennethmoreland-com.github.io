// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaDrawableBuffer.h,v 1.9 2003-06-30 17:56:01 kmorel Exp $

#ifndef _ocaDrawableBuffer_h
#define _ocaDrawableBuffer_h

#include "ocaOpenGLContext.h"

#include "ocaOpenGLExtensions.h"

#include "ocaLookUpBuffer.h"

class OCA_EXPORT ocaDrawableBuffer : public ocaOpenGLContext
{
  public:
    ocaTypeMacro(ocaDrawableBuffer, ocaOpenGLContext);
    virtual const int *getSize() const;
    virtual int getVectorSize() const;
    virtual void getData(float *buffer) const;
    virtual void setData(float *buffer);

    virtual void copy(const ocaBuffer::pointer &src);

    virtual bool isValid() const;
    virtual bool isBoundToLookUp() const;

  // Clears this buffer.
    virtual void clear();

  // Clears the current buffer.  A bit more efficient than clear() if you
  // have already made the drawable current (since you plan to use it
  // anyway).
    static void clearCurrent();

  // Returns a special lookup buffer that, when bound, gets the contents of
  // this buffer without copying.  When this lookup buffer is returned,
  // this buffer becomes invalid.  When this releaseLookUpBuffer is called
  // on this object, the lookup buffer becomes invalid until
  // getSharedLookUpBuffer is called.  The setData and copy methods should
  // work, but they may allocate extra memory to perform the operation.
    virtual ocaLookUpBuffer::pointer getSharedLookUpBuffer();

  // Any textures must be released for this buffer to be drawn or copied
  // to.  However, all bound LookUpBuffers become invalid.  Also, the data
  // left inthe drawable buffers is not guaranteed to be that in the lookup
  // buffer.
    virtual void releaseLookUpBuffer();

  // Binds the texture to the currently bound LookUp buffer.  This will
  // destroy whatever data is already associated with the current lookup
  // buffer.  Generally, it is better to use the buffer retrieved from
  // getSharedLookUpBuffer.
    virtual void bindToLookUpBuffer();

#ifdef WIN32
    static ocaDrawableBuffer::pointer
	create(int width, int height, int vectorSize,
	       HWND hWnd, HDC parentHDC, HGLRC parentHRC);
#else
    static ocaSmartPointer<ocaDrawableBuffer>
	create(int width, int height, int vectorSize,
	       Display *displayId, GLXContext parentContext);
#endif

  protected:
    ocaDrawableBuffer();
    virtual ~ocaDrawableBuffer();

    int size[2];
    int vectorSize;
    bool lubBound;

#ifdef WIN32
    HPBUFFERARB hPbuffer;
#else
    Pixmap pixmapId;
#endif

    class SharedLookUp : public ocaLookUpBuffer {
      public:
	ocaTypeMacro(SharedLookUp, ocaLookUpBuffer);
	void invalidateDrawable();
	SharedLookUp(ocaDrawableBuffer *source);
      protected:
	ocaDrawableBuffer *drawable;
    };

    SharedLookUp::pointer sharedLookUp;
};

#endif //_ocaDrawableBuffer_h
