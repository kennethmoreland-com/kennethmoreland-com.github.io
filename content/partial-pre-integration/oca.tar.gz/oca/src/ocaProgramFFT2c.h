// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT2c.h,v 1.4 2003-06-30 17:56:02 kmorel Exp $

#ifndef _ocaProgramFFT2c_h
#define _ocaProgramFFT2c_h

#include "ocaProgram.h"

class ocaLookUpBuffer;
class ocaDrawableBuffer;

class OCA_EXPORT ocaProgramFFT2c : public ocaProgram
{
  public:
    ocaProgramMacro(FFT2c);

    void execute(ocaSmartPointer<ocaLookUpBuffer> samples,
		 ocaSmartPointer<ocaDrawableBuffer> frequencies);
    void execute(ocaSmartPointer<ocaLookUpBuffer> samples,
		 ocaSmartPointer<ocaDrawableBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> temporary);

    static void uncompress(int sizex, int sizey, int vectorsize,
			   const float *freqcompress,
			   float *freqreal, float *freqimag = NULL);
    static void compress(int sizex, int sizey, int vectorsize,
			 float *freqcompress,
			 const float *freqreal, const float *freqimag = NULL);
  protected:
};

class ocaProgramFFT2cCore : public ocaProgram
{
  public:
    ocaProgramMacro(FFT2cCore);

    void execute(ocaSmartPointer<ocaLookUpBuffer> source,
		 ocaSmartPointer<ocaDrawableBuffer> &target,
		 ocaSmartPointer<ocaDrawableBuffer> &feedback,
		 bool forward);
};

#endif //_ocaProgramFFT2c_h
