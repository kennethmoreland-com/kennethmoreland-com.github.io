// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaBuffer.cxx,v 1.6 2003-06-30 17:56:01 kmorel Exp $

#include "ocaBuffer.h"

#include "ocaError.h"

void ocaBuffer::getSize(int size[2]) const
{
    const int *s = this->getSize();
    size[0] = s[0];
    size[1] = s[1];
}

void ocaBuffer::getSize(int &width, int &height) const
{
    const int *s = this->getSize();
    width = s[0];
    height = s[1];
}

void ocaBuffer::setData(float *buffer, int sizex, int sizey, int sizev)
{
    const int *s = this->getSize();
    if ((s[0] != sizex) || (s[1] != sizey)) {
	ocaRaiseError("Incoming data does not match buffer dimensions.");
    }
    if (this->getVectorSize() != sizev) {
	ocaRaiseError("Incoming data does not match buffer vector size.");
    }
    this->setData(buffer);
}

void ocaBuffer::copy(const ocaBuffer::pointer &src)
{
    float *buffer;
    const int *size;
    const int *size2;
    int sizev;

    size = this->getSize();
    size2 = src->getSize();
    sizev = this->getVectorSize();
    if (   (size[0] != size2[0]) || (size[1] != size2[1])
	|| (sizev != src->getVectorSize()) ) {
	ocaRaiseError("Could not copy vectors.  Not of same size.");
    }
    buffer = new float[size[0]*size[1]*sizev];

    try {
	src->getData(buffer);
	this->setData(buffer);
    } catch (...) {
	delete[] buffer;
	throw;
    }

    delete[] buffer;
}
