// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT2cMult.cxx,v 1.2 2003-06-30 17:56:02 kmorel Exp $

#include "ocaProgramFFT2cMult.h"

#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"
#include "ocaZeroBuffer.h"
#include "ocaFactory.h"

#include <iostream>

#define GET_PROGRAM_PARAMETER(program, paramname, parameter)		\
    parameter = cgGetNamedParameter(program, paramname);		\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }

ocaProgramFFT2cMult::ocaProgramFFT2cMult()
{
    this->loadProgram("fft2c_mult.cg",
		      "FFT2cMultVert", "FFT2cMultFrag");

    GET_PROGRAM_PARAMETER(this->vertProgram, "input.position", this->Position);

    GET_PROGRAM_PARAMETER(this->fragProgram, "ArraySize", this->ArraySize);
    GET_PROGRAM_PARAMETER(this->fragProgram, "HalfArraySize",
			  this->HalfArraySize);
    GET_PROGRAM_PARAMETER(this->fragProgram, "frequencies1",
			  this->Frequencies1);
    GET_PROGRAM_PARAMETER(this->fragProgram, "frequencies2",
			  this->Frequencies2);
}

ocaProgramFFT2cMult::~ocaProgramFFT2cMult()
{
}

static GLfloat fullScreenSquare[] = {
    -1.0, -1.0,
    1.0, -1.0,
    1.0, 1.0,
    -1.0, 1.0
};

void ocaProgramFFT2cMult::execute(ocaLookUpBuffer::pointer frequencies1,
				  ocaLookUpBuffer::pointer frequencies2,
				  ocaDrawableBuffer::pointer destination)
{
  // Get sizes and make sure that they are consistent.
    const int *size;
    const int *size2;

    size = destination->getSize();

    size2 = frequencies1->getSize();
    if ((size2[0] != size[0]) || (size2[1] != size[1])) {
	ocaRaiseError("Input size not consistent with output size.");
    }
    size2 = frequencies1->getSize();
    if ((size2[0] != size[0]) || (size2[1] != size[1])) {
	ocaRaiseError("Input size not consistent with output size.");
    }

  // Set up inputs to vertex and fragment programs.
    destination->makeCurrent();
    this->bind();
    cgGLSetParameter2f(this->ArraySize, (float)size[0], (float)size[1]);
    cgGLSetParameter2f(this->HalfArraySize, 0.5f*size[0], 0.5f*size[1]);
    cgGLSetTextureParameter(this->Frequencies1, frequencies1->getTextureId());
    cgGLEnableTextureParameter(this->Frequencies1);
    cgGLSetTextureParameter(this->Frequencies2, frequencies2->getTextureId());
    cgGLEnableTextureParameter(this->Frequencies2);

    cgGLSetParameterPointer(this->Position, 2, GL_FLOAT, 0, fullScreenSquare);
    cgGLEnableClientState(this->Position);

  // Run vertex and fragment programs.
    glDrawArrays(GL_QUADS, 0, 4);

    cgGLDisableTextureParameter(this->Frequencies1);
    cgGLDisableTextureParameter(this->Frequencies2);
    cgGLDisableClientState(this->Position);
    this->unbind();
}
