// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramVolumeRenderingIntegrate.h,v 1.2 2003-09-04 19:40:34 kmorel Exp $

#ifndef _ocaProgramVolumeRenderingIntegrate_h
#define _ocaProgramVolumeRenderingIntegrate_h

#include "ocaProgram.h"

class OCA_EXPORT ocaProgramVolumeRenderingIntegrate : public ocaProgram
{
  public:
    ocaTypeMacro(ocaProgramVolumeRenderingIntegrate, ocaProgram);

    inline CGparameter getPosition() { return this->Position; }
    inline CGparameter getBackColor() { return this->BackColor; }
    inline CGparameter getFrontColor() { return this->FrontColor; }
    inline CGparameter getLength() { return this->Length; }
    inline CGparameter getIncoming() { return this->Incoming; }

  protected:
    CGparameter Position;
    CGparameter BackColor;
    CGparameter FrontColor;
    CGparameter Length;
    CGparameter Incoming;

    virtual void loadProgram(const char *filename,
			     const char *vertProgEntry,
			     const char *fragProgEntry,
			     const char **compilerArgs = NULL);
};

#endif //_ocaProgramVolumeRenderingIntegrate_h
