// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramIFFT2c.h,v 1.2 2003-06-30 17:56:02 kmorel Exp $

#ifndef _ocaProgramIFFT2c_h
#define _ocaProgramIFFT2c_h

#include "ocaProgram.h"

class ocaLookUpBuffer;
class ocaDrawableBuffer;

class OCA_EXPORT ocaProgramIFFT2c : public ocaProgram
{
  public:
    ocaProgramMacro(IFFT2c);

  // Takes the compressed 2D FFT (frequencies) and places the original
  // data in samples.
    void execute(ocaSmartPointer<ocaLookUpBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> samples);
    void execute(ocaSmartPointer<ocaLookUpBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> samples,
		 ocaSmartPointer<ocaDrawableBuffer> temporary);

  // Takes the compressed 2D FFT (frequencies) that is in a drawable
  // buffer and computes the original data.  The original data is placed
  // in one of the two input buffers (if two are given).  The correct
  // buffer is returned.
    ocaSmartPointer<ocaDrawableBuffer>
	execute(ocaSmartPointer<ocaDrawableBuffer> frequencies);
    ocaSmartPointer<ocaDrawableBuffer>
	execute(ocaSmartPointer<ocaDrawableBuffer> frequencies,
		ocaSmartPointer<ocaDrawableBuffer> auxiliary);

  // Takes the compressed 2D FFT (frequencies) that is in a drawable
  // buffer and computes the original data.  The original data is placed
  // in one of the two input buffers (if two are given).  The correct
  // buffer is returned in samples, and the other is placed in other.
    void execute(ocaSmartPointer<ocaDrawableBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> auxiliary,
		 ocaSmartPointer<ocaDrawableBuffer> &samples,
		 ocaSmartPointer<ocaDrawableBuffer> &other);

  protected:
  // Performs the IFFT on source.  Source may be a shared lookup buffer for
  // feedback.  feedback is set to the buffer with the result, target is
  // set to the opposite.
    void do_IFFT(ocaSmartPointer<ocaLookUpBuffer> source,
		 ocaSmartPointer<ocaDrawableBuffer> &target,
		 ocaSmartPointer<ocaDrawableBuffer> &feedback);
};

#endif //_ocaProgramIFFT2c_h
