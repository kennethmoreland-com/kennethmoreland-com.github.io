// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// "Solves" the volume rendering equation by averaging the color and
// attenuation and then performing the homogeneous solution.
//
// $Id: ocaProgramVolumeRenderingIntegrateRiemann.h,v 1.1 2003-09-04 19:40:34 kmorel Exp $

#ifndef _ocaProgramVolumeRenderingIntegrateRiemann_h
#define _ocaProgramVolumeRenderingIntegrateRiemann_h

#include "ocaProgramVolumeRenderingIntegrate.h"

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateRiemann2
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateRiemann2);
};

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateRiemann4
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateRiemann4);
};

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateRiemann8
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateRiemann8);
};

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateRiemann16
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateRiemann16);
};

class OCA_EXPORT ocaProgramVolumeRenderingIntegrateRiemann32
    : public ocaProgramVolumeRenderingIntegrate
{
  public:
    ocaProgramMacro(VolumeRenderingIntegrateRiemann32);
};

#endif //_ocaProgramVolumeRenderingIntegrateRiemann_h
