// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaTimer.h,v 1.2 2003-06-30 17:56:02 kmorel Exp $

#ifndef _ocaTimer_h
#define _ocaTimer_h

#include "ocaObject.h"

class OCA_EXPORT ocaTimer : public ocaObject
{
  public:
    ocaTypeMacro(ocaTimer, ocaObject);
    static ocaSmartPointer<ocaTimer> New();

  // Marks the current time as the start time.
    virtual void start();
  // Marks the current time as the end time.
    virtual void stop();
  // Returns the amount of time, in seconds, between calls to the start
  // and end time.
    virtual double getElapsedTime();

  protected:
    ocaTimer();
    virtual ~ocaTimer();

    unsigned long startTick;
    unsigned long stopTick;
    const static double ticksPerSec;
};

#endif //_ocaTimer_h
