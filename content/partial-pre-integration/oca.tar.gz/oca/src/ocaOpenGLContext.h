// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaOpenGLContext.h,v 1.7 2003-06-30 17:56:01 kmorel Exp $

#ifndef _ocaOpenGLContext_h
#define _ocaOpenGLContext_h

#include "ocaBuffer.h"

#include <stack>

class ocaLookUpBuffer;

class OCA_EXPORT ocaOpenGLContext : public ocaBuffer
{
  public:
    ocaTypeMacro(ocaOpenGLContext, ocaObject);

    virtual void makeCurrent() const;
    static inline ocaOpenGLContext::pointer getCurrent() {
	return ocaOpenGLContext::current;
    }

    virtual bool isValid() const;

    static void pushContext();
    static void popContext();

    void pushBinding();
    void popBinding();

    virtual ~ocaOpenGLContext();

  // A class that will push the context when instantiated and pop
  // the context when destroyed
    class ScopedContext {
      public:
	ScopedContext() { ocaOpenGLContext::pushContext(); }
	~ScopedContext() { ocaOpenGLContext::popContext(); }
    };

  // INTERNAL USE ONLY.  DO NOT CALL.
    static void finalize();

  protected:
    ocaOpenGLContext();

    bool valid;
#ifdef WIN32
    HGLRC hRC;
    HDC   hDC;
    HWND  hWnd;
#else
    GLXContext  ContextId;
    GLXDrawable DrawableId;
    Display    *DisplayId;
#endif

    static ocaOpenGLContext::pointer current;
    std::stack<ocaSmartPointer<ocaLookUpBuffer> > bindingStack;
};

#endif //_ocaOpenGLContext_h
