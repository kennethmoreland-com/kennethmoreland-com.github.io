
#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>
#include <gl/wglext.h>

#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>

struct _glext {
    PFNWGLGETPIXELFORMATATTRIBIVARBPROC GetPixelFormatAttribivARB;
    PFNWGLGETPIXELFORMATATTRIBFVARBPROC GetPixelFormatAttribfvARB;
    PFNWGLCHOOSEPIXELFORMATARBPROC ChoosePixelFormatARB;
    PFNWGLCREATEPBUFFERARBPROC CreatePbufferARB;
    PFNWGLGETPBUFFERDCARBPROC GetPbufferDCARB;
    PFNWGLRELEASEPBUFFERDCARBPROC ReleasePbufferDCARB;
    PFNWGLDESTROYPBUFFERARBPROC DestroyPbufferARB;
    PFNWGLQUERYPBUFFERARBPROC QueryPbufferARB;
} glext;

static void InitPixelFormat();
static LONG WINAPI WndProc( HWND, UINT, WPARAM, LPARAM );
static void DrawOpenGLScene( void );
static HGLRC SetUpOpenGL( HWND hWnd );
static void InitTexture(HWND hWnd, HGLRC shareHRC);

static GLuint texture = 0;

////////////////////////////////////////////////////////// 
//  WinMain - the main window entrypoint,
////////////////////////////////////////////////////////// 

int WINAPI WinMain (HINSTANCE hInstance,
		    HINSTANCE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow)
{
    static char szAppName[] = "OpenGL";
    static char szTitle[]="A Simple C OpenGL Program";
    WNDCLASS wc;   // windows class sruct
    MSG      msg;  // message struct 
    HWND     hWnd; // Main window handle.

    InitPixelFormat();

    // Fill in window class structure with parameters that
    //  describe the main window.

    wc.style         =
        CS_HREDRAW | CS_VREDRAW;// Class style(s).
    wc.lpfnWndProc   = 
        (WNDPROC)WndProc;      // Window Procedure
    wc.cbClsExtra    = 0;     // No per-class extra data.
    wc.cbWndExtra    = 0;     // No per-window extra data.
    wc.hInstance     =
        hInstance;            // Owner of this class
    wc.hIcon         = NULL;  // Icon name 
    wc.hCursor       =
        LoadCursor(NULL, IDC_ARROW);// Cursor
    wc.hbrBackground = 
        (HBRUSH)(COLOR_WINDOW+1);// Default color
    wc.lpszMenuName  = NULL;  // Menu from .RC
    wc.lpszClassName =
        szAppName;            // Name to register as

    // Register the window class
    RegisterClass( &wc );
  
    // Create a main window for this application instance.

    hWnd = CreateWindow(
                szAppName, // app name
                szTitle,   // Text for window title bar
                WS_OVERLAPPEDWINDOW// Window style 
                  // NEED THESE for OpenGL calls to work!
                 | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
                CW_USEDEFAULT, 0, CW_USEDEFAULT, 0,
                NULL,     // no parent window
                NULL,     // Use the window class menu.
                hInstance,// This instance owns this window
                NULL      // We don't use any extra data
        );

    // If window could not be created, return zero
    if ( !hWnd ) {
        return( 0 );
    }

    // Make the window visible & update its client area
    ShowWindow( hWnd, SW_SHOWNORMAL );// Show the window
    UpdateWindow( hWnd );        // Sends WM_PAINT message

    // Enter the Windows message loop
    // Get and dispatch messages until WM_QUIT 
    while (GetMessage(&msg, // message structure
               NULL,       // handle of window receiving
                           // the message
               0,          // lowest message id to examine
               0))         // highest message id to examine
        {
        TranslateMessage( &msg ); // Translates messages
        DispatchMessage( &msg );  // then dispatches
        }

    return( msg.wParam ); 
}

//////////////////////////////////////////////////////////////////
// This function initializes the pixel format extension.  The pixel
// format extension is supposed to help you make windows.  However,
// you cannot initialize any extension until a window is created.
// We get around this chicken-and-the-egg by temporarily creating
// an OpenGL context using older methods.
//////////////////////////////////////////////////////////////////
static void InitPixelFormat()
{
    static char ClassName[] = "InitPixelFormat";
    WNDCLASS wc;	// Window class struct
    HWND hWnd;		// Window handle
    HINSTANCE hInstance = GetModuleHandle(NULL);
    PIXELFORMATDESCRIPTOR pfd;
    HGLRC hRC;
    HDC hDC;
    int pixelFormatId;

    wc.style		= CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc	= DefWindowProc;
    wc.cbClsExtra	= 0;
    wc.cbWndExtra	= 0;
    wc.hInstance	= hInstance;
    wc.hIcon		= NULL;
    wc.hCursor		= NULL;
    wc.hbrBackground	= NULL;
    wc.lpszMenuName	= NULL;
    wc.lpszClassName	= ClassName;

    RegisterClass(&wc);

    hWnd = CreateWindow(ClassName,
			"",
			WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
			CW_USEDEFAULT, 0, CW_USEDEFAULT, 0,
			NULL,     // no parent window
			NULL,     // Use the window class menu.
			hInstance,// This instance owns this window
			NULL      // We don't use any extra data
			);
    if (!hWnd) {
	cout << "Could not create window." << endl;
	exit(1);
    }

    memset(&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW;
    pfd.iPixelType = PFD_TYPE_RGBA;

    hDC = GetDC(hWnd);
    pixelFormatId = ChoosePixelFormat(hDC, &pfd);

    SetPixelFormat(hDC, pixelFormatId, &pfd);

    hRC = wglCreateContext(hDC);
    wglMakeCurrent(hDC, hRC);

    glext.GetPixelFormatAttribivARB =
	wglGetProcAddress("wglGetPixelFormatAttribivARB");
    if (glext.GetPixelFormatAttribivARB == NULL) {
	cout << "Could not get wglGetPixelFormatAttribivARB" << endl;
	exit(1);
    }
    glext.GetPixelFormatAttribfvARB =
	wglGetProcAddress("wglGetPixelFormatAttribfvARB");
    if (glext.GetPixelFormatAttribfvARB == NULL) {
	cout << "Could not get wglGetPixelFormatAttribfvARB" << endl;
	exit(1);
    }
    glext.ChoosePixelFormatARB =
	wglGetProcAddress("wglChoosePixelFormatARB");
    if (glext.ChoosePixelFormatARB == NULL) {
	cout << "Could not get wglChoosePixelFormatARB" << endl;
	exit(1);
    }

    glext.CreatePbufferARB =
	(PFNWGLCREATEPBUFFERARBPROC)wglGetProcAddress("wglCreatePbufferARB");
    if (glext.CreatePbufferARB == NULL) {
	cout << "Could not get wglCreatePbufferARB" << endl;
	exit(1);
    }
    glext.GetPbufferDCARB =
	(PFNWGLGETPBUFFERDCARBPROC)wglGetProcAddress("wglGetPbufferDCARB");
    if (glext.GetPbufferDCARB == NULL) {
	cout << "Could not get wglGetPbufferDCARB" << endl;
	exit(1);
    }
    glext.ReleasePbufferDCARB =
	wglGetProcAddress("wglReleasePbufferDCARB");
    if (glext.ReleasePbufferDCARB == NULL) {
	cout << "Could not get wglReleasePbufferDCARB" << endl;
	exit(1);
    }
    glext.DestroyPbufferARB =
	wglGetProcAddress("wglDestroyPbufferARB");
    if (glext.DestroyPbufferARB == NULL) {
	cout << "Could not get wglDestroyPbufferARB" << endl;
	exit(1);
    }
    glext.QueryPbufferARB =
	wglGetProcAddress("wglQueryPbufferARB");
    if (glext.QueryPbufferARB == NULL) {
	cout << "Could not get wglQueryPbufferARB" << endl;
	exit(1);
    }

    ReleaseDC(hWnd, hDC);
    wglDeleteContext(hRC);

    DestroyWindow(hWnd);
    UnregisterClass(ClassName, hInstance);
}

////////////////////////////////////////////////////////// 
// WndProc processes messages to our program.
// It's called WndProc because Windows's expects it
// to be called that!
////////////////////////////////////////////////////////// 
 
static LONG WINAPI WndProc( HWND hWnd, UINT msg,
			    WPARAM wParam, LPARAM lParam )
{
    HDC hDC;
    static HGLRC hRC; // Note this is STATIC!
    PAINTSTRUCT ps;
    GLdouble gldAspect;
    GLsizei glnWidth, glnHeight;
            
    switch (msg)
      {
       case WM_CREATE:
           // Select a pixel format and then
           // create a rendering context from it.
           hRC = SetUpOpenGL( hWnd );
	   InitTexture(hWnd, hRC);
           return 0;
    
       case WM_SIZE:
            // Redefine the viewing volume and viewport
            // when the window size changes.

            // Make the RC current since we're going to
            // make an OpenGL call here...
            hDC = GetDC (hWnd);
            wglMakeCurrent (hDC, hRC);
        
            // get the new size of the client window
            // note that we size according to the height,
            // not the smaller of the height or width.
            glnWidth = (GLsizei) LOWORD (lParam);
            glnHeight = (GLsizei) HIWORD (lParam);
            gldAspect = 
                 (GLdouble)glnWidth/(GLdouble)glnHeight;

            // set up a projection matrix to fill the
            //  client window
            glMatrixMode( GL_PROJECTION );
            glLoadIdentity();
            // a perspective-view matrix...
            gluPerspective(
                30.0,   // Field-of-view angle
                gldAspect, // Aspect ratio of view volume
                1.0,    // Distance to near clipping plane
                10.0 ); // Distance to far clipping plane

            glViewport( 0, 0, glnWidth, glnHeight );
            wglMakeCurrent( NULL, NULL );
            ReleaseDC( hWnd, hDC );
            return 0;

        case WM_PAINT:
            // Draw the scene.

            // Get a DC, then make the RC current and
            // associated with this DC
            hDC = BeginPaint( hWnd, &ps );
            wglMakeCurrent( hDC, hRC );

            DrawOpenGLScene();

            // we're done with the RC, so
            // deselect it
            // (note: This technique is not recommended!)
            wglMakeCurrent( NULL, NULL );

            EndPaint( hWnd, &ps );
            return 0;       
            
        case WM_DESTROY:
            // Clean up and terminate.
            wglDeleteContext( hRC );
            PostQuitMessage( 0 );
            return 0;
        }

    // This function handles any messages that we didn't.
    // (Which is most messages) It belongs to the OS.
    return DefWindowProc( hWnd, msg, wParam, lParam );
}

/////////////////////////////////////////////////////////
//  SetUpOpenGL sets the pixel format and a rendering
//  context then returns the RC
/////////////////////////////////////////////////////////
static HGLRC SetUpOpenGL( HWND hWnd )
{
    static GLint attribIList[] = {
	WGL_DRAW_TO_WINDOW_ARB, GL_TRUE,
	WGL_ACCELERATION_ARB, WGL_FULL_ACCELERATION_ARB,
	WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
	WGL_DOUBLE_BUFFER_ARB, GL_FALSE,
	WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB,
	WGL_COLOR_BITS_ARB, 24,
	WGL_DEPTH_BITS_ARB, 24,
	0
    };
    int pixelFormatId;
    UINT numPixelFormats;
    int success;
    HDC hDC;
    HGLRC hRC;

    hDC = GetDC( hWnd );

  // wglChoosePixelFormatARB replaces the windows ChoosePixelFormat.
    success = glext.ChoosePixelFormatARB(hDC, attribIList, NULL, 1,
					 &pixelFormatId, &numPixelFormats);
    if (!success || numPixelFormats < 1) {
	cout << "Could not get pixel format!" << endl;
	exit(1);
    }

    SetPixelFormat(hDC, pixelFormatId, NULL);

    hRC = wglCreateContext( hDC );
    wglMakeCurrent(hDC, hRC);

    ReleaseDC( hWnd, hDC );

    return hRC;
}

static void InitTexture(HWND hWnd, HGLRC shareHRC)
{
    HGLRC hRC;
    HPBUFFERARB hPbuffer;
    HDC hDC;
    HDC pbufferHDC;
    int pixelFormatId;
    UINT numPixelFormats;

  // Make a pbuffer.
    static GLint attribIList[] = {
	WGL_DRAW_TO_PBUFFER_ARB, GL_TRUE,
	WGL_ACCELERATION_ARB, WGL_FULL_ACCELERATION_ARB,
	WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
	WGL_DOUBLE_BUFFER_ARB, GL_FALSE,
	WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB,
	WGL_COLOR_BITS_ARB, 24,
	0
    };
    hDC = GetDC(hWnd);
    int success = glext.ChoosePixelFormatARB(hDC, attribIList, NULL, 1,
					     &pixelFormatId, &numPixelFormats);
    if (!success || numPixelFormats < 1) {
	cout << "Could not get pixel format for pbuffer!" << endl;
	exit(1);
    }

    int tmp = 0;
    hPbuffer = glext.CreatePbufferARB(hDC, pixelFormatId, 256, 256, &tmp);
    pbufferHDC = glext.GetPbufferDCARB(hPbuffer);

    SetPixelFormat(pbufferHDC, pixelFormatId, NULL);

    hRC = wglCreateContext(pbufferHDC);

  // Make sure we share texture space
    wglShareLists(shareHRC, hRC);

    wglMakeCurrent(pbufferHDC, hRC);

  // Make texture image.
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 255, 0, 255, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glViewport(0, 0, 256, 256);

    glDisable(GL_DEPTH_TEST);
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_QUADS);
      glColor3ub(0, 0, 127);
      glVertex3f(0.0, 0.0, 0.0);
      glColor3ub(255, 0, 0);
      glVertex3f(255, 0.0, 0.0);
      glColor3ub(255, 255, 255);
      glVertex3f(255, 255, 0.0);
      glColor3ub(0, 255, 0);
      glVertex3f(0.0, 255, 0.0);
    glEnd();

    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

  // Copy image.
    glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 0, 0, 256, 256, 0);

    GLuint image[256*256];
    glGetTexImage(GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    printf("%X\n%X\n%X\n%X\n", image[0], image[255], image[255*256],
	   image[255*256+255]);

  // Delete pbuffer and stuff.
    glext.ReleasePbufferDCARB(hPbuffer, pbufferHDC);
    glext.DestroyPbufferARB(hPbuffer);
    ReleaseDC(hWnd, hDC);
    wglDeleteContext(hRC);
}

////////////////////////////////////////////////////////// 
//  DrawScene uses OpenGL commands to draw a cube.
//  This is where the OpenGL drawing commands live
////////////////////////////////////////////////////////// 

static void DrawOpenGLScene( )
{

    //
    // Enable depth testing and clear the color and depth
    //  buffers.
    //
    glEnable( GL_DEPTH_TEST );
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    glBindTexture(GL_TEXTURE_2D, texture);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glEnable(GL_TEXTURE_2D);

    //
    // Define the modelview transformation.
    //
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

   // move the viewpoint out to where we can see everything
    glTranslatef( 0.0f, 0.0f, -5.0f );

    // Draw a large triangle out of three smaller triangles
    // sharing common vertex colors

    //  Upper left triangle
    glBegin( GL_POLYGON );
        glColor3f( 0.0f, 0.0f, 0.0f ); // black center
	glTexCoord2f((float)256/(float)256, (float)256/(float)256);
        glVertex3f( 0.0f, 0.0f, 0.0f);
        glColor3f( 0.0f, 1.0f, 0.0f ); // left vertex green
	glTexCoord2f(0.0, (float)256/(float)256);
        glVertex3f(-1.0f, -1.0f, 0.0f);
        glColor3f( 1.0f, 0.0f, 0.0f ); // upper vertex red
	glTexCoord2f((float)256/(float)256, 0.0);
        glVertex3f( 0.0f, 1.0f, 0.0f);            
    glEnd();

    //  bottom triangle
    glBegin( GL_POLYGON );
        glColor3f( 0.0f, 0.0f, 0.0f ); // black center
	glTexCoord2f((float)256/(float)256, (float)256/(float)256);
        glVertex3f( 0.0f, 0.0f, 0.0f);
        glColor3f( 0.0f, 0.0f, 1.0f ); // right vertex blue
	glTexCoord2f(0.0, 0.0);
        glVertex3f( 1.0f, -1.0f, 0.0f);
        glColor3f( 0.0f, 1.0f, 0.0f ); // left vertex green
	glTexCoord2f(0.0, (float)256/(float)256);
        glVertex3f(-1.0f, -1.0f, 0.0f);            
    glEnd();

    //  upper right triangle
    glBegin( GL_POLYGON );
        glColor3f( 0.0f, 0.0f, 0.0f ); // black center
	glTexCoord2f((float)256/(float)256, (float)256/(float)256);
        glVertex3f( 0.0f, 0.0f, 0.0f);
        glColor3f( 1.0f, 0.0f, 0.0f ); // upper vertex red
	glTexCoord2f((float)256/(float)256, 0.0);
        glVertex3f( 0.0f, 1.0f, 0.0f);
        glColor3f( 0.0f, 0.0f, 1.0f ); // bottom right blue
	glTexCoord2f(0.0, 0.0);
        glVertex3f( 1.0f, -1.0f, 0.0f);            
    glEnd();
      
    // Flush the drawing pipeline since it's single buffered
    glFlush ();
 
}
