/*
 * threshold_points.h
 *
 *  Created on: Sep 21, 2011
 *      Author: ollie
 */

#ifndef THRESHOLD_POINTS_H_
#define THRESHOLD_POINTS_H_

template <typename InputDataSet>
struct threshold_points
{

};

#endif /* THRESHOLD_POINTS_H_ */
