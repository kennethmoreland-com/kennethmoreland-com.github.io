
#define DAX_DEVICE_ADAPTER DAX_DEVICE_ADAPTER_OPENMP

#include "pistoncompare.h"

int main(int, char *[])
{
  return RunPistonCompare("OpenMP");
}
