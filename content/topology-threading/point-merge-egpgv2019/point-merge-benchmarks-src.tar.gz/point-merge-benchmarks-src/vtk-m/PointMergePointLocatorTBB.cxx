#define VTKM_DEVICE_ADAPTER VTKM_DEVICE_ADAPTER_TBB

#define _BUILDING_TBB_

#include "PointMergePointLocator.cxx"
