#ifndef definetypes_h
#define definetypes_h

#include <vtkm/Types.h>

using BinIndex = vtkm::Int32;

#endif
