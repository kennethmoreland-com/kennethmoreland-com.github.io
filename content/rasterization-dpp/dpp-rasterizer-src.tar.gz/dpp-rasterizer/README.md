# Rasterization with Data-Parallel Primitives

## About The Project

This project presents a hardware-agnostic rasterization algorithm that handles
race conditions using only data-parallel primitives (DPPs), enabling efficient
rendering on HPC systems without graphics API dependencies and aligning with
recent efforts to deliver visualization software with DPPs.

## Installation 

This project was evaluated on the Talapas, Perlmutter, and Frontier
supercomputers.

### Viskores

(1) Install *Viskores 1.1.0* with the *CUDA*, *Kokkos*, and *TBB* backends.

(2) Create a new directory `dpp-rasterizer-viskores/build`.
  (a) `mkdir dpp-rasterizer-viskores/build/`

(3) Change directories to the `dpp-rasterizer-viskores/build/` directory

(4) Run CMake with `cmake ..` or `ccmake ..` using your desired options.

(5) Make the `rast` executable using `make`.

#### CMake Options

- CUDA_MODE: `ON` compiles the executable for a CUDA architecture. `OFF`
compiles the executable for a non-CUDA architecture.
- CUDA_TARGET_ARCHITECTURE: The target architecture to compile for if
compiling for CUDA.
- DEBUG_LEVEL: The desired level of debug information. Ranges from `0` (no
information) to `4` (All available information)
- DEBUG_MODE: `ON` enables debug messages. `OFF` disable debug messages.
- ENABLE_WARNING: Enables compiler warnings.
- OPTIMIZATION LEVEL: The compiler optimization level (O0-O3).
- TIME_LEVEL: The desired level of timing granularity. `0` provides no
timing, `1` times the algorithm as a whole, `2` times each phase, `3` times
operations within each phase.
- USE_MG_MEM: Enables the program to use managed memory.

### Thrust

(1) Install the *CUDA Toolkit 11.5*.
  (a) Let the path to the *CUDA Toolkit 11.5* `nvcc` compiler as `NVCC`.

(2) Change directories to the `dpp-rasterizer-thrust/` directory.

(3) Open `Makefile` and set `CC` to `NVCC` and uncomment your desired 
compile `flags` (comment out the other `flags`).

(4) Make the project with `make`.

#### Makefile Compile Flags
- Debug CPU: Flags for debugging on a CPU. Uses OpenMP.
- Test CPU: Flags for testing on a CPU. Uses OpenMP.
- Test GPU: Flags for testing on a GPU. Uses CUDA.
These flags may be adjusted to control program behavior. In particular, the
`DDEBUG` and `DTIME` flags define the `DEBUG_LEVEL` and `TIME_LEVEL` in the
same fashion as the *Viskores* version.

## Running

**Viskores:** from `dpp-rasterizer-viskores/`, run the program with:  
```$ build/rast <data set> <output> <image scale> <subdivisions>```  
Additionally, the program can be run with a specific device using:  
```$ build/rast --viskores-device=<device> <data set> <output> <image scale> <subdivisions>```  

**Thrust:** from `dpp-rasterizer-thrust/`, run the program with:  
```$ ./rast <data set> <output> <image scale> <subdivisions>```  

Both programs produce images in a PNM format.

## Testing

Both archives contain a testing suite consisting of three scripts:
`PORTABILITY.sh`, `SCALABILITY.sh`, and `SCALE_SUB.sh`. The data sets can be
found in the `datasets.tar` archive.  

**PORTABILITY:** On a compute node, the `PORTABILITY.sh` script runs the
rasterizer across a directory of data sets.  
When prompted with `Models: ` provide the directory containing your data
sets.  
When prompted with `Images: ` provide a directory for storing output images.  
(Viskores only) When prompted with `Device: ` provide a device to use for
the test.

**SCALABILITY:** On a CPU compute node, the `SCALABILITY.sh` script runs the
rasterizer across multiple levels of parallelism, specifically 0-14 threads.  
When prompted with `FILE: ` provide the path to the data set you would like
to run the test on.

**SCALE_SUB:** On a compute node, the `SCALE_SUB.sh` script runs the
rasterizer across multiple image and model resolutions.  
When prompted with `FILE: ` provide the path to the data set you would like 
to run the test on.

## Triangle Count

Both archives come with a getTriangleCount.c utility program. The program
can be compiled using:
```$ gcc getTriangleCount.c -o getTriangleCount```
The program can be used to check the triangle count of a data set by doing:  
```$ ./getTriangleCount <data set>```
