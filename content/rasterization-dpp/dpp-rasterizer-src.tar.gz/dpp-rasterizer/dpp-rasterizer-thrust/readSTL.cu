#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <limits>
#include <thrust/device_vector.h>
#include <thrust/host_vector.h>
#include <thrust/tuple.h>
#include <thrust/copy.h>

#include "readSTL.h"

/*
    readBinarySTL: A function for reading a binary STL file to standard output

    Parameters:
    * filename: a pointer to an array of characters containing the
    	name of the file to read

    Returns 0 on sucess
*/
int readBinarySTL (char *filename)
{
	//open the stl file in read mode
	FILE *f = fopen(filename, "r");
	//create buffers to store the header of the file and the
	//number of triangles
	char header[80];
	unsigned int numTri = 0;
	//read from the file into the buffers
	fread(header, 1, 80, f);
	fread(&numTri, 4, 1, f);
	//print the values in the buffers
	std::cout << header << std::endl;
	std::cout << numTri << std::endl;
	//read the triangles
	//create buffers for the normal vector, position vectors
	//for the three vertices of each triangle, and attribute
	//byte count
	float normal[3];
	float vert1[3];
	float vert2[3];
	float vert3[3];
	short attr;
	for (int i = 0; i < numTri; i++)
	{
		//read into the buffers
		fread(normal, 4, 3, f);
		fread(vert1, 4, 3, f);
		fread(vert2, 4, 3, f);
		fread(vert3, 4, 3, f);
		fread(&attr, 2, 1, f);
		//print out the values in the buffers
		std::cout << "N\tV1\tV2\tV3" << std::endl;
		for(int j = 0; j < 3; j++)
		{
			std::cout << normal[j] << "\t";
			std::cout << vert1[j] << "\t";
			std::cout << vert2[j] << "\t";
			std::cout << vert3[j] << "\t";
			std::cout << std::endl;
		}
		std::cout << "Attribute Byte Count: " << attr << std::endl;
	}
	//close the file
	fclose(f);
	return 0;
}

/*
    getNumTriSTL: Get the number of triangles encoded within an STL file

    Parameters:
    * filename: a pointer to an array of characters containing the name
    	of the STL file to read

    Returns the number of triangles in the file
*/
unsigned int getNumTriSTL(char *filename)
{
	//open the STL file
	FILE *f = fopen(filename, "r");
	//go to the end of the STL file header
	fseek(f, 80, SEEK_SET);
	//create a buffer to read the number of triangles into
	unsigned int numTri = 0;
	//read the number of triangles into the buffer
	fread(&numTri, 4, 1, f);
	//close the STL file
	fclose(f);
	//return the number of triangles
	return numTri;
}

int getColor(float* norm, thrust::tuple<char,char,char> &color)
{
	float light[3] = {0, 0, 1};
	float mag = std::sqrt(norm[0] * norm[0] + norm[1] * norm[1] + norm[2] * norm[2]);
	float dot = (norm[0] * light[0] + norm[1] * light[1] + norm[2] * light[2]) / mag;
	dot = std::max(dot, 0.0f);
	color = thrust::make_tuple((char)(255 * dot), (char)(255 * dot), (char)(255 * dot));
	/*if(dot > 1)
	{
		std::cout << std::endl;
		std::cout << norm[0] << ", " << norm[1] << ", " << norm[2] << std::endl;
		std::cout << dot << ", " << mag << std::endl;
	}*/
	//std::cout << 255 * dot << ", " << (int) (255 * dot) << ", " << (int)(unsigned char)(char) (255 * dot) << std::endl;
	return 0;
}

/*
    readTriFromBinarySTL: read the triangles of an STL file into buffers

    Parameters:
    * p1: the address of the buffer to store the positions of the first
    	point of each triangle in
    * p2: the address of the buffer to store the positions of the
    	second point of each triangle in
    * p3: the address of the buffer to store the positions of the third
    	point of each triangle in
    * color: the address of the buffer to store the color of each
    	triangle in
    * filename: the name of the file to read

    Returns the number of triangles read
*/

unsigned int readTriFromBinarySTL(
	thrust::device_vector<thrust::tuple<float,float,float>> &p1,
	thrust::device_vector<thrust::tuple<float,float,float>> &p2,
	thrust::device_vector<thrust::tuple<float,float,float>> &p3,
	thrust::device_vector<thrust::tuple<char,char,char>> &color,
	char *filename, int &width, int &height, int scale, int subdivisions)
{
	//get the number of triangles to read
	unsigned int numTri = getNumTriSTL(filename);
	//create host buffers to store data temporarily
	thrust::host_vector<thrust::tuple<float,float,float>> hp1(numTri);
	thrust::host_vector<thrust::tuple<float,float,float>> hp2(numTri);
	thrust::host_vector<thrust::tuple<float,float,float>> hp3(numTri);
	thrust::host_vector<thrust::tuple<char,char,char>> hcolor(numTri);
	//open the file
	FILE *f = fopen(filename, "r");
	//go to the start of the triangle information
	fseek(f, 84, SEEK_SET);
	//iterate over the triangles
	unsigned int i = 0;
	//create buffers for each bit of triangle information
	float norm[3];
	float v1[3];
	float v2[3];
	float v3[3];
	short attr;
	//iterate over triangles for max and min values
	//variables for tracking lowest values
	int lowx = std::numeric_limits<int>::max();
	int lowy = std::numeric_limits<int>::max();
	//reset width and height to minimum possible value
	width = std::numeric_limits<int>::min();
	height = std::numeric_limits<int>::min();
	for(; i < numTri; i++)
	{
		//read into buffers
		fread(norm, 4, 3, f);
		fread(v1, 4, 3, f);
		fread(v2, 4, 3, f);
		fread(v3, 4, 3, f);
		fread(&attr, 2, 1, f);
		//scale up positions 
		for (int j = 0; j < 3; j++)
		{
			v1[j] *= scale;
			v2[j] *= scale;
			v3[j] *= scale;
		}
		//process buffers
		width = std::max(width, std::max((int) v1[0], std::max((int) v2[0], (int) v3[0])) + 1);
		height = std::max(height, std::max((int) v1[1], std::max((int) v2[1], (int) v3[1])) + 1);
		lowx = std::min(lowx, std::min((int) v1[0], std::min((int) v2[0], (int) v3[0])));
		lowy = std::min(lowy, std::min((int) v1[1], std::min((int) v2[1], (int) v3[1])));
	}
	width -= lowx;
	height -= lowy;
	//std::cout << "LOWX: " << lowx << " LOWY: " << lowy << std::endl;

	fseek(f, 84, SEEK_SET); //go back to the start of the file

	//iterate over the triangles to read into triangle buffers
	
	//std::cout << "x, y, z" << std::endl;
	for(i = 0; i < numTri; i++)
	{
		//read into buffers
		fread(norm, 4, 3, f);
		fread(v1, 4, 3, f);
		fread(v2, 4, 3, f);
		fread(v3, 4, 3, f);
		fread(&attr, 2, 1, f);
		//scale up positions
		for(int j = 0; j < 3; j++)
		{
			v1[j] *= scale;
			v2[j] *= scale;
			v3[j] *= scale;
		}
		//process buffers
		//std::cout << v1[0] - lowx << ", " << v1[1] - lowy << ", " << v1[2] << std::endl;
		hp1[i] = thrust::make_tuple(v1[0] - lowx, v1[1] - lowy, v1[2]);
		//std::cout << v2[0] - lowx << ", " << v2[1] - lowy << ", " << v2[2] << std::endl;
		hp2[i] = thrust::make_tuple(v2[0] - lowx, v2[1] - lowy, v2[2]);
		//std::cout << v3[0] - lowx << ", " << v3[1] - lowy << ", " << v3[2] << std::endl;
		hp3[i] = thrust::make_tuple(v3[0] - lowx, v3[1] - lowy, v3[2]);
		getColor(norm, hcolor[i]);
	}
	//std::cout << std::endl;

	// Subdivide triangles
	unsigned int curNumTri = numTri;
	for(int j = 0; j < subdivisions; j++)
	{
		// Create temporary buffers for subdivision	
		thrust::host_vector<thrust::tuple<float,float,float>> tp1(curNumTri * 4);
		thrust::host_vector<thrust::tuple<float,float,float>> tp2(curNumTri * 4);
		thrust::host_vector<thrust::tuple<float,float,float>> tp3(curNumTri * 4);
		thrust::host_vector<thrust::tuple<char,char,char>> tcolor(curNumTri * 4);

		// Do one subdivision
		for(i = 0; i < curNumTri; i++)
		{
			// Original points
			auto v1 = hp1[i];
			auto v2 = hp2[i];
			auto v3 = hp3[i];

			// Midpoints
			auto v12 = thrust::make_tuple<float,float,float>(
					(thrust::get<0>(v1) + thrust::get<0>(v2))/2,
					(thrust::get<1>(v1) + thrust::get<1>(v2))/2,
					(thrust::get<2>(v1) + thrust::get<2>(v2))/2);
			auto v13 = thrust::make_tuple<float,float,float>(
					(thrust::get<0>(v1) + thrust::get<0>(v3))/2,
					(thrust::get<1>(v1) + thrust::get<1>(v3))/2,
					(thrust::get<2>(v1) + thrust::get<2>(v3))/2);
			auto v23 = thrust::make_tuple<float,float,float>(
					(thrust::get<0>(v2) + thrust::get<0>(v3))/2,
					(thrust::get<1>(v2) + thrust::get<1>(v3))/2,
					(thrust::get<2>(v2) + thrust::get<2>(v3))/2);

			// New Triangles
			unsigned int k = i * 4;	

			tp1[k] = v1;
			tp2[k] = v12;
			tp3[k] = v13;
			tcolor[k] = hcolor[i];

			tp1[k+1] = v12;
			tp2[k+1] = v2;
			tp3[k+1] = v23;
			tcolor[k+1] = hcolor[i];

			tp1[k+2] = v13;
			tp2[k+2] = v23;
			tp3[k+2] = v3;
			tcolor[k+2] = hcolor[i];

			tp1[k+3] = v12;
			tp2[k+3] = v23;
			tp3[k+3] = v13;
			tcolor[k+3] = hcolor[i];
		}

		// Resize vectors
		curNumTri *= 4;
		hp1.resize(curNumTri);
		hp2.resize(curNumTri);
		hp3.resize(curNumTri);
		hcolor.resize(curNumTri);

		// Copy temporary vectors
		hp1 = tp1;
		hp2 = tp2;
		hp3 = tp3;
		hcolor = tcolor;
	}

	//copy host vectors into device vectors
	//thrust::copy(p1.begin(), p1.end(), hp1.begin());
	p1 = hp1;
	p2 = hp2;
	p3 = hp3;
	color = hcolor;

	return curNumTri;
}

/*int main(int argc, char **argv)
{
	readBinarySTL(argv[1]);
	unsigned int numTri = getNumTriSTL(argv[1]);
	std::cout << numTri << std::endl;
	thrust::device_vector<thrust::tuple<float,float,float>> p1(numTri);
	thrust::device_vector<thrust::tuple<float,float,float>> p2(numTri);
	thrust::device_vector<thrust::tuple<float,float,float>> p3(numTri);
	thrust::device_vector<thrust::tuple<char,char,char>> color(numTri);
	readTriFromBinarySTL(p1, p2, p3, color, argv[1]);
	thrust::host_vector<thrust::tuple<float,float,float>> temp = p1;
	for(int i = 0; i < temp.size(); i++)
		std::cout << temp[i].get<0>() << "\t";
	std::cout << std::endl;
	return 0;
}*/
