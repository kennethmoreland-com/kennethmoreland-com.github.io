// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramScale.cxx,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#include "ocaProgramScale.h"

#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"

#include <iostream>

ocaProgramScale::ocaProgramScale()
{
    this->loadProgram("scale.cg", "ScaleVert", "ScaleFrag");

    this->position = cgGetNamedParameter(this->vertProgram, "input.position");
    if (this->position == NULL) {
	ocaRaiseError("Could not get pointer for position parameter.");
    }

    this->scale = cgGetNamedParameter(this->fragProgram, "scale");
    if (this->scale == NULL) {
	ocaRaiseError("Could not get pointer for scale parameter.");
    }

    this->source = cgGetNamedParameter(this->fragProgram, "source");
    if (this->source == NULL) {
	ocaRaiseError("Could not get pointer for source parameter.");
    }
}

ocaProgramScale::~ocaProgramScale()
{
}

static GLfloat fullScreenSquare[] = {
    -1.0, -1.0,
    1.0, -1.0,
    1.0, 1.0,
    -1.0, 1.0
};

void ocaProgramScale::execute(ocaLookUpBuffer::pointer src, float scale,
			      ocaDrawableBuffer::pointer dest)
{
    ocaOpenGLContext::ScopedContext saveContext;

    dest->makeCurrent();
    this->bind();

    cgGLSetParameter1f(this->scale, scale);
    cgGLSetTextureParameter(this->source, src->getTextureId());
    cgGLEnableTextureParameter(this->source);

    cgGLSetParameterPointer(this->position, 2, GL_FLOAT, 0, fullScreenSquare);
    cgGLEnableClientState(this->position);

    glDrawArrays(GL_POLYGON, 0, 4);

    cgGLDisableClientState(this->position);
    cgGLDisableTextureParameter(this->source);
    this->unbind();
}
