// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaOpenGLExtensions.h,v 1.1 2003/06/30 18:33:18 kmorel Exp $

#ifndef _ocaOpenGLExtensions_h
#define _ocaOpenGLExtensions_h

#include "ocaConfig.h"

#include <GL/glext.h>

#ifdef WIN32
#  include <GL/wglext.h>
#else
#  ifdef GLX_ARB_get_proc_address
     typedef void (*__GLXextFuncPtr)(void);
#  endif
#  ifndef GLX_VERSION_1_4
     //Before GLX 1.4, PFN typedefs were not needed on UNIX.  If GL/glx.h
     //is not 1.4 compliant, we need to reload any extensions.  This may
     //result in compiler warnings about redefinitions.
#    ifdef GLX_SGIX_fbconfig
#      undef GLX_SGIX_fbconfig
#      undef GLX_WINDOW_BIT_SGIX
#      undef GLX_PIXMAP_BIT_SGIX
#      undef GLX_RGBA_BIT_SGIX
#      undef GLX_COLOR_INDEX_BIT_SGIX
#      undef GLX_DRAWABLE_TYPE_SGIX
#      undef GLX_RENDER_TYPE_SGIX
#      undef GLX_X_RENDERABLE_SGIX
#      undef GLX_FBCONFIG_ID_SGIX
#      undef GLX_RGBA_TYPE_SGIX
#      undef GLX_COLOR_INDEX_TYPE_SGIX
#    endif
#    ifdef GLX_SGIX_pbuffer
#      undef GLX_SGIX_pbuffer
#      undef GLX_PBUFFER_BIT_SGIX
#      undef GLX_BUFFER_CLOBBER_MASK_SGIX
#      undef GLX_FRONT_LEFT_BUFFER_BIT_SGIX
#      undef GLX_FRONT_RIGHT_BUFFER_BIT_SGIX
#      undef GLX_BACK_LEFT_BUFFER_BIT_SGIX
#      undef GLX_BACK_RIGHT_BUFFER_BIT_SGIX
#      undef GLX_AUX_BUFFERS_BIT_SGIX
#      undef GLX_DEPTH_BUFFER_BIT_SGIX
#      undef GLX_STENCIL_BUFFER_BIT_SGIX
#      undef GLX_ACCUM_BUFFER_BIT_SGIX
#      undef GLX_SAMPLE_BUFFERS_BIT_SGIX
#      undef GLX_MAX_PBUFFER_WIDTH_SGIX
#      undef GLX_MAX_PBUFFER_HEIGHT_SGIX
#      undef GLX_MAX_PBUFFER_PIXELS_SGIX
#      undef GLX_OPTIMAL_PBUFFER_WIDTH_SGIX
#      undef GLX_OPTIMAL_PBUFFER_HEIGHT_SGIX
#      undef GLX_PRESERVED_CONTENTS_SGIX
#      undef GLX_LARGEST_PBUFFER_SGIX
#      undef GLX_WIDTH_SGIX
#      undef GLX_HEIGHT_SGIX
#      undef GLX_EVENT_MASK_SGIX
#      undef GLX_DAMAGED_SGIX
#      undef GLX_SAVED_SGIX
#      undef GLX_WINDOW_SGIX
#      undef GLX_PBUFFER_SGIX
#    endif
#  endif
#  include <GL/glxext.h>
#endif

#ifndef APIENTRY
# if defined(__CYGWIN__) || defined(__MINGW32__)
#  define APIENTRY __attribute__ ((__stdcall__))
# else /* define APIENTRY to null string if we aren't on Cygwin or Mingw */
#  define APIENTRY
# endif
# define GL_APIENTRY_DEFINED
#endif

// Prototypes for NV30 extensions not yet prototyped in GL/glext.h and
// WGL/glext.h
#ifndef WGL_NV_render_texture_rectangle
#define WGL_NV_render_texture_rectangle
#define WGL_BIND_TO_TEXTURE_RECTANGLE_RGB_NV		0x20A0
#define WGL_BIND_TO_TEXTURE_RECTANGLE_RGBA_NV		0x20A1
#define WGL_TEXTURE_RECTANGLE_NV			0x20A2
#endif //WGL_NV_render_texture_rectangle

#ifndef GL_NV_float_buffer
#define GL_NV_float_buffer 1
#define GL_FLOAT_R_NV					0x8880
#define GL_FLOAT_RG_NV					0x8881
#define GL_FLOAT_RGB_NV					0x8882
#define GL_FLOAT_RGBA_NV				0x8883
#define GL_TEXTURE_FLOAT_COMPONENTS_NV			0x888C
#define GL_FLOAT_CLEAR_COLOR_VALUE_NV			0x888D
#define GL_FLOAT_RGBA_MODE_NV				0x888E
#endif //GL_NV_float_buffer

#ifndef WGL_NV_float_buffer
#define WGL_NV_float_buffer 1
#define WGL_FLOAT_COMPONENTS_NV				0x20B0
#define WGL_BIND_TO_TEXTURE_RECTANGLE_FLOAT_R_NV	0x20B1
#define WGL_BIND_TO_TEXTURE_RECTANGLE_FLOAT_RG_NV	0x20B2
#define WGL_BIND_TO_TEXTURE_RECTANGLE_FLOAT_RGB_NV	0x20B3
#define WGL_BIND_TO_TEXTURE_RECTANGLE_FLOAT_RGBA_NV	0x20B4
#define WGL_TEXTURE_FLOAT_R_NV				0x20B5
#define WGL_TEXTURE_FLOAT_RG_NV				0x20B6
#define WGL_TEXTURE_FLOAT_RGB_NV			0x20B7
#define WGL_TEXTURE_FLOAT_RGBA_NV			0x20B8
#endif //WGL_NV_float_buffer

#ifndef GL_NV_vertex_program2
#define GL_NV_vertex_program2 1
#endif //GL_NV_vertex_program2

#ifndef GL_NV_fragment_program
#define GL_NV_fragment_program 1
#define GL_FRAGMENT_PROGRAM_NV				0x8870
#define GL_MAX_TEXTURE_COORDS_NV			0x8871
#define GL_MAX_TEXTURE_IMAGE_UNITS_NV			0x8872
#define GL_FRAGMENT_PROGRAM_BINDING_NV			0x8873
#define GL_MAX_FRAGMENT_PROGRAM_LOCAL_PARAMETERS_NV	0x8868
#define GL_PROGRAM_ERROR_STRING_NV			0x8874
typedef void (APIENTRY * PFNGLPROGRAMLOCALPARAMETER4DARBPROC)
    (GLenum target, GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
typedef void (APIENTRY * PFNGLPROGRAMLOCALPARAMETER4DVARBPROC)
    (GLenum target, GLuint index, const GLdouble *params);
typedef void (APIENTRY * PFNGLPROGRAMLOCALPARAMETER4FARBPROC)
    (GLenum target, GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
typedef void (APIENTRY * PFNGLPROGRAMLOCALPARAMETER4FVARBPROC)
    (GLenum target, GLuint index, const GLfloat *params);
typedef void (APIENTRY * PFNGLGETPROGRAMLOCALPARAMETERDVARBPROC)
    (GLenum target, GLuint index, GLdouble *params);
typedef void (APIENTRY * PFNGLGETPROGRAMLOCALPARAMETERFVARBPROC)
    (GLenum target, GLuint index, GLfloat *params);
#endif //GL_NV_fragment_program

#ifdef GL_APIENTRY_DEFINED
#undef APIENTRY
#endif

struct _ocagl{
#ifdef WIN32
  // From WGL_ARB_pixel_format
    PFNWGLGETPIXELFORMATATTRIBIVARBPROC GetPixelFormatAttribivARB;
    PFNWGLGETPIXELFORMATATTRIBFVARBPROC GetPixelFormatAttribfvARB;
    PFNWGLCHOOSEPIXELFORMATARBPROC ChoosePixelFormatARB;

  // From WGL_ARB_pbuffer
    PFNWGLCREATEPBUFFERARBPROC CreatePbufferARB;
    PFNWGLGETPBUFFERDCARBPROC GetPbufferDCARB;
    PFNWGLRELEASEPBUFFERDCARBPROC ReleasePbufferDCARB;
    PFNWGLDESTROYPBUFFERARBPROC DestroyPbufferARB;
    PFNWGLQUERYPBUFFERARBPROC QueryPbufferARB;

  // From WGL_ARB_render_texture
    PFNWGLBINDTEXIMAGEARBPROC BindTexImageARB;
    PFNWGLRELEASETEXIMAGEARBPROC ReleaseTexImageARB;
    PFNWGLSETPBUFFERATTRIBARBPROC SetPbufferAttribARB;
#endif

#ifndef WIN32
    PFNGLXGETFBCONFIGATTRIBSGIXPROC GetFBConfigAttribSGIX;
    PFNGLXCHOOSEFBCONFIGSGIXPROC ChooseFBConfigSGIX;
    PFNGLXCREATEGLXPIXMAPWITHCONFIGSGIXPROC CreateGLXPixmapWithConfigSGIX;
    PFNGLXCREATECONTEXTWITHCONFIGSGIXPROC CreateContextWithConfigSGIX;
    PFNGLXGETVISUALFROMFBCONFIGSGIXPROC GetVisualFromFBConfigSGIX;
    PFNGLXGETFBCONFIGFROMVISUALSGIXPROC GetFBConfigFromVisualSGIX;

    PFNGLXCREATEGLXPBUFFERSGIXPROC CreateGLXPbufferSGIX;
    PFNGLXDESTROYGLXPBUFFERSGIXPROC DestroyGLXPbufferSGIX;
    PFNGLXQUERYGLXPBUFFERSGIXPROC QueryGLXPbufferSGIX;
    PFNGLXSELECTEVENTSGIXPROC SelectEventSGIX;
    PFNGLXGETSELECTEDEVENTSGIXPROC GetSelectedEventSGIX;
#endif

#if 0
  // From GL_NV_vertex_program(2)
    PFNGLBINDPROGRAMNVPROC BindProgramNV;
    PFNGLDELETEPROGRAMSNVPROC DeleteProgramsNV;
    PFNGLEXECUTEPROGRAMNVPROC ExecuteProgramNV;
    PFNGLGENPROGRAMSNVPROC GenProgramsNV;
    PFNGLAREPROGRAMSRESIDENTNVPROC AreProgramsResidentNV;
    PFNGLREQUESTRESIDENTPROGRAMSNVPROC RequestResidentProgramsNV;
    PFNGLGETPROGRAMPARAMETERFVNVPROC GetProgramParameterfvNV;
    PFNGLGETPROGRAMPARAMETERDVNVPROC GetProgramParameterdvNV;
    PFNGLGETPROGRAMIVNVPROC GetProgramivNV;
    PFNGLGETPROGRAMSTRINGNVPROC GetProgramStringNV;
    PFNGLGETTRACKMATRIXIVNVPROC GetTrackMatrixivNV;
    PFNGLGETVERTEXATTRIBDVNVPROC GetVertexAttribdvNV;
    PFNGLGETVERTEXATTRIBFVNVPROC GetVertexAttribfvNV;
    PFNGLGETVERTEXATTRIBIVNVPROC GetVertexAttribivNV;
    PFNGLGETVERTEXATTRIBPOINTERVNVPROC GetVertexAttribPointervNV;
    PFNGLISPROGRAMNVPROC IsProgramNV;
    PFNGLLOADPROGRAMNVPROC LoadProgramNV;
    PFNGLPROGRAMPARAMETER4FNVPROC ProgramParameter4fNV;
    PFNGLPROGRAMPARAMETER4DNVPROC ProgramParameter4dNV;
    PFNGLPROGRAMPARAMETER4DVNVPROC ProgramParameter4dvNV;
    PFNGLPROGRAMPARAMETER4FVNVPROC ProgramParameter4fvNV;
    PFNGLPROGRAMPARAMETERS4DVNVPROC ProgramParameters4dvNV;
    PFNGLPROGRAMPARAMETERS4FVNVPROC ProgramParameters4fvNV;
    PFNGLTRACKMATRIXNVPROC TrackMatrixNV;
    PFNGLVERTEXATTRIBPOINTERNVPROC VertexAttribPointerNV;
    PFNGLVERTEXATTRIB1SNVPROC VertexAttrib1sNV;
    PFNGLVERTEXATTRIB1FNVPROC VertexAttrib1fNV;
    PFNGLVERTEXATTRIB1DNVPROC VertexAttrib1dNV;
    PFNGLVERTEXATTRIB2SNVPROC VertexAttrib2sNV;
    PFNGLVERTEXATTRIB2FNVPROC VertexAttrib2fNV;
    PFNGLVERTEXATTRIB2DNVPROC VertexAttrib2dNV;
    PFNGLVERTEXATTRIB3SNVPROC VertexAttrib3sNV;
    PFNGLVERTEXATTRIB3FNVPROC VertexAttrib3fNV;
    PFNGLVERTEXATTRIB3DNVPROC VertexAttrib3dNV;
    PFNGLVERTEXATTRIB4SNVPROC VertexAttrib4sNV;
    PFNGLVERTEXATTRIB4FNVPROC VertexAttrib4fNV;
    PFNGLVERTEXATTRIB4DNVPROC VertexAttrib4dNV;
    PFNGLVERTEXATTRIB4UBNVPROC VertexAttrib4ubNV;
    PFNGLVERTEXATTRIB1SVNVPROC VertexAttrib1svNV;
    PFNGLVERTEXATTRIB1FVNVPROC VertexAttrib1fvNV;
    PFNGLVERTEXATTRIB1DVNVPROC VertexAttrib1dvNV;
    PFNGLVERTEXATTRIB2SVNVPROC VertexAttrib2svNV;
    PFNGLVERTEXATTRIB2FVNVPROC VertexAttrib2fvNV;
    PFNGLVERTEXATTRIB2DVNVPROC VertexAttrib2dvNV;
    PFNGLVERTEXATTRIB3SVNVPROC VertexAttrib3svNV;
    PFNGLVERTEXATTRIB3FVNVPROC VertexAttrib3fvNV;
    PFNGLVERTEXATTRIB3DVNVPROC VertexAttrib3dvNV;
    PFNGLVERTEXATTRIB4SVNVPROC VertexAttrib4svNV;
    PFNGLVERTEXATTRIB4FVNVPROC VertexAttrib4fvNV;
    PFNGLVERTEXATTRIB4DVNVPROC VertexAttrib4dvNV;
    PFNGLVERTEXATTRIB4UBVNVPROC VertexAttrib4ubvNV;
    PFNGLVERTEXATTRIBS1SVNVPROC VertexAttribs1svNV;
    PFNGLVERTEXATTRIBS1FVNVPROC VertexAttribs1fvNV;
    PFNGLVERTEXATTRIBS1DVNVPROC VertexAttribs1dvNV;
    PFNGLVERTEXATTRIBS2SVNVPROC VertexAttribs2svNV;
    PFNGLVERTEXATTRIBS2FVNVPROC VertexAttribs2fvNV;
    PFNGLVERTEXATTRIBS2DVNVPROC VertexAttribs2dvNV;
    PFNGLVERTEXATTRIBS3SVNVPROC VertexAttribs3svNV;
    PFNGLVERTEXATTRIBS3FVNVPROC VertexAttribs3fvNV;
    PFNGLVERTEXATTRIBS3DVNVPROC VertexAttribs3dvNV;
    PFNGLVERTEXATTRIBS4SVNVPROC VertexAttribs4svNV;
    PFNGLVERTEXATTRIBS4FVNVPROC VertexAttribs4fvNV;
    PFNGLVERTEXATTRIBS4DVNVPROC VertexAttribs4dvNV;
    PFNGLVERTEXATTRIBS4UBVNVPROC VertexAttribs4ubvNV;
#endif
};

extern struct _ocagl ocagl;

void ocaInitExtensions();

#endif //_ocaOpenGLExtensions_h
