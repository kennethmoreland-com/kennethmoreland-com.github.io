// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaObject.h,v 1.2 2003/06/30 20:18:40 kmorel Exp $

#ifndef _ocaObject_h
#define _ocaObject_h

#include "ocaConfig.h"
#include "ocaError.h"
#include "ocaOpenGLExtensions.h"

// A smart pointer template class that takes a pointer to an oca object
// and automatically increments and decrements its reference count as
// the pointer goes in and out of scope.
template<class ocaClass>
class ocaSmartPointer
{
  protected:
    ocaClass *ref;
    inline void setref(ocaClass *reference) {
	if (this->ref != reference) {
	    if (this->ref != NULL) this->ref->Unregister();
	    this->ref = reference;
	    if (this->ref != NULL) this->ref->Register();
	}
    }
  public:
    inline ocaSmartPointer() : ref(NULL) {}
    inline ocaSmartPointer(const ocaSmartPointer<ocaClass> &src)
	: ref(src.getRef()) {
	if (this->ref) this->ref->Register();
    }
    inline ocaSmartPointer(ocaClass *reference) : ref(reference) {
	if (this->ref) this->ref->Register();
    }
    inline ~ocaSmartPointer() {
	if (this->ref) this->ref->Unregister();
    }
    inline bool isNull() const { return (this->ref == NULL); }
    inline const ocaSmartPointer<ocaClass>
	&operator=(const ocaSmartPointer<ocaClass> &src) {
	this->setref(src.getRef());
	return *this;
    }
    inline bool operator==(const ocaSmartPointer<ocaClass> &src) const {
	return this->ref == src.ref;
    }
    inline bool operator==(const ocaClass *src) const {
	return this->ref == src;
    }
    inline bool operator!=(const ocaSmartPointer<ocaClass> &src) const {
	return this->ref != src.ref;
    }
    inline bool operator!=(const ocaClass *src) const {
	return this->ref != src;
    }
    inline bool operator<(const ocaSmartPointer<ocaClass> &src) const {
	return this->ref < src.ref;
    }
    inline ocaClass *operator->() const { return this->ref; }
    inline ocaClass *getRef() const { return this->ref; }
};

// Dynamically cast from one type of smart pointer to another.
template<class ocaClassDest, class ocaClassSrc>
ocaSmartPointer<ocaClassDest> ocaCast(ocaSmartPointer<ocaClassSrc> src) {
    return ocaSmartPointer<ocaClassDest>(dynamic_cast<ocaClassDest *>(src.getRef()));
}


// All ocaObjects include the ocaTypeMacro giving its name and its
// superclass name.  They also all contain an internal class whose name is
// is pointer and publicly inherits from the super data of the same name.
// This class is a smart pointer.  It names this class as a friend and has
// a protected constructor that takes a pointer to the class.
#define ocaTypeMacro(classname, supername)				\
  public:								\
    typedef ocaSmartPointer<classname> pointer;				\
    virtual const char *getClassName() const { return #classname; }	\
    virtual bool isA(const char *name) const {				\
	return (strcmp(name, #classname) == 0)				\
	    ? true : this->supername::isA(name);			\
    }									\
    typedef supername super;

// A singleton works much like any other ocaObject except that it declares
// the ocaSingletonMacro instead of the ocaTypeMacro.  A static instance of
// the pointer class called singleton is declared (and initialized to
// NULL).
#define ocaSingletonMacro(classname, supername)				\
    ocaTypeMacro(classname, supername)					\
    static pointer getSingleton() {					\
	pointer s							\
	    = ocaCast<classname>(ocaObject::getRegisteredSingleton(#classname));\
	if (s.isNull()) {						\
	    s = new classname;						\
	    ocaObject::registerSingleton(ocaCast<ocaObject>(s));	\
	}								\
	return s;							\
    }									\
  protected:								\
    virtual bool isSingleton() const { return true; }			\
  public:


class OCA_EXPORT ocaObject
{
  public:
    typedef ocaSmartPointer<ocaObject> pointer;

    virtual ~ocaObject();

    virtual const char *getClassName() const { return "ocaObject"; }
    virtual bool isA(const char *name) const {
	return (strcmp(name, "ocaObject") == 0);
    }
    virtual bool isA(const ocaObject &src) const {
	return this->isA(src.getClassName());
    }
    virtual bool isSingleton() const { return false; }

    static void initialize();
    static void finalize();

    static bool initialized();
    static bool finalized();

    virtual void Register();
    virtual void Unregister();

  protected:
    ocaObject();

    int refcount;

    static pointer &getRegisteredSingleton(const char *classname);
    static void registerSingleton(pointer singleton);

  private:
    ocaObject(const ocaObject &src);		//Not implemented
    void operator=(const ocaObject &src);	//Not implemented
};

#undef ocaSmartPointerMacro

#endif //_ocaObject_h
