// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT1c.h,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#ifndef _ocaProgramFFT1c_h
#define _ocaProgramFFT1c_h

#include "ocaProgram.h"

class ocaLookUpBuffer;
class ocaDrawableBuffer;

class OCA_EXPORT ocaProgramFFT1c : public ocaProgram
{
  public:
    ocaProgramMacro(FFT1c);

    void execute(ocaSmartPointer<ocaLookUpBuffer> samples,
		 ocaSmartPointer<ocaDrawableBuffer> frequencies);
    void execute(ocaSmartPointer<ocaLookUpBuffer> samples,
		 ocaSmartPointer<ocaDrawableBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> temporary);

    static void uncompress(int windowsize, int vectorsize,
			   const float *freqcompress,
			   float *freqreal, float *freqimag = NULL);
    static void compress(int windowsize, int vectorsize, float *freqcompress,
			 const float *freqreal, const float *freqimag = NULL);
};

class ocaProgramFFT1cCore : public ocaProgram
{
  public:
    ocaProgramMacro(FFT1cCore);

    void execute(ocaSmartPointer<ocaLookUpBuffer> source,
		 ocaSmartPointer<ocaDrawableBuffer> &target,
		 ocaSmartPointer<ocaDrawableBuffer> &feedback,
		 bool forward);
};

class ocaProgramFFT1cHelpers : public ocaProgram
{
  public:
    void execute(ocaSmartPointer<ocaLookUpBuffer> source,
		 int partitionSize, int numPartitions,
		 float *realIndexes, float *imagIndexes,
		 bool forward);

  protected:
    ocaProgramFFT1cHelpers() {}
    void load_program(const char **compilerArgs);
    CGparameter realIndex;
    CGparameter imagIndex;
    CGparameter ArraySizeVert;
    CGparameter ArraySizeFrag;
    CGparameter PartitionSize;
    CGparameter NumPartitions;
    CGparameter Direction;
    CGparameter InputSamples;
};


class ocaProgramFFT1cUntanglers : public ocaProgram
{
  public:
    void execute(ocaSmartPointer<ocaLookUpBuffer> source,
		 const float *realFRegion, const float *realGRegion,
		 const float *imagFRegion, const float *imagGRegion,
		 float scale);
  protected:
    ocaProgramFFT1cUntanglers() {}
    void load_program(const char **compilerArgs);
    CGparameter realFIndex;
    CGparameter imagFIndex;
    CGparameter realGIndex;
    CGparameter imagGIndex;
    CGparameter ArraySize;
    CGparameter Scale;
    CGparameter TangledFrequencies;
};
class ocaProgramFFT1cUntangleRealF : public ocaProgramFFT1cUntanglers
{
  public:
    ocaProgramMacro(FFT1cUntangleRealF);
  protected:
    const static char *compilerArgs[];
};
class ocaProgramFFT1cUntangleRealG : public ocaProgramFFT1cUntanglers
{
  public:
    ocaProgramMacro(FFT1cUntangleRealG);
  protected:
    const static char *compilerArgs[];
};
class ocaProgramFFT1cUntangleImagF : public ocaProgramFFT1cUntanglers
{
  public:
    ocaProgramMacro(FFT1cUntangleImagF);
  protected:
    const static char *compilerArgs[];
};
class ocaProgramFFT1cUntangleImagG : public ocaProgramFFT1cUntanglers
{
  public:
    ocaProgramMacro(FFT1cUntangleImagG);
  protected:
    const static char *compilerArgs[];
};

#endif //_ocaProgramFFT1c_h
