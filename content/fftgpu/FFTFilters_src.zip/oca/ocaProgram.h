// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgram.h,v 1.1 2003/06/30 18:33:18 kmorel Exp $

#ifndef _ocaProgram_h
#define _ocaProgram_h

#include "ocaObject.h"

#include <string>

// #ifdef WIN32
// #undef WIN32
// #define WIN32 1
// #endif
#include <Cg/cgGL.h>

#define ocaProgramMacro(programname)					\
    ocaSingletonMacro(ocaProgram ## programname, ocaProgram);		\
  protected:								\
    ocaProgram ## programname();					\
    ~ocaProgram ## programname();					\
  public:

class OCA_EXPORT ocaProgram : public ocaObject
{
  public:
    ocaTypeMacro(ocaProgram, ocaObject);

  // Binds the program.
    virtual void bind();

  // Releases the program.
    virtual void unbind();

  // Called by ocaObject::initialize()
    static void findSourceDirectory();

  protected:
    ocaProgram();
    virtual ~ocaProgram();

    bool valid;
    CGcontext programContext;
    CGprogram vertProgram;
    CGprogram fragProgram;

    CGprofile vertProfile;
    CGprofile fragProfile;

  // Loads the given program from "../share/oca/Cg", initializes the contents
  // of data to it, and sets data->valid to true.
    virtual void loadProgram(const char *filename,
			     const char *vertProgEntry,
			     const char *fragProgEntry);
    virtual void loadProgram(const char *filename,
			     const char *vertProgEntry,
			     const char *fragProgEntry,
			     const char **compilerArgs);

    static std::string sourceDirectory;
};

#endif //_ocaProgram_h
