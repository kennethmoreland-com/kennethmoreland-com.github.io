// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaOpenGLContext.cxx,v 1.1 2003/06/30 18:33:18 kmorel Exp $

#include "ocaOpenGLContext.h"

#include "ocaOpenGLExtensions.h"
#include "ocaLookUpBuffer.h"
#include <stack>

static std::stack<ocaOpenGLContext::pointer> contextStack;
ocaOpenGLContext::pointer ocaOpenGLContext::current;

ocaOpenGLContext::ocaOpenGLContext() : valid(false) {}

ocaOpenGLContext::~ocaOpenGLContext() {
    if (this->valid) {
#ifdef WIN32
	ReleaseDC(this->hWnd, this->hDC);
	wglDeleteContext(this->hRC);
#else
	glXDestroyContext(this->DisplayId, this->ContextId);
#endif
    }
}

void ocaOpenGLContext::makeCurrent() const
{
    if (ocaOpenGLContext::current != this) {
#ifdef WIN32
	wglMakeCurrent(this->hDC, this->hRC);
#else
	glXMakeCurrent(this->DisplayId, this->DrawableId, this->ContextId);
#endif
	ocaOpenGLContext::current
	    = ocaOpenGLContext::pointer((ocaOpenGLContext *)this);
    }
}

bool ocaOpenGLContext::isValid() const
{
    return this->valid;
}

void ocaOpenGLContext::pushContext()
{
    contextStack.push(ocaOpenGLContext::current);
}

void ocaOpenGLContext::popContext()
{
    if (contextStack.empty()) {
	ocaRaiseError("Tried to pop empty context binding stack.");
    }
    contextStack.top()->makeCurrent();
    contextStack.pop();
}

void ocaOpenGLContext::pushBinding()
{
    ocaOpenGLContext::ScopedContext();
    this->makeCurrent();
    this->bindingStack.push(ocaLookUpBuffer::getCurrent());
}

void ocaOpenGLContext::popBinding()
{
    if (this->bindingStack.empty()) {
	ocaRaiseError("Attempted to pop empty binding stack.");
    }
    ocaOpenGLContext::ScopedContext();
    this->makeCurrent();
    ocaLookUpBuffer::pointer lub = this->bindingStack.top();
    if (lub.isNull()) {
	glBindTexture(GL_TEXTURE_RECTANGLE_NV, 0);
    } else {
	lub->bind();
    }
    this->bindingStack.pop();
}

void ocaOpenGLContext::finalize()
{
    ocaOpenGLContext::current = NULL;
}
