// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaLookUpBuffer.h,v 1.1 2003/06/30 18:33:18 kmorel Exp $

#ifndef _ocaLookUpBuffer_h
#define _ocaLookUpBuffer_h

#include "ocaObject.h"
#include "ocaBuffer.h"

class ocaFactory;
class ocaOpenGLContext;

class OCA_EXPORT ocaLookUpBuffer : public ocaBuffer
{
  public:
    ocaTypeMacro(ocaLookUpBuffer, ocaBuffer);
    virtual ~ocaLookUpBuffer();

    virtual const int *getSize() const { return this->size; }
    virtual int getVectorSize() const { return this->vectorSize; }

    virtual GLuint getTextureId() const { return this->textureId; }

  // This should be used with caution since it does not actually resize
  // the data.
    virtual void setSize(int sizex, int sizey, int sizev);

    virtual void getData(float *buffer) const;
    virtual void setData(float *buffer);
    virtual void setData(float *buffer, int sizex, int sizey, int sizev);
    virtual void copy(const ocaBuffer::pointer &src);
  // In addition to binding, you need to execute:
  // glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
  // glEnable(GL_TEXTURE_RECTANGLE_NV);
    virtual void bind() const;

    static ocaSmartPointer<ocaLookUpBuffer> getCurrent();

    static ocaSmartPointer<ocaLookUpBuffer>
	create(ocaSmartPointer<ocaFactory> factory);

  // A class that will push the binding of the given context when
  // instantiated and pop the binding when destroyed.
    class ScopedBinding {
      private:
	ocaSmartPointer<ocaOpenGLContext> context;
      public:
	ScopedBinding(ocaSmartPointer<ocaOpenGLContext> c);
	~ScopedBinding();
    };

  protected:
    ocaLookUpBuffer(ocaSmartPointer<ocaFactory> factory);

    int size[2];
    int vectorSize;
    GLuint textureId;
};

#endif //_ocaLookUpBuffer_h
