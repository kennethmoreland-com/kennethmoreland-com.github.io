// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramIFFT2c.cxx,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#include "ocaProgramIFFT2c.h"

#include "ocaProgramFFT2c.h"
#include "ocaProgramIFFT1c.h"
#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"
#include "ocaFactory.h"
#include "ocaProgramPassThrough.h"


//-----------------------------------------------------------------------------
// Functions for main ocaProgramIFFT2c program.

ocaProgramIFFT2c::ocaProgramIFFT2c() {
}
ocaProgramIFFT2c::~ocaProgramIFFT2c() {
}

void ocaProgramIFFT2c::execute(ocaLookUpBuffer::pointer frequencies,
			       ocaDrawableBuffer::pointer samples)
{
    const int *size = samples->getSize();
    int vectorSize = samples->getVectorSize();

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer temporary
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);

    this->execute(frequencies, samples, temporary);
}

void ocaProgramIFFT2c::execute(ocaLookUpBuffer::pointer frequencies,
			       ocaDrawableBuffer::pointer samples,
			       ocaDrawableBuffer::pointer temporary)
{
    ocaDrawableBuffer::pointer a = samples;
    ocaDrawableBuffer::pointer b = temporary;

    this->do_IFFT(frequencies, a, b);

    if (a != samples) {
	samples->copy(ocaCast<ocaBuffer>(a));
    }
}

ocaDrawableBuffer::pointer ocaProgramIFFT2c
    ::execute(ocaDrawableBuffer::pointer frequencies)
{
    const int *size = frequencies->getSize();
    int vectorSize = frequencies->getVectorSize();

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer temporary
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);

    return this->execute(frequencies, temporary);
}

ocaDrawableBuffer::pointer ocaProgramIFFT2c
    ::execute(ocaDrawableBuffer::pointer frequencies,
	      ocaDrawableBuffer::pointer auxiliary)
{
    ocaDrawableBuffer::pointer samples, other;
    this->execute(frequencies, auxiliary, samples, other);
    return samples;
}

void ocaProgramIFFT2c::execute(ocaDrawableBuffer::pointer frequencies,
			       ocaDrawableBuffer::pointer auxiliary,
			       ocaDrawableBuffer::pointer &samples,
			       ocaDrawableBuffer::pointer &other)
{
    ocaDrawableBuffer::pointer target = auxiliary;
    ocaDrawableBuffer::pointer feedback = frequencies;

    this->do_IFFT(feedback->getSharedLookUpBuffer(), target, feedback);

    samples = feedback;
    other = target;
}

void ocaProgramIFFT2c::do_IFFT(ocaLookUpBuffer::pointer source,
			       ocaDrawableBuffer::pointer &target,
			       ocaDrawableBuffer::pointer &feedback)
{
    const int *arraySize = source->getSize();

    if ((arraySize[0] < 2) || (arraySize[1] < 2)) {
	ocaRaiseError("2D FFT must be of image size 2x2 or greater.");
    }

    int size = arraySize[1];
    int logsize = 0;
    int i = size;
    while (1) {
	if (i < 2) break;
	if ((i%2) == 1) ocaRaiseError("IFFT input must be a power of 2");
	i >>= 1;
	logsize++;
    }

    if (arraySize[1] < 2) {
	ocaRaiseError("Compressed IFFT requires at least 2 rows.");
    }
    if (arraySize[1]%2 != 0) {
	ocaRaiseError("Compressed IFFT requires an even amount of rows.");
    }

    const int *as_t = target->getSize();
    const int *as_f = feedback->getSize();
    if (   (arraySize[0] != as_t[0]) || (arraySize[1] != as_t[1])
	|| (arraySize[0] != as_f[0]) || (arraySize[1] != as_f[1]) ) {
	ocaRaiseError("Inconsistent buffer sizes.");
    }

  // Do the tangling.
    target->makeCurrent();

  // Tangle conjugates.
    ocaProgramIFFT1cTangleRealLower::pointer tangleRealLower
	= ocaProgramIFFT1cTangleRealLower::getSingleton();
    ocaProgramIFFT1cTangleRealUpper::pointer tangleRealUpper
	= ocaProgramIFFT1cTangleRealUpper::getSingleton();
    ocaProgramIFFT1cTangleImagLower::pointer tangleImagLower
	= ocaProgramIFFT1cTangleImagLower::getSingleton();
    ocaProgramIFFT1cTangleImagUpper::pointer tangleImagUpper
	= ocaProgramIFFT1cTangleImagUpper::getSingleton();

    float realFRegion[] = {
	0,			1,
	0,			(float)arraySize[1]/2,
	1,			(float)arraySize[1]/2,
	1,			1
    };
    float imagFRegion[] = {
	0,			(float)arraySize[1],
	0,			(float)arraySize[1]/2+1,
	1,			(float)arraySize[1]/2+1,
	1,			(float)arraySize[1]
    };
    float realGRegion[] = {
	(float)arraySize[0]/2,	1,
	(float)arraySize[0]/2,	(float)arraySize[1]/2,
	(float)arraySize[0]/2+1,(float)arraySize[1]/2,
	(float)arraySize[0]/2+1,1
    };
    float imagGRegion[] = {
	(float)arraySize[0]/2,	(float)arraySize[1],
	(float)arraySize[0]/2,	(float)arraySize[1]/2+1,
	(float)arraySize[0]/2+1,(float)arraySize[1]/2+1,
	(float)arraySize[0]/2+1,(float)arraySize[1]
    };

    ocaProgramPassThrough::getSingleton()->execute(source, target);

    tangleRealLower->execute(source, realFRegion, realGRegion,
			     imagFRegion, imagGRegion);
    tangleRealUpper->execute(source, realFRegion, realGRegion,
			     imagFRegion, imagGRegion);
    tangleImagLower->execute(source, realFRegion, realGRegion,
			     imagFRegion, imagGRegion);
    tangleImagUpper->execute(source, realFRegion, realGRegion,
			     imagFRegion, imagGRegion);

  // In case source came from feedback.
    feedback->releaseLookUpBuffer();

  // Swap target & feedback.
    ocaDrawableBuffer::pointer swap = target;
    target = feedback;
    feedback = swap;

  // Do the actuall FFT algorithm.
    ocaProgramFFT2cCore::getSingleton()
	->execute(feedback->getSharedLookUpBuffer(), target, feedback, false);

    ocaProgramIFFT1c::getSingleton()->execute(feedback, target,
					      feedback, target);
}
