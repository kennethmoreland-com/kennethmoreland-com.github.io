// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaError.cxx,v 1.1 2003/06/30 18:33:18 kmorel Exp $

#include "ocaError.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using std::string;

ocaError::ocaError()
{
    this->message = "";
}

ocaError::ocaError(const char *msg)
{
    this->message = msg;
}

ocaError::ocaError(string msg)
{
    this->message = msg;
}

ocaError::~ocaError()
{
}

string oca_itos(int num)
{
    static char s[256];
    sprintf(s, "%d", num);
    return string(s);
}

string oca_ftos(float num)
{
    static char s[256];
    sprintf(s, "%f", num);
    return string(s);
}
