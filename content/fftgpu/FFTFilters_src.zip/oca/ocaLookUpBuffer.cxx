// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaLookUpBuffer.cxx,v 1.2 2003/06/30 20:18:40 kmorel Exp $

#include "ocaLookUpBuffer.h"

#include "ocaError.h"
#include "ocaFactory.h"
#include "ocaDrawableBuffer.h"

#include <stack>
#include <map>

static std::map<GLuint, ocaLookUpBuffer *> textureMap;

static inline void bind(GLuint id)
{
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, id);
}

static inline GLenum getFormat(int vecsize)
{
    switch (vecsize) {
      case 1: return GL_RED;
      case 2: ocaRaiseError("2 vectors not supported yet");
      case 3: return GL_RGB;
      case 4: return GL_RGBA;
    }
    ocaRaiseError("Bad vector size: " + oca_itos(vecsize));
}
static inline GLenum getInternalFormat(int vecsize)
{
    switch (vecsize) {
      case 1: return GL_FLOAT_R_NV;
      case 2: return GL_FLOAT_RG_NV;
      case 3: return GL_FLOAT_RGB_NV;
      case 4: return GL_FLOAT_RGBA_NV;
    }
    ocaRaiseError("Bad vector size: " + oca_itos(vecsize));
}

ocaLookUpBuffer::ocaLookUpBuffer(ocaFactory::pointer factory)  {
    this->size[0] = 0;  this->size[1] = 0;
    this->vectorSize = 0;

  // Fake a registry so we don't delete the object when we pop the binding.
    this->refcount = 1;

    ocaOpenGLContext::ScopedContext saveContext;
    factory->makeCurrent();
    glGenTextures(1, &this->textureId);
    factory->pushBinding();
    this->bind();
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,
		    GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,
		    GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,
		    GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,
		    GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    factory->popBinding();

  // Save myself in map.
    textureMap[this->textureId] = this;

  // Fix registry
    this->refcount = 0;
}

ocaLookUpBuffer::~ocaLookUpBuffer() {
  // Remove myself from map.
  // Don't remove if we are already finalized (we may be exiting the program
  // and textureMap's data might have already been dealocated).
    if (!ocaObject::finalized()) {
	textureMap.erase(textureMap.find(this->textureId));
    }
}

void ocaLookUpBuffer::setSize(int sizex, int sizey, int sizev)
{
    this->size[0] = sizex;
    this->size[1] = sizey;
    this->vectorSize = sizev;
}

void ocaLookUpBuffer::getData(float *buffer) const
{
    ocaLookUpBuffer::ScopedBinding saveBinding(ocaOpenGLContext::getCurrent());
    this->bind();
    glGetTexImage(GL_TEXTURE_RECTANGLE_NV, 0, getFormat(this->vectorSize),
		  GL_FLOAT, buffer);
}

void ocaLookUpBuffer::setData(float *buffer)
{
    ocaLookUpBuffer::ScopedBinding saveBinding(ocaOpenGLContext::getCurrent());
    this->bind();
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0,
		 getInternalFormat(this->vectorSize),
		 this->size[0], this->size[1], 0,
		 getFormat(this->vectorSize), GL_FLOAT, buffer);
}

void ocaLookUpBuffer::setData(float *buffer, int sizex, int sizey, int sizev)
{
    this->setSize(sizex, sizey, sizev);
    this->setData(buffer);
}

void ocaLookUpBuffer::copy(const ocaBuffer::pointer &src)
{
    src->getSize(this->size);
    this->vectorSize = src->getVectorSize();

  //Change to handle copying from ocaOpenGLContext special.
    ocaOpenGLContext::pointer openglsrc = ocaCast<ocaOpenGLContext>(src);
    if (openglsrc.isNull()) {
	this->super::copy(src);
	return;
    }

    ocaOpenGLContext::ScopedContext saveContext;
    openglsrc->makeCurrent();
    ocaLookUpBuffer::ScopedBinding saveBinding(openglsrc);
    this->bind();
    glCopyTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0,
		     getInternalFormat(this->vectorSize),
		     0, 0, this->size[0], this->size[1], 0);
}

void ocaLookUpBuffer::bind() const
{
    glBindTexture(GL_TEXTURE_RECTANGLE_NV, this->textureId);
}

ocaLookUpBuffer::pointer ocaLookUpBuffer::getCurrent()
{
    GLint texBinding;
    glGetIntegerv(GL_TEXTURE_BINDING_RECTANGLE_NV, &texBinding);
    return textureMap[texBinding];
}

ocaLookUpBuffer::pointer ocaLookUpBuffer::create(ocaFactory::pointer factory)
{
    ocaLookUpBuffer::pointer newlub(new ocaLookUpBuffer(factory));
    return newlub;
}

ocaLookUpBuffer::ScopedBinding::ScopedBinding(ocaOpenGLContext::pointer c)
    : context(c)
{
    context->pushBinding();
}

ocaLookUpBuffer::ScopedBinding::~ScopedBinding()
{
    context->popBinding();
}
