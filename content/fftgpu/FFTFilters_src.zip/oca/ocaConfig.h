// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaConfig.h,v 1.2 2003/06/30 20:18:40 kmorel Exp $

#ifndef _ocaConfig_h
#define _ocaConfig_h

#ifndef WIN32
#define WIN32
#endif

#ifdef WIN32
#  pragma warning(disable : 4786)

#  include <windows.h>
#  include <wingdi.h>
#endif

#include <GL/gl.h>

#ifndef WIN32
#include <GL/glx.h>
#endif

// #define BUILD_SHARED_LIBS
// #ifndef BUILD_SHARED_LIBS
// #  define OCA_STATIC_LIBS
// #endif
// #undef BUILD_SHARED_LIBS

// #if defined(WIN32) && !defined(OCA_STATIC_LIBS)
// #  pragma warning (disable:4251)
// #  if defined(oca_EXPORTS)
// #    define OCA_EXPORT __declspec(dllexport)
// #  else
// #    define OCA_EXPORT __declspec(dllimport)
// #  endif
// #else
// #  define OCA_EXPORT
// #endif

#define OCA_EXPORT

// #define OCA_BUILD_CG_DIR	"C:/kmorel/school/thesis/oca/bin/../share/oca/Cg"
#define OCA_BUILD_CG_DIR	".;Cg;../Cg"

#endif //_ocaConfig_h
