// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaTimer.cxx,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#include "ocaTimer.h"

#include <time.h>

const double ocaTimer::ticksPerSec = (double)CLOCKS_PER_SEC;

ocaTimer::pointer ocaTimer::New()
{
    return ocaTimer::pointer(new ocaTimer);
}

ocaTimer::ocaTimer()
{
}

ocaTimer::~ocaTimer()
{
}

void ocaTimer::start()
{
    this->startTick = (unsigned long)clock();
}

void ocaTimer::stop()
{
    this->stopTick = (unsigned long)clock();
}

double ocaTimer::getElapsedTime()
{
    return (this->stopTick - this->startTick)/ocaTimer::ticksPerSec;
}
