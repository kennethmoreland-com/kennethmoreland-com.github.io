// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaObject.cxx,v 1.2 2003/06/30 20:18:40 kmorel Exp $

#include "ocaObject.h"

#include "ocaError.h"
#include "ocaCgError.h"
#include "ocaFactory.h"
#include "ocaProgram.h"

#include <Cg/cg.h>

#include "map"
#include "string"

#ifdef WIN32
#pragma warning(disable : 4297)
#endif
extern "C" {
    static void cgErrorCallback()
    {
	throw ocaCgError(cgGetError());
    }
}

static std::map<std::string, ocaObject::pointer> singletons;

ocaObject::ocaObject() : refcount(0)
{
    if (this->isSingleton()) {
	registerSingleton(ocaObject::pointer(this));
    }
}

ocaObject::~ocaObject()
{
}

static bool initialized = false;

void ocaObject::initialize()
{
  //This will create the initial context.
    ocaFactory::pointer factory = ocaFactory::getSingleton();
    factory->makeCurrent();
    ocaInitExtensions();

  //Make all Cg errors throw exceptions.
    cgSetErrorCallback(cgErrorCallback);

  //Find the source code directory.
    ocaProgram::findSourceDirectory();

    ::initialized = true;
}

bool ocaObject::initialized()
{
    return ::initialized;
}

static bool finalized = false;

void ocaObject::finalize()
{
    singletons.erase(singletons.begin(), singletons.end());
    ocaOpenGLContext::finalize();

    ::finalized = true;
}

bool ocaObject::finalized()
{
    return ::finalized;
}

ocaObject::pointer &ocaObject::getRegisteredSingleton(const char *classname)
{
    return singletons[classname];
}

void ocaObject::registerSingleton(pointer singleton)
{
    singletons[singleton->getClassName()] = singleton;
}

void ocaObject::Register()
{
    this->refcount++;
}

void ocaObject::Unregister()
{
    this->refcount--;
    if (this->refcount < 1) {
	delete this;
    }
}
