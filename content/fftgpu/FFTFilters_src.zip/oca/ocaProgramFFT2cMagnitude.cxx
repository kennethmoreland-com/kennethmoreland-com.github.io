// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT2cMagnitude.cxx,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#include "ocaProgramFFT2cMagnitude.h"

#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"

#include <iostream>

ocaProgramFFT2cMagnitude::ocaProgramFFT2cMagnitude()
{
    this->loadProgram("fft2c_magnitude.cg",
		      "FFT2cMagnitudeVert", "FFT2cMagnitudeFrag");

    this->Position = cgGetNamedParameter(this->vertProgram, "input.position");
    if (this->Position == NULL) {
	ocaRaiseError("Could not get pointer for position parameter.");
    }

    this->ArraySize = cgGetNamedParameter(this->fragProgram, "ArraySize");
    if (this->ArraySize == NULL) {
	ocaRaiseError("Could not get pointer for ArraySize parameter.");
    }

    this->HalfArraySize =cgGetNamedParameter(this->fragProgram,"HalfArraySize");
    if (this->HalfArraySize == NULL) {
	ocaRaiseError("Could not get pointer for HalfArraySize parameter.");
    }

    this->Frequencies = cgGetNamedParameter(this->fragProgram, "frequencies");
    if (this->Frequencies == NULL) {
	ocaRaiseError("Could not get pointer for frequencies parameter.");
    }
}

ocaProgramFFT2cMagnitude::~ocaProgramFFT2cMagnitude()
{
}

static GLfloat fullScreenSquare[] = {
    -1.0, -1.0,
    1.0, -1.0,
    1.0, 1.0,
    -1.0, 1.0
};

void ocaProgramFFT2cMagnitude::execute(ocaLookUpBuffer::pointer src,
				       ocaDrawableBuffer::pointer dest)
{
    ocaOpenGLContext::ScopedContext saveContext;

    dest->makeCurrent();
    this->execute(src);
}

void ocaProgramFFT2cMagnitude::execute(ocaLookUpBuffer::pointer src)
{
    const int *size = src->getSize();
    const int *size2 = ocaOpenGLContext::getCurrent()->getSize();

    if ((size[0] != size2[0]) || (size[1] != size2[1])) {
	ocaRaiseError("Input and output sizes don't match.");
    }

    this->bind();

    cgGLSetParameter2f(this->ArraySize, (float)size[0], (float)size[1]);
    cgGLSetParameter2f(this->HalfArraySize, 0.5f*size[0], 0.5f*size[1]);

    cgGLSetTextureParameter(this->Frequencies, src->getTextureId());
    cgGLEnableTextureParameter(this->Frequencies);

    cgGLSetParameterPointer(this->Position, 2, GL_FLOAT, 0, fullScreenSquare);
    cgGLEnableClientState(this->Position);

    glDrawArrays(GL_POLYGON, 0, 4);

    cgGLDisableClientState(this->Position);
    cgGLDisableTextureParameter(this->Frequencies);
    this->unbind();
}
