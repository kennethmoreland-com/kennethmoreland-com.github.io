// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaBuffer.h,v 1.1 2003/06/30 18:33:18 kmorel Exp $

#ifndef _ocaBuffer_h
#define _ocaBuffer_h

#include "ocaObject.h"

class OCA_EXPORT ocaBuffer : public ocaObject
{
  public:
    ocaTypeMacro(ocaBuffer, ocaObject);

  // Returns the size of the 2D buffer.  No deallocation necessary.
    virtual const int *getSize() const = 0;
    virtual void getSize(int size[2]) const;
    virtual void getSize(int &width, int &height) const;
  // Returns the number of elements in each buffer element.
    virtual int getVectorSize() const = 0;
  // Get set the data stored in the buffer.  The array must be at least
  // size[0]*size[1]*vectorsize.
    virtual void getData(float *buffer) const = 0;
    virtual void setData(float *buffer) = 0;
    virtual void setData(float *buffer, int sizex, int sizey, int sizev);
  // Performs a deep copy of the data.
    virtual void copy(const ocaSmartPointer<ocaBuffer> &src);
};

#endif //_ocaBuffer_h
