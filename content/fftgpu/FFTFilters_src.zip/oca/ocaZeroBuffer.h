// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaZeroBuffer.h,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#ifndef _ocaZeroBuffer_h
#define _ocaZeroBuffer_h

#include "ocaLookUpBuffer.h"

class OCA_EXPORT ocaZeroBuffer : public ocaLookUpBuffer
{
  public:
    ocaSingletonMacro(ocaZeroBuffer, ocaLookUpBuffer);

  // Simply throws an error since you are not allowed to change this buffer.
    virtual void setData(float *buffer);
    virtual void setData(float *buffer, int sizex, int sizey, int sizev);

  private:
    ocaZeroBuffer();
};

#endif //_ocaZeroBuffer_h
