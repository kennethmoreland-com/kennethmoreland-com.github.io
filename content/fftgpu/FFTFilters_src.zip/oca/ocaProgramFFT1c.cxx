// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT1c.cxx,v 1.2 2003/06/30 20:18:40 kmorel Exp $

#include "ocaProgramFFT1c.h"

#include "ocaLookUpBuffer.h"
#include "ocaDrawableBuffer.h"
#include "ocaFactory.h"
#include "ocaProgramScale.h"

#define GET_VERT_PROGRAM_PARAMETER(paramname, parameter)		\
    parameter = cgGetNamedParameter(this->vertProgram, paramname);	\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }
#define GET_FRAG_PROGRAM_PARAMETER(paramname, parameter)		\
    parameter = cgGetNamedParameter(this->fragProgram, paramname);	\
    if (parameter == NULL) {						\
	ocaRaiseError("Could not get pointer for parameter " #paramname); \
    }


//-----------------------------------------------------------------------------
// Auxiliary classes for performing actual FFT.

void ocaProgramFFT1cHelpers::load_program(const char **compilerArgs)
{
    this->loadProgram("fft.cg", "FFTVert", "FFTFrag", compilerArgs);
    GET_VERT_PROGRAM_PARAMETER("input.realIndex", this->realIndex);
    GET_VERT_PROGRAM_PARAMETER("input.imagIndex", this->imagIndex);
    GET_VERT_PROGRAM_PARAMETER("ArraySize", this->ArraySizeVert);
    GET_FRAG_PROGRAM_PARAMETER("ArraySize", this->ArraySizeFrag);
    GET_FRAG_PROGRAM_PARAMETER("PartitionSize", this->PartitionSize);
    GET_FRAG_PROGRAM_PARAMETER("NumPartitions", this->NumPartitions);
    GET_FRAG_PROGRAM_PARAMETER("Direction", this->Direction);
    GET_FRAG_PROGRAM_PARAMETER("InputSamples", this->InputSamples);
}

void ocaProgramFFT1cHelpers::execute(ocaLookUpBuffer::pointer source,
				     int partitionSize, int numPartitions,
				     float *realIndexes, float *imagIndexes,
				     bool forward)
{
    const int *arraySize = source->getSize();

    this->bind();
    cgGLSetParameter2f(this->ArraySizeVert, (float)arraySize[0], 
		       (float)arraySize[1]);
    cgGLSetParameter2f(this->ArraySizeFrag, (float)arraySize[0], 
		       (float)arraySize[1]);
    cgGLSetParameter1f(this->PartitionSize, (float)partitionSize);
    cgGLSetParameter1f(this->NumPartitions, (float)numPartitions);
    cgGLSetParameter1f(this->Direction, forward ? 1.0f : -1.0f);
    cgGLSetTextureParameter(this->InputSamples, source->getTextureId());
    cgGLEnableTextureParameter(this->InputSamples);

    cgGLEnableClientState(this->realIndex);
    cgGLEnableClientState(this->imagIndex);

    cgGLSetParameterPointer(this->realIndex, 2, GL_FLOAT, 0, realIndexes);
    cgGLSetParameterPointer(this->imagIndex, 2, GL_FLOAT, 0, imagIndexes);

    glDrawArrays(GL_QUADS, 0, 4);

    cgGLDisableClientState(this->realIndex);
    cgGLDisableClientState(this->imagIndex);
    cgGLDisableTextureParameter(this->InputSamples);

    this->unbind();
}


class ocaProgramFFT1cReal : public ocaProgramFFT1cHelpers
{
  public:
    ocaProgramMacro(FFT1cReal);
  protected:
    const static char *compilerArgs[];
};
const char *ocaProgramFFT1cReal::compilerArgs[] = { "-DFFT_DIM=x",
						    "-DCALCULATE_REAL",
						    NULL };
ocaProgramFFT1cReal::ocaProgramFFT1cReal() {
    this->load_program(compilerArgs);
}
ocaProgramFFT1cReal::~ocaProgramFFT1cReal() {}


class ocaProgramFFT1cImag : public ocaProgramFFT1cHelpers
{
  public:
    ocaProgramMacro(FFT1cImag);
  protected:
    const static char *compilerArgs[];
};
const char *ocaProgramFFT1cImag::compilerArgs[] = { "-DFFT_DIM=x",
						    "-DCALCULATE_IMAGINARY",
						    NULL };
ocaProgramFFT1cImag::ocaProgramFFT1cImag() {
    this->load_program(compilerArgs);
}
ocaProgramFFT1cImag::~ocaProgramFFT1cImag() {}


//-----------------------------------------------------------------------------
// Core FFT program.

ocaProgramFFT1cCore::ocaProgramFFT1cCore() {}
ocaProgramFFT1cCore::~ocaProgramFFT1cCore() {}

void ocaProgramFFT1cCore::execute(ocaLookUpBuffer::pointer source,
				  ocaDrawableBuffer::pointer &target,
				  ocaDrawableBuffer::pointer &feedback,
				  bool forward)
{
    const int *arraySize = target->getSize();
    int size = arraySize[0];

    static float realIndexes[2*4];
    static float imagIndexes[2*4];

    realIndexes[0] = 0;		realIndexes[1] = 0;
    realIndexes[2] = (float)arraySize[0];
				realIndexes[3] = 0;
    realIndexes[4] = (float)arraySize[0];
				realIndexes[5] = (float)(arraySize[1]/2);
    realIndexes[6] = 0;		realIndexes[7] = (float)(arraySize[1]/2);

    imagIndexes[0] = 0;		imagIndexes[1] = (float)(arraySize[1]/2);
    imagIndexes[2] = (float)arraySize[0];
				imagIndexes[3] = (float)(arraySize[1]/2);
    imagIndexes[4] = (float)arraySize[0];
				imagIndexes[5] = (float)arraySize[1];
    imagIndexes[6] = 0;		imagIndexes[7] = (float)arraySize[1];

    ocaProgramFFT1cReal::pointer real_prog
	= ocaProgramFFT1cReal::getSingleton();
    ocaProgramFFT1cImag::pointer imag_prog
	= ocaProgramFFT1cImag::getSingleton();

    bool first = true;
    for (int partitionSize = 2; partitionSize <= size; partitionSize *= 2)
    {
      // Set up lookup buffers.
	ocaLookUpBuffer::pointer lookUp;
	if (first) {
	    lookUp = source;
	    first = false;
	} else {
	    lookUp = feedback->getSharedLookUpBuffer();
	}

      // Perform calculation
	target->makeCurrent();
	real_prog->execute(lookUp, partitionSize, size/partitionSize,
			   realIndexes, imagIndexes, forward);
	imag_prog->execute(lookUp, partitionSize, size/partitionSize,
			   realIndexes, imagIndexes, forward);

      // Unbind shared lookup buffer.
	feedback->releaseLookUpBuffer();

      // Switch drawable buffers.
	ocaDrawableBuffer::pointer swap;
	swap = target;
	target = feedback;
	feedback = swap;
    }
}    


//-----------------------------------------------------------------------------
// Auxiliary classes for untangling FFT result.

void ocaProgramFFT1cUntanglers::load_program(const char **compilerArgs)
{
    this->loadProgram("fft1c_untangle.cg", "FFT1cUntangleVert",
		      "FFT1cUntangleFrag", compilerArgs);
    GET_VERT_PROGRAM_PARAMETER("input.realFIndex", this->realFIndex);
    GET_VERT_PROGRAM_PARAMETER("input.imagFIndex", this->imagFIndex);
    GET_VERT_PROGRAM_PARAMETER("input.realGIndex", this->realGIndex);
    GET_VERT_PROGRAM_PARAMETER("input.imagGIndex", this->imagGIndex);
    GET_VERT_PROGRAM_PARAMETER("ArraySize", this->ArraySize);
    GET_FRAG_PROGRAM_PARAMETER("Scale", this->Scale);
    GET_FRAG_PROGRAM_PARAMETER("TangledFrequencies", this->TangledFrequencies);
}
void ocaProgramFFT1cUntanglers::execute(ocaLookUpBuffer::pointer source,
					const float *realFRegion,
					const float *realGRegion,
					const float *imagFRegion,
					const float *imagGRegion,
					float scale)
{
    const int *arraySize = source->getSize();

    this->bind();
    cgGLSetParameter2f(this->ArraySize,
		       (float)arraySize[0], (float)arraySize[1]);
    cgGLSetParameter1f(this->Scale, scale);
    cgGLSetTextureParameter(this->TangledFrequencies, source->getTextureId());
    cgGLEnableTextureParameter(this->TangledFrequencies);

    cgGLSetParameterPointer(this->realFIndex, 2, GL_FLOAT, 0,
			    (void *)realFRegion);
    cgGLSetParameterPointer(this->realGIndex, 2, GL_FLOAT, 0,
			    (void *)realGRegion);
    cgGLSetParameterPointer(this->imagFIndex, 2, GL_FLOAT, 0,
			    (void *)imagFRegion);
    cgGLSetParameterPointer(this->imagGIndex, 2, GL_FLOAT, 0,
			    (void *)imagGRegion);

    cgGLEnableClientState(this->realFIndex);
    cgGLEnableClientState(this->imagFIndex);
    cgGLEnableClientState(this->realGIndex);
    cgGLEnableClientState(this->imagGIndex);

    glDrawArrays(GL_QUADS, 0, 4);

    cgGLDisableClientState(this->realFIndex);
    cgGLDisableClientState(this->imagFIndex);
    cgGLDisableClientState(this->realGIndex);
    cgGLDisableClientState(this->imagGIndex);
    cgGLDisableTextureParameter(this->TangledFrequencies);

    this->unbind();
}

ocaProgramFFT1cUntangleRealF::ocaProgramFFT1cUntangleRealF() {
    this->load_program(this->compilerArgs);
}
ocaProgramFFT1cUntangleRealF::~ocaProgramFFT1cUntangleRealF() {}
const char *ocaProgramFFT1cUntangleRealF::compilerArgs[] = {
    "-DCALCULATE_REAL", "-DCALCULATE_F", NULL
};

ocaProgramFFT1cUntangleRealG::ocaProgramFFT1cUntangleRealG() {
    this->load_program(this->compilerArgs);
}
ocaProgramFFT1cUntangleRealG::~ocaProgramFFT1cUntangleRealG() {}
const char *ocaProgramFFT1cUntangleRealG::compilerArgs[] = {
    "-DCALCULATE_REAL", "-DCALCULATE_G", NULL
};

ocaProgramFFT1cUntangleImagF::ocaProgramFFT1cUntangleImagF() {
    this->load_program(this->compilerArgs);
}
ocaProgramFFT1cUntangleImagF::~ocaProgramFFT1cUntangleImagF() {}
const char *ocaProgramFFT1cUntangleImagF::compilerArgs[] = {
    "-DCALCULATE_IMAGINARY", "-DCALCULATE_F", NULL
};

ocaProgramFFT1cUntangleImagG::ocaProgramFFT1cUntangleImagG() {
    this->load_program(this->compilerArgs);
}
ocaProgramFFT1cUntangleImagG::~ocaProgramFFT1cUntangleImagG() {}
const char *ocaProgramFFT1cUntangleImagG::compilerArgs[] = {
    "-DCALCULATE_IMAGINARY", "-DCALCULATE_G", NULL
};


//-----------------------------------------------------------------------------
// Functions for main ocaProgramFFT1c program.

ocaProgramFFT1c::ocaProgramFFT1c() {
}
ocaProgramFFT1c::~ocaProgramFFT1c() {
}

void ocaProgramFFT1c::execute(ocaLookUpBuffer::pointer samples,
			      ocaDrawableBuffer::pointer frequencies)
{
    const int *size = frequencies->getSize();
    int vectorSize = frequencies->getVectorSize();

    ocaFactory::pointer factory = ocaFactory::getSingleton();
    ocaDrawableBuffer::pointer temporary
	= factory->makeDrawableBuffer(size[0], size[1], vectorSize);

    this->execute(samples, frequencies, temporary);
}

void ocaProgramFFT1c::execute(ocaLookUpBuffer::pointer samples,
			      ocaDrawableBuffer::pointer frequencies,
			      ocaDrawableBuffer::pointer temporary)
{
    const int *arraySize = samples->getSize();

    int size = arraySize[0];
    int logsize = 0;
    int i = size;
    while (1) {
	if (i < 2) break;
	if ((i%2) == 1) ocaRaiseError("FFT input must be a power of 2");
	i >>= 1;
	logsize++;
    }

  // Special case of 1 sample inputs.
    if (logsize == 0) {
	frequencies->copy(ocaCast<ocaBuffer>(samples));
	return;
    }

    int rows = arraySize[1];
    if (rows < 2) {
	ocaRaiseError("Compressed FFT requires at least 2 rows.");
    }
    if (rows%2 != 0) {
	ocaRaiseError("Compressed FFT requires an even amount of rows.");
    }

    ocaDrawableBuffer::pointer feedback;
    ocaDrawableBuffer::pointer target;

    if ((logsize%2) == 0) {
	feedback = temporary;
	target = frequencies;
    } else {
	target = temporary;
	feedback = frequencies;
    }

    ocaProgramFFT1cCore::getSingleton()->execute(samples,
						 target, feedback, true);

  // Now do the untangling.
    target->makeCurrent();
    ocaLookUpBuffer::pointer lookup = feedback->getSharedLookUpBuffer();

  // Untangle conjugates.
    ocaProgramFFT1cUntangleRealF::pointer untangleRealF
	= ocaProgramFFT1cUntangleRealF::getSingleton();
    ocaProgramFFT1cUntangleRealG::pointer untangleRealG
	= ocaProgramFFT1cUntangleRealG::getSingleton();
    ocaProgramFFT1cUntangleImagF::pointer untangleImagF
	= ocaProgramFFT1cUntangleImagF::getSingleton();
    ocaProgramFFT1cUntangleImagG::pointer untangleImagG
	= ocaProgramFFT1cUntangleImagG::getSingleton();

    float realFRegion[] = {
	1, 				0,
	(float)(arraySize[0]/2),	0,
	(float)(arraySize[0]/2),	(float)(arraySize[1]/2),
	1,				(float)(arraySize[1]/2)
    };
    float imagFRegion[] = {
	(float)(arraySize[0]),		0,
	(float)(arraySize[0]/2+1),	0,
	(float)(arraySize[0]/2+1),	(float)(arraySize[1]/2),
	(float)(arraySize[0]),		(float)(arraySize[1]/2)
    };
    float realGRegion[] = {
	1,				(float)(arraySize[1]/2),
	(float)(arraySize[0]/2),	(float)(arraySize[1]/2),
	(float)(arraySize[0]/2),	(float)(arraySize[1]),
	1,				(float)(arraySize[1])
    };
    float imagGRegion[] = {
	(float)(arraySize[0]),		(float)(arraySize[1]/2),
	(float)(arraySize[0]/2+1),	(float)(arraySize[1]/2),
	(float)(arraySize[0]/2+1),	(float)(arraySize[1]),
	(float)(arraySize[0]),		(float)(arraySize[1])
    };

    float scale = 1.0f/(float)arraySize[0];

    untangleRealF->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);
    untangleRealG->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);
    untangleImagF->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);
    untangleImagG->execute(lookup, realFRegion, realGRegion,
			   imagFRegion, imagGRegion, scale);

  // Pass through stuff that doesn't need changing.
    const static float PassThroughLines[] = {
	-1, -1,
	-1, 1,
	0, -1,
	0, 1
    };

    ocaProgramScale::pointer scaleProgram = ocaProgramScale::getSingleton();
    scaleProgram->bind();
    cgGLSetParameter1f(scaleProgram->getScale(), scale);
    cgGLSetTextureParameter(scaleProgram->getSource(), lookup->getTextureId());
    cgGLEnableTextureParameter(scaleProgram->getSource());
    cgGLSetParameterPointer(scaleProgram->getPosition(), 2, GL_FLOAT, 0,
			    (void *)PassThroughLines);
    cgGLEnableClientState(scaleProgram->getPosition());
    glDrawArrays(GL_LINES, 0, 4);
    cgGLDisableClientState(scaleProgram->getPosition());
    cgGLDisableTextureParameter(scaleProgram->getSource());
    scaleProgram->unbind();

    feedback->releaseLookUpBuffer();
}


// -----------------------------------------------------------------------------
// Static functions for compressing and uncompressing FFT's.
void ocaProgramFFT1c::uncompress(int windowsize, int vectorsize,
				 const float *freqcompress,
				 float *freqreal, float *freqimag)
{
    int i, j;

    for (i = 0; i < windowsize; i++) {
	for (j = 0; j < vectorsize; j++) {
	    if (freqreal) {
		if (i <= windowsize/2) {
		    freqreal[vectorsize*i + j] = freqcompress[vectorsize*i + j];
		} else {
		    freqreal[vectorsize*i + j]
			= freqcompress[vectorsize*(windowsize-i) + j];
		}
	    }
	    if (freqimag) {
		if ((i == 0) || (i == windowsize/2)) {
		    freqimag[vectorsize*i + j] = 0;
		} else if (i < windowsize/2) {
		    freqimag[vectorsize*i + j]
			= -freqcompress[vectorsize*(windowsize-i) + j];
		} else {
		    freqimag[vectorsize*i + j] = freqcompress[vectorsize*i + j];
		}
	    }
	}
    }
}

void ocaProgramFFT1c::compress(int windowsize, int vectorsize,
			       float *freqcompress,
			       const float *freqreal, const float *freqimag)
{
    int i, j;

    for (i = 0; i < windowsize; i++) {
	for (j = 0; j < vectorsize; j++) {
	    if (i <= windowsize/2) {
		freqcompress[vectorsize*i + j] = freqreal[vectorsize*i + j];
	    } else if (freqimag) {
		freqcompress[vectorsize*i + j] = freqimag[vectorsize*i + j];
	    } else {
		freqcompress[vectorsize*i + j] = 0;
	    }
	}
    }
}
