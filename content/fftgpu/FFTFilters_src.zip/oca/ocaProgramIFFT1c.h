// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramIFFT1c.h,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#ifndef _ocaProgramIFFT1c_h
#define _ocaProgramIFFT1c_h

#include "ocaProgram.h"

class ocaLookUpBuffer;
class ocaDrawableBuffer;

class OCA_EXPORT ocaProgramIFFT1c : public ocaProgram
{
  public:
    ocaProgramMacro(IFFT1c);

  // Takes the compressed 1D FFT (frequencies) and places the original
  // data in samples.
    void execute(ocaSmartPointer<ocaLookUpBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> samples);
    void execute(ocaSmartPointer<ocaLookUpBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> samples,
		 ocaSmartPointer<ocaDrawableBuffer> temporary);

  // Takes the compressed 1D FFT (frequencies) that is in a drawable
  // buffer and computes the original data.  The original data is placed
  // in one of the two input buffers (if two are given).  The correct
  // buffer is returned.
    ocaSmartPointer<ocaDrawableBuffer>
	execute(ocaSmartPointer<ocaDrawableBuffer> frequencies);
    ocaSmartPointer<ocaDrawableBuffer>
	execute(ocaSmartPointer<ocaDrawableBuffer> frequencies,
		ocaSmartPointer<ocaDrawableBuffer> auxiliary);

  // Takes the compressed 1D FFT (frequencies) that is in a drawable
  // buffer and computes the original data.  The original data is placed
  // in one of the two input buffers (if two are given).  The correct
  // buffer is returned in samples, and the other is placed in other.
    void execute(ocaSmartPointer<ocaDrawableBuffer> frequencies,
		 ocaSmartPointer<ocaDrawableBuffer> auxiliary,
		 ocaSmartPointer<ocaDrawableBuffer> &samples,
		 ocaSmartPointer<ocaDrawableBuffer> &other);

  protected:
  // Performs the IFFT on source.  Source may be a shared lookup buffer for
  // feedback.  feedback is set to the buffer with the result, target is
  // set to the opposite.
    void do_IFFT(ocaSmartPointer<ocaLookUpBuffer> source,
		 ocaSmartPointer<ocaDrawableBuffer> &target,
		 ocaSmartPointer<ocaDrawableBuffer> &feedback);
};


class ocaProgramIFFT1cTanglers : public ocaProgram
{
  public:
    void execute(ocaSmartPointer<ocaLookUpBuffer> source,
		 const float *realFRegion, const float *realGRegion,
		 const float *imagFRegion, const float *imagGRegion);
  protected:
    ocaProgramIFFT1cTanglers() {}
    void load_program(const char **compilerArgs);
    CGparameter realFIndex;
    CGparameter imagFIndex;
    CGparameter realGIndex;
    CGparameter imagGIndex;
    CGparameter ArraySize;
    CGparameter CompressedFrequencies;
};
class ocaProgramIFFT1cTangleRealLower : public ocaProgramIFFT1cTanglers
{
  public:
    ocaProgramMacro(IFFT1cTangleRealLower);
  protected:
    const static char *compilerArgs[];
};
class ocaProgramIFFT1cTangleRealUpper : public ocaProgramIFFT1cTanglers
{
  public:
    ocaProgramMacro(IFFT1cTangleRealUpper);
  protected:
    const static char *compilerArgs[];
};
class ocaProgramIFFT1cTangleImagLower : public ocaProgramIFFT1cTanglers
{
  public:
    ocaProgramMacro(IFFT1cTangleImagLower);
  protected:
    const static char *compilerArgs[];
};
class ocaProgramIFFT1cTangleImagUpper : public ocaProgramIFFT1cTanglers
{
  public:
    ocaProgramMacro(IFFT1cTangleImagUpper);
  protected:
    const static char *compilerArgs[];
};

#endif //_ocaProgramIFFT1c_h
