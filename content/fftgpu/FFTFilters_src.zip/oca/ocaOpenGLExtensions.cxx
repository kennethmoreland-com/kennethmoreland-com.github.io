// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaOpenGLExtensions.cxx,v 1.1 2003/06/30 18:33:18 kmorel Exp $

#include "ocaOpenGLExtensions.h"

#include "ocaError.h"

#include <GL/glu.h>

struct _ocagl ocagl;

static GLboolean myCheckExtension(const char *extName,const GLubyte *extString);
static GLboolean extensionExists(const char *name);

#ifdef WIN32
#define GetProcAddress(function) wglGetProcAddress((const char *)function)
#else
#define GetProcAddress(function) glXGetProcAddressARB((const GLubyte *)function)
#endif

#define CHECK_EXTENSION(extension)					\
    if (!extensionExists(#extension))					\
	ocaRaiseError("Extension " #extension " does not exist");

#define LOAD_FUNCTION(name, gltype, prototype)				  \
    ocagl.name = (PFN ## prototype ## PROC)GetProcAddress(#gltype #name); \
    if (ocagl.name == NULL) {						  \
	ocaRaiseError("Could not load " #gltype #name);		  \
    }
#define LOAD_GL_FUNCTION(capname, name) LOAD_FUNCTION(name, gl, GL ## capname)
#define LOAD_WGL_FUNCTION(capname, name) LOAD_FUNCTION(name,wgl,WGL ## capname)
#define LOAD_GLX_FUNCTION(capname, name) LOAD_FUNCTION(name,glX,GLX ## capname)

void ocaInitExtensions()
{
#ifdef WIN32
    CHECK_EXTENSION(WGL_ARB_pixel_format);
    LOAD_WGL_FUNCTION(GETPIXELFORMATATTRIBIVARB, GetPixelFormatAttribivARB);
    LOAD_WGL_FUNCTION(GETPIXELFORMATATTRIBFVARB, GetPixelFormatAttribfvARB);
    LOAD_WGL_FUNCTION(CHOOSEPIXELFORMATARB, ChoosePixelFormatARB);

    CHECK_EXTENSION(WGL_ARB_pbuffer);
    LOAD_WGL_FUNCTION(CREATEPBUFFERARB, CreatePbufferARB);
    LOAD_WGL_FUNCTION(GETPBUFFERDCARB, GetPbufferDCARB);
    LOAD_WGL_FUNCTION(RELEASEPBUFFERDCARB, ReleasePbufferDCARB);
    LOAD_WGL_FUNCTION(DESTROYPBUFFERARB, DestroyPbufferARB);
    LOAD_WGL_FUNCTION(QUERYPBUFFERARB, QueryPbufferARB);

    CHECK_EXTENSION(WGL_NV_float_buffer);

    CHECK_EXTENSION(WGL_ARB_render_texture);
    LOAD_WGL_FUNCTION(BINDTEXIMAGEARB, BindTexImageARB);
    LOAD_WGL_FUNCTION(RELEASETEXIMAGEARB, ReleaseTexImageARB);
    LOAD_WGL_FUNCTION(SETPBUFFERATTRIBARB, SetPbufferAttribARB);

    CHECK_EXTENSION(WGL_NV_render_texture_rectangle);

#else //not WIN32

    CHECK_EXTENSION(GLX_SGIX_fbconfig);
    LOAD_GLX_FUNCTION(GETFBCONFIGATTRIBSGIX, GetFBConfigAttribSGIX);
    LOAD_GLX_FUNCTION(CHOOSEFBCONFIGSGIX, ChooseFBConfigSGIX);
    LOAD_GLX_FUNCTION(CREATEGLXPIXMAPWITHCONFIGSGIX, CreateGLXPixmapWithConfigSGIX);
    LOAD_GLX_FUNCTION(CREATECONTEXTWITHCONFIGSGIX, CreateContextWithConfigSGIX);
    LOAD_GLX_FUNCTION(GETVISUALFROMFBCONFIGSGIX, GetVisualFromFBConfigSGIX);
    LOAD_GLX_FUNCTION(GETFBCONFIGFROMVISUALSGIX, GetFBConfigFromVisualSGIX);

    CHECK_EXTENSION(GLX_SGIX_pbuffer);
    LOAD_GLX_FUNCTION(CREATEGLXPBUFFERSGIX, CreateGLXPbufferSGIX);
    LOAD_GLX_FUNCTION(DESTROYGLXPBUFFERSGIX, DestroyGLXPbufferSGIX);
    LOAD_GLX_FUNCTION(QUERYGLXPBUFFERSGIX, QueryGLXPbufferSGIX);
    LOAD_GLX_FUNCTION(SELECTEVENTSGIX, SelectEventSGIX);
    LOAD_GLX_FUNCTION(GETSELECTEDEVENTSGIX, GetSelectedEventSGIX);

    CHECK_EXTENSION(GLX_NV_float_buffer);

#endif //WIN32

    CHECK_EXTENSION(GL_NV_float_buffer);
    CHECK_EXTENSION(GL_NV_texture_rectangle);

    CHECK_EXTENSION(GL_NV_vertex_program2);
#if 0
    LOAD_GL_FUNCTION(BINDPROGRAMNV, BindProgramNV);
    LOAD_GL_FUNCTION(DELETEPROGRAMSNV, DeleteProgramsNV);
    LOAD_GL_FUNCTION(EXECUTEPROGRAMNV, ExecuteProgramNV);
    LOAD_GL_FUNCTION(GENPROGRAMSNV, GenProgramsNV);
    LOAD_GL_FUNCTION(AREPROGRAMSRESIDENTNV, AreProgramsResidentNV);
    LOAD_GL_FUNCTION(REQUESTRESIDENTPROGRAMSNV, RequestResidentProgramsNV);
    LOAD_GL_FUNCTION(GETPROGRAMPARAMETERFVNV, GetProgramParameterfvNV);
    LOAD_GL_FUNCTION(GETPROGRAMPARAMETERDVNV, GetProgramParameterdvNV);
    LOAD_GL_FUNCTION(GETPROGRAMIVNV, GetProgramivNV);
    LOAD_GL_FUNCTION(GETPROGRAMSTRINGNV, GetProgramStringNV);
    LOAD_GL_FUNCTION(GETTRACKMATRIXIVNV, GetTrackMatrixivNV);
    LOAD_GL_FUNCTION(GETVERTEXATTRIBDVNV, GetVertexAttribdvNV);
    LOAD_GL_FUNCTION(GETVERTEXATTRIBFVNV, GetVertexAttribfvNV);
    LOAD_GL_FUNCTION(GETVERTEXATTRIBIVNV, GetVertexAttribivNV);
    LOAD_GL_FUNCTION(GETVERTEXATTRIBPOINTERVNV, GetVertexAttribPointervNV);
    LOAD_GL_FUNCTION(ISPROGRAMNV, IsProgramNV);
    LOAD_GL_FUNCTION(LOADPROGRAMNV, LoadProgramNV);
    LOAD_GL_FUNCTION(PROGRAMPARAMETER4FNV, ProgramParameter4fNV);
    LOAD_GL_FUNCTION(PROGRAMPARAMETER4DNV, ProgramParameter4dNV);
    LOAD_GL_FUNCTION(PROGRAMPARAMETER4DVNV, ProgramParameter4dvNV);
    LOAD_GL_FUNCTION(PROGRAMPARAMETER4FVNV, ProgramParameter4fvNV);
    LOAD_GL_FUNCTION(PROGRAMPARAMETERS4DVNV, ProgramParameters4dvNV);
    LOAD_GL_FUNCTION(PROGRAMPARAMETERS4FVNV, ProgramParameters4fvNV);
    LOAD_GL_FUNCTION(TRACKMATRIXNV, TrackMatrixNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBPOINTERNV, VertexAttribPointerNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB1SNV, VertexAttrib1sNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB1FNV, VertexAttrib1fNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB1DNV, VertexAttrib1dNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB2SNV, VertexAttrib2sNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB2FNV, VertexAttrib2fNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB2DNV, VertexAttrib2dNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB3SNV, VertexAttrib3sNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB3FNV, VertexAttrib3fNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB3DNV, VertexAttrib3dNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4SNV, VertexAttrib4sNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4FNV, VertexAttrib4fNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4DNV, VertexAttrib4dNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4UBNV, VertexAttrib4ubNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB1SVNV, VertexAttrib1svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB1FVNV, VertexAttrib1fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB1DVNV, VertexAttrib1dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB2SVNV, VertexAttrib2svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB2FVNV, VertexAttrib2fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB2DVNV, VertexAttrib2dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB3SVNV, VertexAttrib3svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB3FVNV, VertexAttrib3fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB3DVNV, VertexAttrib3dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4SVNV, VertexAttrib4svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4FVNV, VertexAttrib4fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4DVNV, VertexAttrib4dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIB4UBVNV, VertexAttrib4ubvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS1SVNV, VertexAttribs1svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS1FVNV, VertexAttribs1fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS1DVNV, VertexAttribs1dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS2SVNV, VertexAttribs2svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS2FVNV, VertexAttribs2fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS2DVNV, VertexAttribs2dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS3SVNV, VertexAttribs3svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS3FVNV, VertexAttribs3fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS3DVNV, VertexAttribs3dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS4SVNV, VertexAttribs4svNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS4FVNV, VertexAttribs4fvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS4DVNV, VertexAttribs4dvNV);
    LOAD_GL_FUNCTION(VERTEXATTRIBS4UBVNV, VertexAttribs4ubvNV);
#endif

    CHECK_EXTENSION(GL_NV_fragment_program);
}


#if GLU_VERSION_1_3
static GLboolean myCheckExtension(const char *extName, const GLubyte *extString)
{
#ifdef WIN32
    return gluCheckExtension(extName, extString);
#else
    return gluCheckExtension((const GLubyte *)extName,
			     (const GLubyte *)extString);
#endif
}
#else
static GLboolean myCheckExtension(const char *extName, const GLubyte *extString)
{
    const char *p = (const char *)extString;
    size_t extNameLen = strlen(extName);

    if (extString == NULL) return GL_FALSE;

    while (GL_TRUE) {
	size_t n;
	while (*p == ' ') p++;
	if (*p == '\0') return GL_FALSE;
	n = strcspn(p, " ");
	if ((extNameLen == n) && (strncmp(extName, p, n) == 0)) {
	    return GL_TRUE;
	}
	p += n;
    }
  //Shadup compiler
    return GL_FALSE;
}
#endif

static GLboolean extensionExists(const char *name)
{
#ifdef _WIN32
    PFNWGLGETEXTENSIONSSTRINGARBPROC wglGetExtensionsStringARB = 0;
#endif

    if (myCheckExtension(name, glGetString(GL_EXTENSIONS))) return GL_TRUE;
    if (myCheckExtension(name, gluGetString(GLU_EXTENSIONS))) return GL_TRUE;

#ifdef _WIN32
    wglGetExtensionsStringARB = (PFNWGLGETEXTENSIONSSTRINGARBPROC)wglGetProcAddress("wglGetExtensionsStringARB");
    if (wglGetExtensionsStringARB) {
	if (myCheckExtension(name, (const GLubyte *)wglGetExtensionsStringARB(wglGetCurrentDC())))
	    return GL_TRUE;
    }
#else
    if (myCheckExtension(name, (const GLubyte *)glXGetClientString(glXGetCurrentDisplay(),
								   GLX_EXTENSIONS)))
	return GL_TRUE;
#endif
    
    return GL_FALSE;
}
