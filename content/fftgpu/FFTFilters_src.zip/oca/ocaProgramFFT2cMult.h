// -*- c++ -*- *******************************************************
// Copyright (C) 2003 Sandia Corporation
// Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
// license for use of this work by or on behalf of the U.S. Government.
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that this Notice and any statement
// of authorship are reproduced on all copies.
//
// $Id: ocaProgramFFT2cMult.h,v 1.1 2003/06/30 18:33:19 kmorel Exp $

#ifndef _ocaProgramFFT2cMult_h
#define _ocaProgramFFT2cMult_h

#include "ocaProgram.h"

class ocaLookUpBuffer;
class ocaDrawableBuffer;

class OCA_EXPORT ocaProgramFFT2cMult : public ocaProgram
{
  public:
    ocaProgramMacro(FFT2cMult);

    void execute(ocaSmartPointer<ocaLookUpBuffer> frequencies1,
		 ocaSmartPointer<ocaLookUpBuffer> frequencies2,
		 ocaSmartPointer<ocaDrawableBuffer> destination);

  protected:
    CGparameter Position;
    CGparameter ArraySize;
    CGparameter HalfArraySize;
    CGparameter Frequencies1;
    CGparameter Frequencies2;
};

#endif //_ocaProgramFFT2cMult_h
